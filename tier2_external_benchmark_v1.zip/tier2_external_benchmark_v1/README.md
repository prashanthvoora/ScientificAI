# Tier-2 External Dielectric Benchmark v1

## Scientific target harmonization

The Tier-2 model head is `k_total_log = ln(k_total)`. The source oxide database
provides spherical averages (or full tensors) for the electronic and ionic
static dielectric contributions. The builder computes:

```
k_electronic = spherical average of electronic tensor
k_ionic      = spherical average of ionic tensor
k_total      = k_electronic + k_ionic
k_total_log  = natural log(k_total)
```

This matches the scalar total DFPT convention used for the ALIGNN
`epsilon(DFPT: elec+ionic)` result. Linear `k_total` MAE/RMSE/MAD::MAE is the
headline result; log-space results are retained because that is the model's
training scale.

The default domain filters match v4.60.3 Tier-2:

* `k_total >= 3.9`
* `band_gap >= 1.0 eV`
* ordered structure
* 2–100 atoms
* `k_total <= 500`

## 1. Environment

Use the same environment as v4.60.3:

```bash
conda activate <your-alignn-environment>
pip install requests pandas numpy pymatgen tqdm
python -m py_compile build_tier2_oxi_dielectric_benchmark.py
python -m py_compile tier2_external_eval.py
```

## 2. Build and freeze the benchmark

Automatic download from the public source repository:

```bash
python build_tier2_oxi_dielectric_benchmark.py \
  --output-dir external_raw/tier2_oxide_dielectric_v1 \
  --min-k 3.9 \
  --min-band-gap 1.0 \
  --min-atoms 2 \
  --max-atoms 100
```

The builder keeps all accepted rows by default. To perform the slower
within-source structural deduplication:

```bash
python build_tier2_oxi_dielectric_benchmark.py \
  --output-dir external_raw/tier2_oxide_dielectric_v1 \
  --min-k 3.9 --min-band-gap 1.0 \
  --deduplicate-structures
```

If you manually cloned/downloaded the source repository:

```bash
python build_tier2_oxi_dielectric_benchmark.py \
  --source-dir /path/to/oxi_diel_db \
  --output-dir external_raw/tier2_oxide_dielectric_v1 \
  --min-k 3.9 --min-band-gap 1.0
```

Generated files include:

```
external_raw/tier2_oxide_dielectric_v1/
├── tier2_external_manifest.csv
├── tier2_external_manifest.csv.metadata.json
├── tier2_external_selected.csv
├── tier2_external_rejections.csv
├── tier2_external_build_metadata.json
└── structures/*.cif
```

Read the manifest SHA-256:

```bash
python - <<'PY'
import json
p='external_raw/tier2_oxide_dielectric_v1/tier2_external_manifest.csv.metadata.json'
print(json.load(open(p))['manifest_sha256'])
PY
```

Do not modify the manifest after freezing it.

## 3. Diagnostic evaluation without bootstrap

```bash
CUDA_VISIBLE_DEVICES=0 python tier2_external_eval.py \
  --pipeline highk_alignn_train_v4_60_3_locked_disjoint_baseline.py \
  --manifest external_raw/tier2_oxide_dielectric_v1/tier2_external_manifest.csv \
  --expected-hash <MANIFEST_SHA256> \
  --tier2-weights highk_project/checkpoints/tier2_best.pt \
  --tier1-weights highk_project/checkpoints/tier1_best.pt \
  --overlap-policy exclude \
  --batch-size 32 \
  --num-workers 0 \
  --n-boot 0 \
  --outdir highk_project/reports/tier2_external_oxide_v1_smoke
```

`--tier1-weights` is optional but strongly recommended. It enables a paired
comparison on identical external rows and directly tests whether Tier-2 domain
fine-tuning improves dielectric performance relative to the Tier-1 checkpoint.

## 4. Final evaluation

```bash
CUDA_VISIBLE_DEVICES=0 python tier2_external_eval.py \
  --pipeline highk_alignn_train_v4_60_3_locked_disjoint_baseline.py \
  --manifest external_raw/tier2_oxide_dielectric_v1/tier2_external_manifest.csv \
  --expected-hash <MANIFEST_SHA256> \
  --tier2-weights highk_project/checkpoints/tier2_best.pt \
  --tier1-weights highk_project/checkpoints/tier1_best.pt \
  --overlap-policy exclude \
  --batch-size 32 \
  --num-workers 4 \
  --n-boot 10000 \
  --outdir highk_project/reports/tier2_external_oxide_v1_final
```

Use `python`, not `torchrun`; this is single-process inference-only evaluation.

## 5. Outputs

```
tier2_external_summary.md
tier2_external_metrics.csv
tier2_external_prediction_audit.csv
tier2_external_overlap_audit.csv
tier2_external_dataset_flow_audit.csv
tier2_vs_tier1_paired_bootstrap.csv
tier2_external_metadata.json
```

The evaluator reports:

* Tier-2 metrics for `all_benchmark` and `strict_external`
* Tier-1 baseline metrics for the same populations when supplied
* log-space `k_total_log`
* linear-space `k_total` headline metrics
* band-gap metrics
* 95% row-bootstrap CIs
* paired Tier-2 minus Tier-1 improvement statistics
* row win/loss/tie counts

## 6. Interpretation

For the paired report, positive values always favor Tier-2:

```
MAE improvement = MAE(Tier-1) - MAE(Tier-2)
MAD::MAE improvement = ratio(Tier-2) - ratio(Tier-1)
```

A supported external improvement requires:

* point MAE improvement > 0
* 95% paired-bootstrap CI for MAE improvement excludes 0
* preferably consistent improvement for both all and strict populations
* row wins not concentrated in only a few extreme materials

If the CI crosses zero, report the observed change but do not claim established
external superiority.

## 7. Optional benchmark variants

All harmonized oxides, including lower-k rows:

```bash
--min-k 1.0
```

Dynamically stable subset:

```bash
--require-dynamic-stability --min-phonon-frequency -0.3
```

Allow rows without band-gap labels while still evaluating dielectric:

```bash
--allow-missing-band-gap
```

Keep each variant in a separate output directory and freeze a separate manifest
hash. Do not tune the model based on any external result.
