#!/usr/bin/env python3
"""Inference-only Tier-2 external benchmark evaluator.

Loads classes and checkpoint utilities from the supplied v4.60.3 training file,
evaluates a frozen Tier-2 checkpoint on a harmonized dielectric manifest, and
reports:
  * all_benchmark and strict_external populations
  * log-space and linear-space k_total metrics
  * band-gap and optional formation-energy metrics
  * bootstrap confidence intervals
  * overlap and dataset-flow audits
  * optional paired Tier-2 vs Tier-1 checkpoint improvement analysis

The evaluator never creates an optimizer, scheduler, split, or checkpoint.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm


def load_pipeline(path: Path):
    spec = importlib.util.spec_from_file_location("highk_v4603_pipeline", path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot import pipeline from {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def metric_arrays(y: np.ndarray, p: np.ndarray) -> Dict[str, float]:
    mask = np.isfinite(y) & np.isfinite(p)
    y, p = y[mask].astype(float), p[mask].astype(float)
    if len(y) == 0:
        return {"n": 0, "mae": np.nan, "rmse": np.nan, "mad": np.nan, "mad_mae": np.nan,
                "median_ae": np.nan, "p90_ae": np.nan, "mean_signed_error": np.nan}
    e = p - y
    ae = np.abs(e)
    mae = float(ae.mean())
    mad = float(np.mean(np.abs(y - y.mean())))
    return {
        "n": int(len(y)), "mae": mae, "rmse": float(np.sqrt(np.mean(e * e))),
        "mad": mad, "mad_mae": float(mad / mae) if mae > 0 else np.inf,
        "median_ae": float(np.median(ae)), "p90_ae": float(np.percentile(ae, 90)),
        "mean_signed_error": float(e.mean()),
    }


def bootstrap(y: np.ndarray, p: np.ndarray, n_boot: int, seed: int) -> Dict[str, float]:
    mask = np.isfinite(y) & np.isfinite(p)
    y, p = y[mask].astype(float), p[mask].astype(float)
    n = len(y)
    if n < 2 or n_boot <= 0:
        return {}
    rng = np.random.default_rng(seed)
    mae_d = np.empty(n_boot)
    ratio_d = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        ys, ps = y[idx], p[idx]
        mae = float(np.mean(np.abs(ps - ys)))
        mad = float(np.mean(np.abs(ys - ys.mean())))
        mae_d[i] = mae
        ratio_d[i] = mad / mae if mae > 0 else np.nan
    return {
        "mae_ci_low": float(np.nanpercentile(mae_d, 2.5)),
        "mae_ci_high": float(np.nanpercentile(mae_d, 97.5)),
        "mad_mae_ci_low": float(np.nanpercentile(ratio_d, 2.5)),
        "mad_mae_ci_high": float(np.nanpercentile(ratio_d, 97.5)),
    }


def paired_bootstrap(y: np.ndarray, pa: np.ndarray, pb: np.ndarray,
                     n_boot: int, seed: int) -> Dict[str, float]:
    """Candidate A versus baseline B. Positive improvement values favor A."""
    mask = np.isfinite(y) & np.isfinite(pa) & np.isfinite(pb)
    y, pa, pb = y[mask], pa[mask], pb[mask]
    n = len(y)
    if n == 0:
        return {"n": 0}
    ae_a, ae_b = np.abs(pa - y), np.abs(pb - y)
    mae_a, mae_b = float(ae_a.mean()), float(ae_b.mean())
    mad = float(np.mean(np.abs(y - y.mean())))
    ratio_a = mad / mae_a if mae_a > 0 else np.inf
    ratio_b = mad / mae_b if mae_b > 0 else np.inf
    out = {
        "n": n,
        "mae_candidate": mae_a, "mae_baseline": mae_b,
        "mae_improvement_baseline_minus_candidate": mae_b - mae_a,
        "mad_mae_candidate": ratio_a, "mad_mae_baseline": ratio_b,
        "mad_mae_improvement_candidate_minus_baseline": ratio_a - ratio_b,
        "candidate_row_wins": int(np.sum(ae_a < ae_b)),
        "baseline_row_wins": int(np.sum(ae_b < ae_a)),
        "ties": int(np.sum(np.isclose(ae_a, ae_b, rtol=0, atol=1e-12))),
    }
    if n_boot <= 0 or n < 2:
        return out
    rng = np.random.default_rng(seed)
    d_mae = np.empty(n_boot)
    d_ratio = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, n)
        ys, aa, bb = y[idx], pa[idx], pb[idx]
        ma = float(np.mean(np.abs(aa - ys)))
        mb = float(np.mean(np.abs(bb - ys)))
        md = float(np.mean(np.abs(ys - ys.mean())))
        d_mae[i] = mb - ma
        d_ratio[i] = (md / ma if ma > 0 else np.nan) - (md / mb if mb > 0 else np.nan)
    out.update({
        "mae_improvement_ci_low": float(np.nanpercentile(d_mae, 2.5)),
        "mae_improvement_ci_high": float(np.nanpercentile(d_mae, 97.5)),
        "mad_mae_improvement_ci_low": float(np.nanpercentile(d_ratio, 2.5)),
        "mad_mae_improvement_ci_high": float(np.nanpercentile(d_ratio, 97.5)),
        "bootstrap_probability_candidate_lower_mae": float(np.mean(d_mae > 0)),
    })
    return out


def load_manifest(path: Path, mod) -> pd.DataFrame:
    raw = pd.read_csv(path)
    required = ["benchmark_row_id", "source_material_id", "structure_path", "k_total"]
    missing = [c for c in required if c not in raw.columns]
    if missing:
        raise ValueError(f"Tier-2 manifest missing columns: {missing}")
    if raw["benchmark_row_id"].astype(str).duplicated().any():
        raise ValueError("Duplicate benchmark_row_id values")
    df = pd.DataFrame(index=raw.index)
    df["benchmark_row_id"] = raw["benchmark_row_id"].astype(str)
    df["source_material_id"] = raw["source_material_id"].astype(str)
    df["source"] = raw.get("source_database", pd.Series("ExternalTier2", index=raw.index)).astype(str)
    atoms = []
    from pymatgen.core import Structure
    for v in raw["structure_path"]:
        p = Path(str(v))
        if not p.is_absolute():
            p = path.parent / p
        try:
            s = Structure.from_file(str(p))
            ja = mod.JarvisAtomsAdaptor.get_atoms(s)
            atoms.append(json.dumps(ja.to_dict()))
        except Exception:
            atoms.append(None)
    df["atoms_dict"] = atoms
    df["has_structure"] = df["atoms_dict"].notna()
    formulas = []
    for a in atoms:
        try:
            formulas.append(mod.JAtoms.from_dict(json.loads(a)).composition.reduced_formula)
        except Exception:
            formulas.append(None)
    supplied = raw.get("formula", pd.Series("", index=raw.index)).astype(str)
    df["formula"] = [f if f else supplied.iloc[i] for i, f in enumerate(formulas)]
    for c in ["k_total", "band_gap", "formation_energy_per_atom", "k_electronic", "k_ionic"]:
        df[c] = pd.to_numeric(raw[c], errors="coerce") if c in raw.columns else np.nan
    df["k_total_log"] = np.nan
    valid_k = df["k_total"].notna() & (df["k_total"] > 0)
    df.loc[valid_k, "k_total_log"] = np.log(df.loc[valid_k, "k_total"])
    df["functional_code"] = pd.to_numeric(raw.get("functional_code", 1), errors="coerce").fillna(1).astype(int)
    df["dft_functional"] = raw.get("dft_functional", pd.Series("PBE_VASP_DFPT", index=raw.index)).astype(str)
    df["is_molecule"] = False
    df["tier"] = 2
    df["row_hash"] = [hashlib.md5(f"T2EXT_{x}".encode()).hexdigest()[:12] for x in df["benchmark_row_id"]]
    if (~df["has_structure"]).any():
        bad = df.loc[~df["has_structure"], "benchmark_row_id"].head(10).tolist()
        raise ValueError(f"Invalid structures: {int((~df['has_structure']).sum())}; examples={bad}")
    if df["k_total_log"].notna().sum() == 0:
        raise ValueError("No valid positive k_total labels")
    return df.reset_index(drop=True)


def overlap_audit(df: pd.DataFrame, mod, cache: Path, out: Path, policy: str) -> pd.DataFrame:
    if policy == "off":
        x = df.copy(); x["is_strict_external"] = True
        pd.DataFrame({
            "benchmark_row_id": x["benchmark_row_id"], "formula": x["formula"],
            "is_overlap": False, "matched_training_id": "", "matched_training_source": "",
            "matched_training_formula": "", "match_method": "off",
        }).to_csv(out / "tier2_external_overlap_audit.csv", index=False)
        return x
    if not cache.exists():
        raise FileNotFoundError(f"Tier-2 cache not found: {cache}")
    train = pd.read_hdf(cache, key="data")
    train = train[train.get("atoms_dict", pd.Series(index=train.index, dtype=object)).notna()].copy()
    from pymatgen.analysis.structure_matcher import StructureMatcher
    matcher = StructureMatcher(ltol=0.2, stol=0.3, angle_tol=5)
    groups = {str(k): g for k, g in train.groupby("formula", dropna=False)}
    rows, overlap_ids = [], set()
    for _, er in tqdm(df.iterrows(), total=len(df), desc="Tier-2 overlap audit"):
        bid, formula = str(er["benchmark_row_id"]), str(er["formula"])
        matched = None
        estr = mod.TierDatasetBuilder._atoms_json_to_pymatgen(er["atoms_dict"])
        cand = groups.get(formula)
        if estr is not None and cand is not None:
            for _, tr in cand.iterrows():
                tstr = mod.TierDatasetBuilder._atoms_json_to_pymatgen(tr.get("atoms_dict"))
                if tstr is None:
                    continue
                try:
                    if matcher.fit(estr, tstr):
                        matched = tr
                        break
                except Exception:
                    continue
        is_ov = matched is not None
        if is_ov:
            overlap_ids.add(bid)
        rows.append({
            "benchmark_row_id": bid, "formula": formula, "is_overlap": is_ov,
            "matched_training_id": "" if matched is None else str(matched.get("jid", matched.get("mp_id", matched.get("row_hash", "?")))),
            "matched_training_source": "" if matched is None else str(matched.get("source", "")),
            "matched_training_formula": "" if matched is None else str(matched.get("formula", "")),
            "match_method": "structure_match_same_reduced_formula" if is_ov else "none",
        })
    audit = pd.DataFrame(rows)
    audit.to_csv(out / "tier2_external_overlap_audit.csv", index=False)
    n = int(audit.is_overlap.sum())
    if n and policy == "fail":
        raise RuntimeError(f"{n} Tier-2 training overlaps found")
    x = df.copy()
    x["is_strict_external"] = ~x["benchmark_row_id"].isin(overlap_ids)
    return x


def infer_checkpoint(df: pd.DataFrame, mod, checkpoint: Path, batch_size: int,
                     num_workers: int, device: str, label: str) -> Dict[str, Dict[int, float]]:
    heads = ["k_total_log", "band_gap", "formation_energy_per_atom"]
    ds = mod.HighKGraphDataset(df, target_col="k_total_log",
                              aux_cols=["band_gap", "formation_energy_per_atom"])
    valid_any = df["has_structure"] & df["atoms_dict"].notna() & df[heads].notna().any(axis=1)
    ds.valid_idx = df[valid_any].index.tolist()
    dl = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=num_workers,
                    collate_fn=mod.HighKGraphDataset.collate_fn, drop_last=False)
    model = mod.HighKALIGNN(n_output_tasks=len(heads), task_names=heads)
    ckpt = mod.safe_load_checkpoint(checkpoint, map_location="cpu")
    if ckpt is None:
        raise RuntimeError(f"Cannot load checkpoint {checkpoint}")
    state = mod._remap_state_dict(ckpt["model_state_dict"])
    missing, unexpected = model.load_state_dict(state, strict=False)
    miss_heads = [k for k in missing if k.startswith("task_heads.") and any(f"task_heads.{h}." in k for h in heads)]
    if miss_heads:
        raise RuntimeError(f"{label} checkpoint missing required heads: {miss_heads[:10]}")
    print(f"{label} checkpoint load: missing={len(missing)} unexpected={len(unexpected)}")
    model.to(device).eval()
    pred = {h: {} for h in heads}
    with torch.inference_mode():
        for batch in tqdm(dl, desc=f"{label} external inference"):
            if batch is None:
                continue
            g, lg = batch["graph"].to(device), batch["line_graph"].to(device)
            fc = batch.get("functional_code")
            if fc is not None:
                fc = fc.to(device)
            outputs = model.forward_all_tasks(g, lg, proc_context=None, stack_context=None,
                                              functional_code=fc)
            ids = batch["row_indices"].tolist()
            for h, tensor in outputs.items():
                vals = tensor.detach().cpu().reshape(-1).numpy()
                for ri, v in zip(ids, vals):
                    pred[h][int(ri)] = float(v)
    return pred


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--pipeline", required=True, type=Path,
                    help="v4.60.3 training Python file")
    ap.add_argument("--manifest", required=True, type=Path)
    ap.add_argument("--expected-hash", default=None)
    ap.add_argument("--tier2-weights", required=True, type=Path)
    ap.add_argument("--tier1-weights", type=Path, default=None,
                    help="Optional baseline checkpoint for paired Tier-2 improvement analysis")
    ap.add_argument("--outdir", required=True, type=Path)
    ap.add_argument("--overlap-policy", choices=["exclude", "report", "fail", "off"], default="exclude")
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--num-workers", type=int, default=4)
    ap.add_argument("--n-boot", type=int, default=10000)
    args = ap.parse_args()

    out = args.outdir.resolve(); out.mkdir(parents=True, exist_ok=True)
    actual_hash = sha256_file(args.manifest)
    if args.expected_hash and actual_hash.lower() != args.expected_hash.lower():
        raise RuntimeError(f"Manifest hash mismatch expected={args.expected_hash} actual={actual_hash}")
    mod = load_pipeline(args.pipeline.resolve())
    # Prevent accidental DDP invocation.
    if int(getattr(mod, "_DIST", {}).get("world", 1)) != 1:
        raise RuntimeError("Use single-process python, not torchrun")
    df = load_manifest(args.manifest.resolve(), mod)
    flow = {
        "manifest_rows_raw": len(df),
        "k_total_labels_manifest": int(df.k_total.notna().sum()),
        "band_gap_labels_manifest": int(df.band_gap.notna().sum()),
        "formation_energy_labels_manifest": int(df.formation_energy_per_atom.notna().sum()),
    }
    df = overlap_audit(df, mod, mod.TierDatasetBuilder.TIER_PATHS[2], out, args.overlap_policy)
    flow["rows_all_benchmark"] = len(df)
    flow["rows_overlap_matched"] = int((~df.is_strict_external).sum())
    flow["rows_strict_external"] = int(df.is_strict_external.sum())
    flow["rows_removed_by_overlap_policy"] = flow["rows_overlap_matched"] if args.overlap_policy == "exclude" else 0

    device = "cuda" if torch.cuda.is_available() else "cpu"
    predictions = {"tier2": infer_checkpoint(df, mod, args.tier2_weights, args.batch_size, args.num_workers, device, "Tier-2")}
    if args.tier1_weights:
        predictions["tier1"] = infer_checkpoint(df, mod, args.tier1_weights, args.batch_size, args.num_workers, device, "Tier-1")

    audit_rows = []
    for model_label, pmap in predictions.items():
        for ri in df.index:
            for task in ["k_total_log", "band_gap", "formation_energy_per_atom"]:
                y = float(df.at[ri, task]) if pd.notna(df.at[ri, task]) else np.nan
                p = pmap.get(task, {}).get(int(ri), np.nan)
                if not (np.isfinite(y) and np.isfinite(p)):
                    continue
                audit_rows.append({
                    "model": model_label,
                    "benchmark_row_id": df.at[ri, "benchmark_row_id"],
                    "source_material_id": df.at[ri, "source_material_id"],
                    "formula": df.at[ri, "formula"], "task": task,
                    "y_true": y, "y_pred": p, "absolute_error": abs(p-y),
                    "is_overlap": not bool(df.at[ri, "is_strict_external"]),
                    "is_strict_external": bool(df.at[ri, "is_strict_external"]),
                })
    pred_df = pd.DataFrame(audit_rows)
    pred_df.to_csv(out / "tier2_external_prediction_audit.csv", index=False)

    metric_rows = []
    populations = [("all_benchmark", None), ("strict_external", True)]
    for model_label in predictions:
        mdf = pred_df[pred_df.model == model_label]
        for pop, strict in populations:
            pdf = mdf if strict is None else mdf[mdf.is_strict_external]
            for task in ["k_total_log", "band_gap", "formation_energy_per_atom"]:
                tdf = pdf[pdf.task == task]
                y = tdf.y_true.to_numpy(float); p = tdf.y_pred.to_numpy(float)
                row = {"model": model_label, "population": pop,
                       "task": task, "scale": "log" if task == "k_total_log" else "native"}
                row.update(metric_arrays(y, p)); row.update(bootstrap(y, p, args.n_boot, 20260804 + len(metric_rows)))
                metric_rows.append(row)
                if task == "k_total_log" and len(y):
                    yl, pl = np.exp(y), np.exp(p)
                    lrow = {"model": model_label, "population": pop, "task": "k_total", "scale": "linear"}
                    lrow.update(metric_arrays(yl, pl)); lrow.update(bootstrap(yl, pl, args.n_boot, 20261804 + len(metric_rows)))
                    metric_rows.append(lrow)
    metrics = pd.DataFrame(metric_rows)
    metrics.to_csv(out / "tier2_external_metrics.csv", index=False)

    paired_rows = []
    if "tier1" in predictions:
        for pop, strict in populations:
            ids = df.index if strict is None else df.index[df.is_strict_external]
            for task, scale in [("k_total_log", "log"), ("k_total", "linear"), ("band_gap", "native")]:
                ys, pa, pb = [], [], []
                source_task = "k_total_log" if task == "k_total" else task
                for ri in ids:
                    y = df.at[ri, source_task]
                    a = predictions["tier2"].get(source_task, {}).get(int(ri), np.nan)
                    b = predictions["tier1"].get(source_task, {}).get(int(ri), np.nan)
                    if task == "k_total" and np.isfinite(y) and np.isfinite(a) and np.isfinite(b):
                        y, a, b = math.exp(y), math.exp(a), math.exp(b)
                    ys.append(y); pa.append(a); pb.append(b)
                res = paired_bootstrap(np.asarray(ys,float), np.asarray(pa,float), np.asarray(pb,float),
                                       args.n_boot, 20262804 + len(paired_rows))
                paired_rows.append({"population": pop, "task": task, "scale": scale,
                                    "candidate": "tier2", "baseline": "tier1", **res})
    paired = pd.DataFrame(paired_rows)
    paired.to_csv(out / "tier2_vs_tier1_paired_bootstrap.csv", index=False)

    flow["rows_with_tier2_k_prediction"] = len(predictions["tier2"]["k_total_log"])
    pd.DataFrame([{"stage": k, "count": int(v)} for k,v in flow.items()]).to_csv(
        out / "tier2_external_dataset_flow_audit.csv", index=False)
    meta = {
        "mode": "tier2_external_eval", "inference_only": True,
        "manifest": str(args.manifest), "manifest_sha256": actual_hash,
        "tier2_checkpoint": str(args.tier2_weights),
        "tier1_baseline_checkpoint": str(args.tier1_weights) if args.tier1_weights else None,
        "overlap_policy": args.overlap_policy, "n_boot": args.n_boot,
        "dataset_flow": flow,
        "harmonization": "k_total = k_electronic + k_ionic; model target = natural_log(k_total)",
    }
    (out / "tier2_external_metadata.json").write_text(json.dumps(meta, indent=2))

    lines = ["# Tier-2 External Dielectric Benchmark", "",
             f"Manifest SHA-256: `{actual_hash}`", "",
             "## Metrics", "",
             "| Model | Population | Task | Scale | N | MAE | RMSE | MAD::MAE | 95% CI MAE | 95% CI MAD::MAE |",
             "|---|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for _, r in metrics.iterrows():
        lines.append(
            f"| {r.model} | {r.population} | {r.task} | {r.scale} | {int(r.n)} | {r.mae:.6f} | {r.rmse:.6f} | {r.mad_mae:.4f} | "
            f"[{r.get('mae_ci_low',np.nan):.6f}, {r.get('mae_ci_high',np.nan):.6f}] | "
            f"[{r.get('mad_mae_ci_low',np.nan):.4f}, {r.get('mad_mae_ci_high',np.nan):.4f}] |"
        )
    if len(paired):
        lines += ["", "## Tier-2 vs Tier-1 Paired Improvement", "",
                  "Positive improvement values favor Tier-2.", "",
                  "| Population | Task | N | MAE improvement | 95% CI | MAD::MAE improvement | 95% CI | P(Tier-2 lower MAE) | Wins T2/T1/Tie |",
                  "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
        for _, r in paired.iterrows():
            lines.append(
                f"| {r.population} | {r.task} | {int(r.get('n',0))} | {r.get('mae_improvement_baseline_minus_candidate',np.nan):.6f} | "
                f"[{r.get('mae_improvement_ci_low',np.nan):.6f}, {r.get('mae_improvement_ci_high',np.nan):.6f}] | "
                f"{r.get('mad_mae_improvement_candidate_minus_baseline',np.nan):.4f} | "
                f"[{r.get('mad_mae_improvement_ci_low',np.nan):.4f}, {r.get('mad_mae_improvement_ci_high',np.nan):.4f}] | "
                f"{r.get('bootstrap_probability_candidate_lower_mae',np.nan):.4f} | "
                f"{int(r.get('candidate_row_wins',0))}/{int(r.get('baseline_row_wins',0))}/{int(r.get('ties',0))} |"
            )
    (out / "tier2_external_summary.md").write_text("\n".join(lines) + "\n")
    print(metrics.to_string(index=False))
    if len(paired):
        print("\nPAIRED TIER2 VS TIER1\n", paired.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
