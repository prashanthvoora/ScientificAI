"""
tier3_bootstrap_ci.core
=======================

Metric + paired-bootstrap primitives for the Tier-3 locked-TEST evaluation.

Design contract
---------------
This module NEVER touches PyTorch, DGL, or a GPU. It operates purely on the
per-row prediction audit CSV that ``highk_alignn_train_v4_60_3`` already writes
at the end of a finetune run:

    reports/tier3_prediction_audit/normal/tier3_best_checkpoint_test_prediction_audit.csv

The headline metric reproduced here is *bit-for-bit* the same formula used by
``evaluate_multitask`` in the training script for a ``*_log`` head, so a point
estimate computed from the CSV must equal the number printed at the end of the
run. That equality is the correctness test for this whole package (see
``selftest.py``).

Headline formula (linear / exp space, SAME test rows):
    y_lin    = exp(k_true_log)
    yhat_lin = exp(k_pred_log)
    mae  = mean(|yhat_lin - y_lin|)
    mad  = mean(|y_lin - mean(y_lin)|)      # MEAN-absolute-deviation form
    MAD:MAE = mad / max(mae, 1e-9)

Nothing in the bootstrap holds MAD fixed: each resample recomputes BOTH mad and
mae from the resampled rows, because MAD:MAE is a ratio whose numerator is a
property of the (resampled) target distribution. Holding MAD fixed would
understate the variance.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict, Any


# --------------------------------------------------------------------------- #
# Column resolution
# --------------------------------------------------------------------------- #
# The audit CSV carries log-space columns as canonical. We also accept a few
# fallbacks so the same tool works if a user hand-exports predictions.
_LOG_TRUE_CANDS = ["k_true_log", "true_log", "target_log", "y_true_log"]
_LOG_PRED_CANDS = ["k_pred_log", "pred_log", "prediction_log", "y_pred_log"]
_LIN_TRUE_CANDS = ["k_true", "k_total", "y_true", "target"]
_LIN_PRED_CANDS = ["k_pred", "prediction", "y_pred"]
_ROWID_CANDS    = ["row_id", "row_index", "row_indices", "id", "index"]


def _first_present(df: pd.DataFrame, cands) -> Optional[str]:
    for c in cands:
        if c in df.columns:
            return c
    return None


@dataclass
class RowData:
    """Aligned per-row arrays extracted from an audit CSV."""
    row_id: np.ndarray          # object/int identifiers, used for pairing
    y_lin: np.ndarray           # linear-space true k
    yhat_lin: np.ndarray        # linear-space predicted k
    material: Optional[np.ndarray] = None
    donor: Optional[np.ndarray] = None
    source_path: str = ""
    used_log_space: bool = True

    def __len__(self) -> int:
        return len(self.y_lin)


def load_rows(path: str, drop_nan: bool = True) -> RowData:
    """Load one prediction audit CSV into aligned linear-space arrays.

    Prefers log-space columns (exponentiated here, exactly as the training
    script does) and falls back to linear columns if log columns are absent.
    """
    df = pd.read_csv(path)

    log_t = _first_present(df, _LOG_TRUE_CANDS)
    log_p = _first_present(df, _LOG_PRED_CANDS)
    rid_c = _first_present(df, _ROWID_CANDS)

    if log_t is not None and log_p is not None:
        y_lin = np.exp(pd.to_numeric(df[log_t], errors="coerce").to_numpy(dtype=float))
        yhat_lin = np.exp(pd.to_numeric(df[log_p], errors="coerce").to_numpy(dtype=float))
        used_log = True
    else:
        lin_t = _first_present(df, _LIN_TRUE_CANDS)
        lin_p = _first_present(df, _LIN_PRED_CANDS)
        if lin_t is None or lin_p is None:
            raise ValueError(
                f"{path}: could not find true/pred columns. "
                f"Looked for log {_LOG_TRUE_CANDS}/{_LOG_PRED_CANDS} "
                f"and linear {_LIN_TRUE_CANDS}/{_LIN_PRED_CANDS}. "
                f"Columns present: {list(df.columns)}"
            )
        y_lin = pd.to_numeric(df[lin_t], errors="coerce").to_numpy(dtype=float)
        yhat_lin = pd.to_numeric(df[lin_p], errors="coerce").to_numpy(dtype=float)
        used_log = False

    n = len(df)
    if rid_c is not None:
        row_id = df[rid_c].to_numpy()
    else:
        # No explicit id: fall back to positional index. Pairing will then
        # require identical row ORDER across the two files (verified later).
        row_id = np.arange(n)

    material = df["material"].to_numpy() if "material" in df.columns else None
    donor = None
    for dc in ("donor_id", "donor", "imputed_from", "jid"):
        if dc in df.columns:
            donor = df[dc].to_numpy()
            break

    rd = RowData(
        row_id=row_id, y_lin=y_lin, yhat_lin=yhat_lin,
        material=material, donor=donor,
        source_path=path, used_log_space=used_log,
    )

    if drop_nan:
        mask = np.isfinite(rd.y_lin) & np.isfinite(rd.yhat_lin)
        if not mask.all():
            rd.row_id = rd.row_id[mask]
            rd.y_lin = rd.y_lin[mask]
            rd.yhat_lin = rd.yhat_lin[mask]
            if rd.material is not None:
                rd.material = rd.material[mask]
            if rd.donor is not None:
                rd.donor = rd.donor[mask]
    return rd


# --------------------------------------------------------------------------- #
# Metrics — reproduce the training-script headline exactly
# --------------------------------------------------------------------------- #
def mae_linear(y_lin: np.ndarray, yhat_lin: np.ndarray) -> float:
    return float(np.mean(np.abs(yhat_lin - y_lin)))


def mad_linear(y_lin: np.ndarray) -> float:
    """MEAN absolute deviation of the (resampled) target distribution."""
    return float(np.mean(np.abs(y_lin - np.mean(y_lin))))


def mad_mae(y_lin: np.ndarray, yhat_lin: np.ndarray) -> float:
    mae = mae_linear(y_lin, yhat_lin)
    mad = mad_linear(y_lin)
    return mad / max(mae, 1e-9)


def point_metrics(rd: RowData) -> Dict[str, float]:
    return {
        "n": int(len(rd)),
        "mae_linear": mae_linear(rd.y_lin, rd.yhat_lin),
        "mad_linear": mad_linear(rd.y_lin),
        "mad_mae": mad_mae(rd.y_lin, rd.yhat_lin),
    }


# --------------------------------------------------------------------------- #
# Bootstrap engine
# --------------------------------------------------------------------------- #
@dataclass
class BootstrapResult:
    metric_name: str
    point: float
    mean: float
    ci_low: float
    ci_high: float
    ci_level: float
    n_boot: int
    n_rows: int
    samples: np.ndarray = field(repr=False, default=None)

    def as_dict(self, keep_samples: bool = False) -> Dict[str, Any]:
        d = {
            "metric_name": self.metric_name,
            "point": self.point,
            "boot_mean": self.mean,
            "ci_low": self.ci_low,
            "ci_high": self.ci_high,
            "ci_level": self.ci_level,
            "n_boot": self.n_boot,
            "n_rows": self.n_rows,
        }
        if keep_samples and self.samples is not None:
            d["samples"] = self.samples.tolist()
        return d


def _percentile_ci(samples: np.ndarray, ci_level: float) -> Tuple[float, float]:
    alpha = (1.0 - ci_level) / 2.0
    lo = float(np.percentile(samples, 100.0 * alpha))
    hi = float(np.percentile(samples, 100.0 * (1.0 - alpha)))
    return lo, hi


def bootstrap_single(
    rd: RowData,
    n_boot: int = 10000,
    ci_level: float = 0.95,
    seed: int = 20260728,
) -> BootstrapResult:
    """Percentile bootstrap CI for MAD:MAE of a single model on fixed TEST.

    Resamples ROWS with replacement; recomputes BOTH mad and mae each draw.
    """
    rng = np.random.default_rng(seed)
    n = len(rd)
    if n < 2:
        raise ValueError(f"Need >= 2 rows to bootstrap; got {n}.")

    y = rd.y_lin
    yhat = rd.yhat_lin
    samples = np.empty(n_boot, dtype=float)
    # Vectorised index draw: (n_boot, n) is fine for n ~ 30 and n_boot ~ 1e4.
    idx = rng.integers(0, n, size=(n_boot, n))
    for b in range(n_boot):
        ib = idx[b]
        yb = y[ib]
        yhb = yhat[ib]
        mae = np.mean(np.abs(yhb - yb))
        mad = np.mean(np.abs(yb - np.mean(yb)))
        samples[b] = mad / max(mae, 1e-9)

    lo, hi = _percentile_ci(samples, ci_level)
    return BootstrapResult(
        metric_name="MAD:MAE",
        point=mad_mae(y, yhat),
        mean=float(np.mean(samples)),
        ci_low=lo, ci_high=hi, ci_level=ci_level,
        n_boot=n_boot, n_rows=n, samples=samples,
    )


@dataclass
class PairedResult:
    """Paired bootstrap for delta MAD:MAE between model A and model B."""
    point_a: float
    point_b: float
    point_delta: float           # A - B  (positive => A has higher MAD:MAE => A better)
    delta_mean: float
    delta_ci_low: float
    delta_ci_high: float
    prob_a_better: float         # fraction of resamples with delta > 0
    prob_b_better: float
    prob_tie: float
    ci_level: float
    n_boot: int
    n_rows: int
    higher_is_better: bool
    delta_samples: np.ndarray = field(repr=False, default=None)

    @property
    def significant(self) -> bool:
        """CI on the difference excludes 0 at the chosen level."""
        return (self.delta_ci_low > 0.0) or (self.delta_ci_high < 0.0)

    def as_dict(self, keep_samples: bool = False) -> Dict[str, Any]:
        d = {
            "point_a": self.point_a,
            "point_b": self.point_b,
            "point_delta_A_minus_B": self.point_delta,
            "delta_boot_mean": self.delta_mean,
            "delta_ci_low": self.delta_ci_low,
            "delta_ci_high": self.delta_ci_high,
            "ci_level": self.ci_level,
            "prob_A_better": self.prob_a_better,
            "prob_B_better": self.prob_b_better,
            "prob_tie": self.prob_tie,
            "significant_at_level": self.significant,
            "n_boot": self.n_boot,
            "n_rows": self.n_rows,
            "higher_is_better": self.higher_is_better,
        }
        if keep_samples and self.delta_samples is not None:
            d["delta_samples"] = self.delta_samples.tolist()
        return d


def align_pair(rd_a: RowData, rd_b: RowData) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Align two RowData by row_id so both models see identical rows.

    Returns (yA, yhatA, yB, yhatB) all length-M in the SAME row order.
    Raises if the intersection is empty or if targets disagree after alignment
    (which would mean the two files are not the same TEST split).
    """
    a_ids = [str(x) for x in rd_a.row_id]
    b_ids = [str(x) for x in rd_b.row_id]
    a_map = {rid: i for i, rid in enumerate(a_ids)}
    b_map = {rid: i for i, rid in enumerate(b_ids)}
    common = [rid for rid in a_ids if rid in b_map]
    if len(common) == 0:
        raise ValueError(
            "No shared row_id between the two prediction files. "
            "Are they the same locked TEST split? "
            f"(A n={len(a_ids)}, B n={len(b_ids)})"
        )
    ia = np.array([a_map[r] for r in common], dtype=int)
    ib = np.array([b_map[r] for r in common], dtype=int)

    yA, yhatA = rd_a.y_lin[ia], rd_a.yhat_lin[ia]
    yB, yhatB = rd_b.y_lin[ib], rd_b.yhat_lin[ib]

    # Targets for the same row_id must match (same TEST). Allow tiny float noise.
    if not np.allclose(yA, yB, rtol=1e-4, atol=1e-4):
        n_bad = int(np.sum(~np.isclose(yA, yB, rtol=1e-4, atol=1e-4)))
        raise ValueError(
            f"Aligned targets disagree on {n_bad}/{len(common)} rows. "
            "The two files are NOT evaluating the same locked TEST rows. "
            "Pairing would be invalid."
        )
    return yA, yhatA, yB, yhatB


def bootstrap_paired(
    rd_a: RowData,
    rd_b: RowData,
    n_boot: int = 10000,
    ci_level: float = 0.95,
    seed: int = 20260728,
    higher_is_better: bool = True,
) -> PairedResult:
    """Paired percentile bootstrap on delta MAD:MAE = MADMAE(A) - MADMAE(B).

    The SAME resampled row indices are used for both models on every draw, so
    shared per-row difficulty cancels and the CI on the difference is tight.
    """
    yA, yhatA, yB, yhatB = align_pair(rd_a, rd_b)
    n = len(yA)
    if n < 2:
        raise ValueError(f"Need >= 2 shared rows to bootstrap; got {n}.")

    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(n_boot, n))
    deltas = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        ib = idx[b]
        # model A on resample
        yAb, yhatAb = yA[ib], yhatA[ib]
        maeA = np.mean(np.abs(yhatAb - yAb))
        madA = np.mean(np.abs(yAb - np.mean(yAb)))
        ratioA = madA / max(maeA, 1e-9)
        # model B on the SAME resample (targets identical, preds differ)
        yhatBb = yhatB[ib]
        maeB = np.mean(np.abs(yhatBb - yAb))       # yAb == yBb by construction
        ratioB = madA / max(maeB, 1e-9)            # same MAD numerator, same rows
        deltas[b] = ratioA - ratioB

    point_a = mad_mae(yA, yhatA)
    point_b = mad_mae(yB, yhatB)
    lo, hi = _percentile_ci(deltas, ci_level)
    prob_a = float(np.mean(deltas > 0))
    prob_b = float(np.mean(deltas < 0))
    prob_t = float(np.mean(deltas == 0))

    return PairedResult(
        point_a=point_a, point_b=point_b,
        point_delta=point_a - point_b,
        delta_mean=float(np.mean(deltas)),
        delta_ci_low=lo, delta_ci_high=hi,
        prob_a_better=prob_a, prob_b_better=prob_b, prob_tie=prob_t,
        ci_level=ci_level, n_boot=n_boot, n_rows=n,
        higher_is_better=higher_is_better,
        delta_samples=deltas,
    )
