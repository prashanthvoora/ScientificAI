# Tier-3 Paired Bootstrap CI (locked TEST)

Standalone, CPU-only analysis tool that puts a confidence interval around the
Tier-3 `MAD:MAE` headline and answers "is model A really better than model B?"
with a **paired** bootstrap on the *same* locked TEST rows.

It does **not** import `torch` / `dgl` and needs **no GPU**. It reads the per-row
prediction audit CSV that `highk_alignn_train_v4_60_3` already writes, so it is
fully decoupled from training — you can run it on the login node, a laptop, or
the lab PC while the GPUs are busy.

---

## 0. Why this order (bootstrap first, global-bias second)

The bootstrap has no dependency on global bias, but *thoroughly testing* global
bias depends on the bootstrap (bias-on vs bias-off is a paired comparison on ~30
rows, where a bare point-estimate delta is inside the noise band). Build the
instrument first; then the very first global-bias run gets a defensible verdict
in one pass. This tool is that instrument.

---

## 1. What it consumes

The TEST audit written at the end of a finetune run:

```
highk_project/reports/tier3_prediction_audit/normal/tier3_best_checkpoint_test_prediction_audit.csv
```

It uses the log-space columns `k_true_log` / `k_pred_log` (and `row_id` for
pairing), exponentiates them, and reproduces the training script's headline
formula **exactly**:

```
y_lin    = exp(k_true_log);  yhat_lin = exp(k_pred_log)
mae      = mean(|yhat_lin - y_lin|)
mad      = mean(|y_lin - mean(y_lin)|)        # mean-abs-deviation form
MAD:MAE  = mad / max(mae, 1e-9)
```

If log columns are absent it falls back to linear `k_true` / `k_pred`.

---

## 2. Install (lab environment)

No new heavy deps — `numpy` + `pandas` are already in your training venv;
`matplotlib` is optional (only for the PNG histograms).

```bash
cd tier3_bootstrap

# Option A: reuse your existing training venv (recommended — deps already there)
python -c "import numpy, pandas; print('ok')"

# Option B: a throwaway venv, if you prefer isolation
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

### Verify correctness before trusting it on real data
```bash
python selftest.py
```
Expect `SELFTEST PASSED — all checks green.` This checks metric parity against a
hand computation, the log/exp round-trip, CI bracketing, the mismatched-TEST
guard, and the identical-model degenerate-delta case (the signature of a
mis-wired no-op).

---

## 3. Run — baseline headline with CI (single mode)

Point it at your three existing seed runs (42 / 124 / 777). It runs 10,000
resamples per file (~0.1 s each on 30 rows) and also aggregates the per-seed
point estimates.

```bash
python run_bootstrap.py single \
  --pred /path/to/seed42/.../tier3_best_checkpoint_test_prediction_audit.csv \
  --pred /path/to/seed124/.../tier3_best_checkpoint_test_prediction_audit.csv \
  --pred /path/to/seed777/.../tier3_best_checkpoint_test_prediction_audit.csv \
  --tag baseline --n-boot 10000 --outdir bootstrap_out
```

Outputs in `bootstrap_out/`:
- `bootstrap_baseline.json` — per-seed point + CI, and cross-seed mean/std/min/max
- `bootstrap_baseline_summary.md` — the table you paste into a report
- `bootstrap_baseline_seed{0,1,2}_hist.png` — resample distributions

> The **per-seed CI** = test-set estimation uncertainty (model fixed, 30 rows).
> The **cross-seed spread** = split + selection variance. They are different
> quantities; report both. Your 1.59 / 1.60 / 1.69 lands in the cross-seed line;
> each seed's CI tells you how sharp that individual number is.

---

## 4. Run — bias ON vs bias OFF (paired mode) — *later, once bias exists*

After you add global bias, produce two TEST audits on the **same locked splits**
(bias-on and bias-off), then:

```bash
python run_bootstrap.py paired \
  --pred-a /path/to/bias_on/.../tier3_best_checkpoint_test_prediction_audit.csv \
  --pred-b /path/to/bias_off/.../tier3_best_checkpoint_test_prediction_audit.csv \
  --tag bias_on_vs_off --n-boot 10000 --outdir bootstrap_out
```

- A = the model you hope is better (bias ON). Higher MAD:MAE is better.
- The tool aligns by `row_id`, verifies the targets match (else it refuses —
  that means the two runs did not share TEST), then bootstraps the **difference**
  with the *same* resample indices for both models.
- Verdict: if `delta CI` excludes 0 → improvement is statistically resolved on
  this TEST; if it includes 0 → the gap is within sampling noise.

A no-op wiring bug (bias-off secretly still training the bias) shows up
unmistakably: identical models give `delta = 0` with a degenerate CI `[0, 0]`
and `P(A better) = P(B better) = 0`.

---

## 5. Reproducibility

- All draws come from `numpy.default_rng(seed)`; the same `--seed` reproduces the
  same CI to the last digit. Default seed `20260728`.
- `--n-boot 10000` is plenty for a 30-row TEST; 2000 already stabilises the
  percentile CI. There is no benefit to GPU here.
- `--ci-level 0.95` by default; pass `0.90` or `0.99` if a reviewer asks.

---

## 6. What to report back

For the baseline: `MAD:MAE = <mean> (per-seed CIs [lo,hi]); cross-seed
min <min>, spread ±<std>`. Cite the min as the conservative number.

For any comparison: `ΔMAD:MAE = <delta> (A−B), 95% CI [lo,hi], P(A better)=<p>,
verdict=<significant/not>`.

Files to attach: the two `*.json` (machine record) and `*_summary.md` (report
table). The JSON is the audit trail; keep it with the run.
