#!/usr/bin/env python3
"""
selftest.py — verifies the bootstrap library on synthetic ground truth BEFORE
you trust it on real TEST audits. Run once in the lab env after install:

    python selftest.py

It checks:
  1. MAD:MAE reproduction matches an independent hand computation exactly.
  2. Log-space CSV round-trips through exp() to the same linear metric.
  3. bootstrap_single: point estimate sits inside its own CI; CI brackets point.
  4. bootstrap_paired on IDENTICAL predictions => delta point == 0 and the
     delta distribution is degenerate at 0 (this is the signature that catches
     a mis-wired "bias-off == bias-on" no-op — if two conditions are secretly
     the same model, the paired delta is exactly 0 with zero spread).
  5. bootstrap_paired where A is strictly better => delta CI excludes 0 and
     P(A better) == 1.0.
  6. align_pair raises when the two files are not the same TEST (targets differ).

Exit code 0 = all pass.
"""
from __future__ import annotations

import sys
import tempfile
import os
import numpy as np
import pandas as pd
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from tier3_bootstrap_ci import core


def _mk_csv(path, row_ids, k_true, k_pred):
    """Write a minimal audit-shaped CSV in LOG space (as the trainer does)."""
    df = pd.DataFrame({
        "row_id": row_ids,
        "k_true_log": np.log(k_true),
        "k_pred_log": np.log(k_pred),
        "material": ["HfO2"] * len(row_ids),
    })
    df.to_csv(path, index=False)


def approx(a, b, tol=1e-9):
    return abs(a - b) < tol


def main():
    rng = np.random.default_rng(0)
    tmp = Path(tempfile.mkdtemp(prefix="t3boot_"))
    fails = []

    # ---- fixture: 30-row TEST, true k in a realistic high-k range ----------
    n = 30
    ids = [f"r{i:03d}" for i in range(n)]
    k_true = rng.uniform(12.0, 45.0, size=n)
    # model A: good; model B: same but with extra noise (strictly worse on avg)
    kA = k_true * np.exp(rng.normal(0, 0.05, size=n))
    kB = k_true * np.exp(rng.normal(0, 0.15, size=n))

    fA = tmp / "A.csv"; _mk_csv(fA, ids, k_true, kA)
    fB = tmp / "B.csv"; _mk_csv(fB, ids, k_true, kB)
    fA2 = tmp / "A_copy.csv"; _mk_csv(fA2, ids, k_true, kA)  # identical to A

    rdA = core.load_rows(str(fA))
    rdB = core.load_rows(str(fB))
    rdA2 = core.load_rows(str(fA2))

    # --- 1 & 2: metric parity vs independent hand computation ---------------
    y = k_true.copy()
    yhat = kA.copy()
    mae_ref = float(np.mean(np.abs(yhat - y)))
    mad_ref = float(np.mean(np.abs(y - np.mean(y))))
    ratio_ref = mad_ref / max(mae_ref, 1e-9)
    ratio_lib = core.mad_mae(rdA.y_lin, rdA.yhat_lin)
    if not approx(ratio_ref, ratio_lib, tol=1e-8):
        fails.append(f"[1] metric parity: ref={ratio_ref:.8f} lib={ratio_lib:.8f}")
    else:
        print(f"[1] metric parity OK: MAD:MAE={ratio_lib:.6f}")

    # log round-trip: y_lin should equal k_true
    if not np.allclose(rdA.y_lin, k_true, rtol=1e-9, atol=1e-9):
        fails.append("[2] log->exp round trip mismatch on true k")
    else:
        print("[2] log/exp round-trip OK")

    # --- 3: single bootstrap sanity -----------------------------------------
    res = core.bootstrap_single(rdA, n_boot=3000, seed=1)
    if not (res.ci_low <= res.point <= res.ci_high):
        fails.append(f"[3] point {res.point:.4f} outside CI [{res.ci_low:.4f},{res.ci_high:.4f}]")
    else:
        print(f"[3] single CI brackets point OK: {res.point:.4f} in "
              f"[{res.ci_low:.4f},{res.ci_high:.4f}]")

    # --- 4: identical models => degenerate zero delta (no-op detector) ------
    pr_id = core.bootstrap_paired(rdA, rdA2, n_boot=3000, seed=2)
    if not (approx(pr_id.point_delta, 0.0, tol=1e-12)
            and approx(pr_id.delta_ci_low, 0.0, tol=1e-12)
            and approx(pr_id.delta_ci_high, 0.0, tol=1e-12)):
        fails.append(f"[4] identical-model delta not degenerate: "
                     f"point={pr_id.point_delta} CI=[{pr_id.delta_ci_low},{pr_id.delta_ci_high}]")
    else:
        print("[4] identical-model paired delta is exactly 0 with zero spread OK "
              "(no-op wiring bug would look like this)")

    # --- 5: A strictly better => significant, P(A better) high --------------
    pr = core.bootstrap_paired(rdA, rdB, n_boot=5000, seed=3)
    if not (pr.point_delta > 0 and pr.prob_a_better > 0.9):
        fails.append(f"[5] expected A better: delta={pr.point_delta:+.4f} "
                     f"P(A)={pr.prob_a_better:.3f}")
    else:
        print(f"[5] A-better detected OK: delta={pr.point_delta:+.4f} "
              f"P(A better)={pr.prob_a_better:.3f} significant={pr.significant}")

    # --- 6: different TEST rows must raise -----------------------------------
    k_true2 = k_true + 5.0  # different targets for same ids
    fC = tmp / "C.csv"; _mk_csv(fC, ids, k_true2, kA)
    rdC = core.load_rows(str(fC))
    try:
        core.align_pair(rdA, rdC)
        fails.append("[6] align_pair did NOT raise on mismatched targets")
    except ValueError:
        print("[6] mismatched-TEST guard raises OK")

    # cleanup
    for f in (fA, fB, fA2, fC):
        try: os.remove(f)
        except OSError: pass
    try: os.rmdir(tmp)
    except OSError: pass

    print("-" * 60)
    if fails:
        print("SELFTEST FAILED:")
        for f in fails:
            print("  " + f)
        return 1
    print("SELFTEST PASSED — all checks green.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
