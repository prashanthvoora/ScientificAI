#!/usr/bin/env python3
"""
find_audits.py — locate Tier-3 TEST prediction audit CSVs under a reports root,
so you don't have to hand-type long paths.

Usage:
    python find_audits.py /path/to/highk_project/reports
    python find_audits.py .            # search current dir recursively

Prints the matching TEST audit files (best_checkpoint, normal split) and a
ready-to-paste `run_bootstrap.py single` command.
"""
from __future__ import annotations
import sys
from pathlib import Path


def main(argv):
    root = Path(argv[1]) if len(argv) > 1 else Path(".")
    if not root.exists():
        print(f"Path not found: {root}")
        return 2

    # Canonical name the trainer writes for the locked TEST at the frozen best ckpt.
    hits = sorted(root.rglob("tier3_best_checkpoint_test_prediction_audit.csv"))
    # Also surface any other *TEST* audits in case of custom stage names.
    other = sorted(
        p for p in root.rglob("*test*prediction_audit.csv")
        if p not in hits
    )

    if not hits and not other:
        print(f"No TEST prediction audit CSVs found under {root}.")
        print("Expected: .../tier3_prediction_audit/normal/"
              "tier3_best_checkpoint_test_prediction_audit.csv")
        return 1

    print("Canonical best-checkpoint TEST audits:")
    for p in hits:
        print(f"  {p}")
    if other:
        print("\nOther TEST audits (check stage name before use):")
        for p in other:
            print(f"  {p}")

    if hits:
        print("\nReady-to-run (edit --tag / add seeds as needed):\n")
        preds = " \\\n  ".join(f"--pred {p}" for p in hits)
        print("python run_bootstrap.py single \\\n  "
              f"{preds} \\\n  --tag baseline --n-boot 10000 --outdir bootstrap_out")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
