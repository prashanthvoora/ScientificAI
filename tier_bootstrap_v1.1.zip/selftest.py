#!/usr/bin/env python3
"""
selftest.py (v1.1) — verifies the bootstrap library on synthetic ground truth
BEFORE trusting it on real TEST audits. Run once after install:

    python selftest.py

Checks:
  1. MAD:MAE reproduction matches an independent hand computation.
  2. Log-space CSV round-trips through exp() to the same linear metric.
  3. bootstrap_single: point sits inside its own CI.
  4. Paired IDENTICAL predictions => delta MAE == 0, degenerate CI (no-op detector).
  5. Paired A strictly better => delta MAE < 0, P(A better) high, CI excludes 0.
  6. Mismatched TEST targets => align_pair raises.
  --- v1.1 safeguards ---
  7. (item 4) Missing row_id in paired mode => raises (positional refused).
  8. (item 3) Duplicate row_id => raises.
  9. (item 3) Partial row-set overlap => raises unless allow_partial.
 10. (item 5) One-sided NaN => raises; NaN-in-both => dropped with note.
 11. (item 1) delta MAE is exposed and sign-consistent with MAD:MAE.

Exit 0 = all pass.
"""
from __future__ import annotations

import sys, tempfile, os
import numpy as np
import pandas as pd
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from tier3_bootstrap_ci import core


def _mk_csv(path, row_ids, k_true, k_pred, with_id=True, extra=None):
    d = {"k_true_log": np.log(k_true), "k_pred_log": np.log(k_pred),
         "material": ["HfO2"] * len(k_true)}
    if with_id:
        d["row_id"] = row_ids
    if extra:
        d.update(extra)
    pd.DataFrame(d).to_csv(path, index=False)


def approx(a, b, tol=1e-9):
    return abs(a - b) < tol


def expect_raise(fn, label, fails, substr=None):
    try:
        fn()
        fails.append(f"{label}: expected ValueError, none raised")
    except ValueError as e:
        if substr and substr.lower() not in str(e).lower():
            fails.append(f"{label}: raised but message lacked '{substr}': {e}")
        else:
            print(f"{label}: raised as expected")
    except Exception as e:
        fails.append(f"{label}: raised {type(e).__name__}, expected ValueError: {e}")


def main():
    rng = np.random.default_rng(0)
    tmp = Path(tempfile.mkdtemp(prefix="t3boot_"))
    fails = []

    n = 30
    ids = [f"r{i:03d}" for i in range(n)]
    k_true = rng.uniform(12.0, 45.0, size=n)
    kA = k_true * np.exp(rng.normal(0, 0.05, size=n))
    kB = k_true * np.exp(rng.normal(0, 0.15, size=n))

    fA = tmp / "A.csv"; _mk_csv(fA, ids, k_true, kA)
    fB = tmp / "B.csv"; _mk_csv(fB, ids, k_true, kB)
    fA2 = tmp / "A_copy.csv"; _mk_csv(fA2, ids, k_true, kA)

    rdA = core.load_rows(str(fA))
    rdB = core.load_rows(str(fB))
    rdA2 = core.load_rows(str(fA2))

    # 1 & 2
    mae_ref = float(np.mean(np.abs(kA - k_true)))
    mad_ref = float(np.mean(np.abs(k_true - np.mean(k_true))))
    ratio_ref = mad_ref / max(mae_ref, 1e-9)
    if not approx(ratio_ref, core.mad_mae(rdA.y_lin, rdA.yhat_lin), tol=1e-8):
        fails.append("[1] metric parity mismatch")
    else:
        print(f"[1] metric parity OK: MAD:MAE={ratio_ref:.6f}")
    if not np.allclose(rdA.y_lin, k_true, rtol=1e-9, atol=1e-9):
        fails.append("[2] log->exp round trip mismatch")
    else:
        print("[2] log/exp round-trip OK")

    # 3
    res = core.bootstrap_single(rdA, n_boot=3000, seed=1)
    if not (res.ci_low <= res.point <= res.ci_high):
        fails.append("[3] point outside its CI")
    else:
        print(f"[3] single CI brackets point OK: {res.point:.4f} in [{res.ci_low:.4f},{res.ci_high:.4f}]")

    # 4 identical => degenerate delta MAE
    pr, _ = core.bootstrap_paired(rdA, rdA2, n_boot=3000, seed=2)
    if not (approx(pr.delta_mae, 0.0, 1e-12)
            and approx(pr.delta_mae_ci_low, 0.0, 1e-12)
            and approx(pr.delta_mae_ci_high, 0.0, 1e-12)):
        fails.append(f"[4] identical delta MAE not degenerate: {pr.delta_mae}")
    else:
        print("[4] identical-model delta MAE == 0 with zero spread OK (no-op detector)")

    # 5 A better
    pr2, _ = core.bootstrap_paired(rdA, rdB, n_boot=5000, seed=3)
    if not (pr2.delta_mae < 0 and pr2.prob_a_better > 0.9):
        fails.append(f"[5] expected A better: dMAE={pr2.delta_mae:+.4f} P(A)={pr2.prob_a_better:.3f}")
    else:
        print(f"[5] A-better OK: dMAE={pr2.delta_mae:+.4f} P(A better)={pr2.prob_a_better:.3f} sig={pr2.mae_significant}")

    # 6 mismatched targets
    fC = tmp / "C.csv"; _mk_csv(fC, ids, k_true + 5.0, kA)
    rdC = core.load_rows(str(fC))
    expect_raise(lambda: core.align_pair(rdA, rdC), "[6] mismatched-TEST", fails, "disagree")

    # 7 missing row_id in paired mode
    fNo = tmp / "noid.csv"; _mk_csv(fNo, ids, k_true, kA, with_id=False)
    rdNo = core.load_rows(str(fNo))
    if rdNo.had_row_id:
        fails.append("[7] had_row_id should be False when no id column")
    expect_raise(lambda: core.bootstrap_paired(rdNo, rdB, n_boot=10),
                 "[7] missing-row_id paired", fails, "row_id")

    # 8 duplicate ids
    dup_ids = ids.copy(); dup_ids[5] = dup_ids[4]
    fDup = tmp / "dup.csv"; _mk_csv(fDup, dup_ids, k_true, kA)
    rdDup = core.load_rows(str(fDup))
    expect_raise(lambda: core.align_pair(rdDup, rdB), "[8] duplicate-id", fails, "duplicate")

    # 9 partial overlap
    ids_short = [f"r{i:03d}" for i in range(2, n)]  # drop first 2
    fShort = tmp / "short.csv"; _mk_csv(fShort, ids_short, k_true[2:], kA[2:])
    rdShort = core.load_rows(str(fShort))
    expect_raise(lambda: core.align_pair(rdA, rdShort), "[9] partial-overlap", fails, "mismatch")
    # allow_partial should succeed
    try:
        yA, yhatA, yB, yhatB, notes = core.align_pair(rdA, rdShort, allow_partial=True)
        if len(yA) == (n - 2) and any("allow_partial" in nt for nt in notes):
            print("[9b] allow_partial intersection OK (n=%d, noted)" % len(yA))
        else:
            fails.append(f"[9b] allow_partial unexpected: n={len(yA)} notes={notes}")
    except Exception as e:
        fails.append(f"[9b] allow_partial should not raise: {e}")

    # 10 one-sided NaN vs NaN-in-both
    kA_nan = kA.copy(); kA_nan[7] = np.nan   # NaN in A only
    fAnan = tmp / "Anan.csv"; _mk_csv(fAnan, ids, k_true, kA_nan)
    rdAnan = core.load_rows(str(fAnan))
    expect_raise(lambda: core.align_pair(rdAnan, rdB), "[10] one-sided-NaN", fails, "one-sided")
    # NaN in both at same row => dropped with note
    kB_nan = kB.copy(); kB_nan[7] = np.nan
    fBnan = tmp / "Bnan.csv"; _mk_csv(fBnan, ids, k_true, kB_nan)
    rdBnan = core.load_rows(str(fBnan))
    try:
        yA, yhatA, yB, yhatB, notes = core.align_pair(rdAnan, rdBnan)
        if len(yA) == (n - 1) and any("BOTH" in nt for nt in notes):
            print("[10b] NaN-in-both dropped with note OK (n=%d)" % len(yA))
        else:
            fails.append(f"[10b] NaN-in-both unexpected: n={len(yA)} notes={notes}")
    except Exception as e:
        fails.append(f"[10b] NaN-in-both should not raise: {e}")

    # 11 delta MAE sign consistency with MAD:MAE
    #   A better => delta_mae < 0 AND delta_madmae > 0
    if not (pr2.delta_mae < 0 and pr2.delta_madmae > 0):
        fails.append(f"[11] sign inconsistency: dMAE={pr2.delta_mae:+.4f} dMM={pr2.delta_madmae:+.4f}")
    else:
        print(f"[11] delta MAE / MAD:MAE sign-consistent OK "
              f"(dMAE={pr2.delta_mae:+.4f}<0, dMM={pr2.delta_madmae:+.4f}>0)")

    # cleanup
    for f in tmp.glob("*.csv"):
        try: os.remove(f)
        except OSError: pass
    try: os.rmdir(tmp)
    except OSError: pass

    print("-" * 60)
    if fails:
        print("SELFTEST FAILED:")
        for f in fails:
            print("  " + f)
        return 1
    print("SELFTEST PASSED — all checks green.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
