"""
tier3_bootstrap_ci.core  (v1.1)
===============================

Metric + paired-bootstrap primitives for the Tier-3 locked-TEST evaluation.

CPU-only. No torch / dgl / GPU. Operates purely on the per-row prediction audit
CSV that highk_alignn_train_v4_60_4 writes:

    reports/tier3_prediction_audit/normal/tier3_best_checkpoint_test_prediction_audit.csv

Headline metric reproduced here bit-for-bit (linear/exp space, SAME test rows):
    y_lin    = exp(k_true_log);  yhat_lin = exp(k_pred_log)
    mae  = mean(|yhat_lin - y_lin|)
    mad  = mean(|y_lin - mean(y_lin)|)      # MEAN-absolute-deviation form
    MAD:MAE = mad / max(mae, 1e-9)

v1.1 review-driven changes
--------------------------
(1) delta MAE is now a first-class paired statistic (and the *primary* one):
    in the paired bootstrap MAD is identical for A and B on every resample
    (shared targets), so delta MAD:MAE is driven entirely by the MAE
    difference. delta MAE is the more direct, more stable quantity; delta
    MAD:MAE is retained for continuity with the headline.
(3) align_pair is hardened: duplicate row_ids -> error; partial overlap ->
    error unless explicitly allowed; order-independent alignment by id.
(4) Paired validation REQUIRES genuine row_ids. The positional-index fallback
    (fine for single mode) is refused for pairing, because it would silently
    align by row ORDER and assume the two files list the same rows.
(5) NaN handling is alignment-safe: instead of dropping NaN per file *before*
    pairing (which can silently shrink the intersection differently in A vs B),
    RowData records a NaN mask; align_pair drops a row only when it is NaN in
    BOTH files, and ERRORS on a one-sided NaN (valid in one, missing in the
    other) so a failed prediction cannot quietly change the paired row set.

(2) The adapter-delta columns are diagnostic, not part of the metric; they are
    surfaced by component_summary()/the runner, not consumed by the metric.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict, Any, List


# --------------------------------------------------------------------------- #
# Column resolution
# --------------------------------------------------------------------------- #
_LOG_TRUE_CANDS = ["k_true_log", "true_log", "target_log", "y_true_log"]
_LOG_PRED_CANDS = ["k_pred_log", "pred_log", "prediction_log", "y_pred_log"]
_LIN_TRUE_CANDS = ["k_true", "k_total", "y_true", "target"]
_LIN_PRED_CANDS = ["k_pred", "prediction", "y_pred"]
_ROWID_CANDS    = ["row_id", "split_identity", "dataset_row_idx", "row_index",
                   "row_indices", "id", "index"]

# Diagnostic decomposition columns (v4.60.4). Surfaced, not used in the metric.
_COMPONENT_CANDS = [
    "structural_adapter_delta",
    "bounded_process_delta",
    "family_offset_delta",
    "raw_process_delta",
    "delta_log_pred",
]


def _first_present(df: pd.DataFrame, cands) -> Optional[str]:
    for c in cands:
        if c in df.columns:
            return c
    return None


@dataclass
class RowData:
    """Aligned per-row arrays extracted from an audit CSV."""
    row_id: np.ndarray          # identifiers used for pairing
    y_lin: np.ndarray           # linear-space true k (may contain NaN in v1.1)
    yhat_lin: np.ndarray        # linear-space predicted k (may contain NaN)
    valid: np.ndarray           # bool mask: finite y AND finite yhat
    had_row_id: bool = False    # True iff a real id column was present
    material: Optional[np.ndarray] = None
    donor: Optional[np.ndarray] = None
    components: Dict[str, np.ndarray] = field(default_factory=dict)
    source_path: str = ""
    used_log_space: bool = True

    def __len__(self) -> int:
        return len(self.y_lin)

    def n_valid(self) -> int:
        return int(self.valid.sum())

    def valid_view(self) -> "RowData":
        """Return a copy restricted to valid rows (for single-model use)."""
        m = self.valid
        return RowData(
            row_id=self.row_id[m], y_lin=self.y_lin[m], yhat_lin=self.yhat_lin[m],
            valid=np.ones(int(m.sum()), dtype=bool), had_row_id=self.had_row_id,
            material=None if self.material is None else self.material[m],
            donor=None if self.donor is None else self.donor[m],
            components={k: v[m] for k, v in self.components.items()},
            source_path=self.source_path, used_log_space=self.used_log_space,
        )


def load_rows(path: str) -> RowData:
    """Load one prediction audit CSV into aligned linear-space arrays.

    v1.1: does NOT drop NaN rows here. Instead it records a ``valid`` mask so
    downstream code can handle NaN in a pairing-safe way. Single-model callers
    should use ``rd.valid_view()``; the paired path handles masks jointly.
    """
    df = pd.read_csv(path)

    log_t = _first_present(df, _LOG_TRUE_CANDS)
    log_p = _first_present(df, _LOG_PRED_CANDS)
    rid_c = _first_present(df, _ROWID_CANDS)

    if log_t is not None and log_p is not None:
        y_lin = np.exp(pd.to_numeric(df[log_t], errors="coerce").to_numpy(dtype=float))
        yhat_lin = np.exp(pd.to_numeric(df[log_p], errors="coerce").to_numpy(dtype=float))
        used_log = True
    else:
        lin_t = _first_present(df, _LIN_TRUE_CANDS)
        lin_p = _first_present(df, _LIN_PRED_CANDS)
        if lin_t is None or lin_p is None:
            raise ValueError(
                f"{path}: could not find true/pred columns. "
                f"Looked for log {_LOG_TRUE_CANDS}/{_LOG_PRED_CANDS} "
                f"and linear {_LIN_TRUE_CANDS}/{_LIN_PRED_CANDS}. "
                f"Columns present: {list(df.columns)}"
            )
        y_lin = pd.to_numeric(df[lin_t], errors="coerce").to_numpy(dtype=float)
        yhat_lin = pd.to_numeric(df[lin_p], errors="coerce").to_numpy(dtype=float)
        used_log = False

    n = len(df)
    had_row_id = rid_c is not None
    if had_row_id:
        row_id = df[rid_c].to_numpy()
    else:
        # Positional fallback: OK for single mode, REFUSED for pairing (see
        # align_pair). had_row_id=False records that these are not real ids.
        row_id = np.arange(n)

    valid = np.isfinite(y_lin) & np.isfinite(yhat_lin)

    material = df["material"].to_numpy() if "material" in df.columns else None
    donor = None
    for dc in ("donor_id", "donor", "imputed_from", "jid"):
        if dc in df.columns:
            donor = df[dc].to_numpy()
            break

    components: Dict[str, np.ndarray] = {}
    for c in _COMPONENT_CANDS:
        if c in df.columns:
            components[c] = pd.to_numeric(df[c], errors="coerce").to_numpy(dtype=float)

    return RowData(
        row_id=row_id, y_lin=y_lin, yhat_lin=yhat_lin, valid=valid,
        had_row_id=had_row_id, material=material, donor=donor,
        components=components, source_path=path, used_log_space=used_log,
    )


# --------------------------------------------------------------------------- #
# Metrics
# --------------------------------------------------------------------------- #
def mae_linear(y_lin: np.ndarray, yhat_lin: np.ndarray) -> float:
    return float(np.mean(np.abs(yhat_lin - y_lin)))


def mad_linear(y_lin: np.ndarray) -> float:
    return float(np.mean(np.abs(y_lin - np.mean(y_lin))))


def mad_mae(y_lin: np.ndarray, yhat_lin: np.ndarray) -> float:
    mae = mae_linear(y_lin, yhat_lin)
    mad = mad_linear(y_lin)
    return mad / max(mae, 1e-9)


def point_metrics(rd: RowData) -> Dict[str, float]:
    v = rd.valid_view()
    return {
        "n": int(len(v)),
        "n_total_rows": int(len(rd)),
        "n_dropped_nan": int(len(rd) - len(v)),
        "mae_linear": mae_linear(v.y_lin, v.yhat_lin),
        "mad_linear": mad_linear(v.y_lin),
        "mad_mae": mad_mae(v.y_lin, v.yhat_lin),
    }


def component_summary(rd: RowData) -> Dict[str, Dict[str, float]]:
    """Review item (2): surface the diagnostic decomposition columns.

    Reports, per available component, mean / mean|.| / max|.| over valid rows.
    Not part of the metric — purely to make the adapter/process/family
    contributions visible instead of ignored.
    """
    v = rd.valid_view()
    out: Dict[str, Dict[str, float]] = {}
    for name, arr in v.components.items():
        a = arr[np.isfinite(arr)]
        if a.size == 0:
            continue
        out[name] = {
            "mean": float(np.mean(a)),
            "mean_abs": float(np.mean(np.abs(a))),
            "max_abs": float(np.max(np.abs(a))),
        }
    return out


# --------------------------------------------------------------------------- #
# Bootstrap engine
# --------------------------------------------------------------------------- #
@dataclass
class BootstrapResult:
    metric_name: str
    point: float
    mean: float
    ci_low: float
    ci_high: float
    ci_level: float
    n_boot: int
    n_rows: int
    samples: np.ndarray = field(repr=False, default=None)

    def as_dict(self, keep_samples: bool = False) -> Dict[str, Any]:
        d = {
            "metric_name": self.metric_name,
            "point": self.point,
            "boot_mean": self.mean,
            "ci_low": self.ci_low,
            "ci_high": self.ci_high,
            "ci_level": self.ci_level,
            "n_boot": self.n_boot,
            "n_rows": self.n_rows,
        }
        if keep_samples and self.samples is not None:
            d["samples"] = self.samples.tolist()
        return d


def _percentile_ci(samples: np.ndarray, ci_level: float) -> Tuple[float, float]:
    alpha = (1.0 - ci_level) / 2.0
    lo = float(np.percentile(samples, 100.0 * alpha))
    hi = float(np.percentile(samples, 100.0 * (1.0 - alpha)))
    return lo, hi


def bootstrap_single(
    rd: RowData,
    n_boot: int = 10000,
    ci_level: float = 0.95,
    seed: int = 20260728,
) -> BootstrapResult:
    """Percentile bootstrap CI for MAD:MAE of a single model on fixed TEST."""
    v = rd.valid_view()
    n = len(v)
    if n < 2:
        raise ValueError(f"Need >= 2 valid rows to bootstrap; got {n}.")

    rng = np.random.default_rng(seed)
    y, yhat = v.y_lin, v.yhat_lin
    idx = rng.integers(0, n, size=(n_boot, n))
    samples = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        ib = idx[b]
        yb = y[ib]
        yhb = yhat[ib]
        mae = np.mean(np.abs(yhb - yb))
        mad = np.mean(np.abs(yb - np.mean(yb)))
        samples[b] = mad / max(mae, 1e-9)

    lo, hi = _percentile_ci(samples, ci_level)
    return BootstrapResult(
        metric_name="MAD:MAE", point=mad_mae(y, yhat), mean=float(np.mean(samples)),
        ci_low=lo, ci_high=hi, ci_level=ci_level, n_boot=n_boot, n_rows=n,
        samples=samples,
    )


@dataclass
class PairedResult:
    """Paired bootstrap for model A vs model B on identical TEST rows.

    v1.1: delta MAE (linear) is the PRIMARY statistic; delta MAD:MAE retained.
    Sign convention:
      - delta_mae = MAE(A) - MAE(B).  NEGATIVE => A lower error => A better.
      - delta_mm  = MAD:MAE(A) - MAD:MAE(B).  POSITIVE => A better.
    prob_a_better is defined consistently (A genuinely lower error).
    """
    n_rows: int
    n_boot: int
    ci_level: float
    mae_a: float
    mae_b: float
    delta_mae: float
    delta_mae_ci_low: float
    delta_mae_ci_high: float
    madmae_a: float
    madmae_b: float
    delta_madmae: float
    delta_madmae_ci_low: float
    delta_madmae_ci_high: float
    prob_a_better: float
    prob_b_better: float
    prob_tie: float
    delta_mae_samples: np.ndarray = field(repr=False, default=None)
    delta_madmae_samples: np.ndarray = field(repr=False, default=None)

    @property
    def mae_significant(self) -> bool:
        return (self.delta_mae_ci_low > 0.0) or (self.delta_mae_ci_high < 0.0)

    @property
    def madmae_significant(self) -> bool:
        return (self.delta_madmae_ci_low > 0.0) or (self.delta_madmae_ci_high < 0.0)

    def as_dict(self, keep_samples: bool = False) -> Dict[str, Any]:
        d = {
            "n_rows": self.n_rows, "n_boot": self.n_boot, "ci_level": self.ci_level,
            "primary_metric": "delta_MAE_linear",
            "mae_a": self.mae_a, "mae_b": self.mae_b,
            "delta_mae_A_minus_B": self.delta_mae,
            "delta_mae_ci_low": self.delta_mae_ci_low,
            "delta_mae_ci_high": self.delta_mae_ci_high,
            "delta_mae_significant": self.mae_significant,
            "madmae_a": self.madmae_a, "madmae_b": self.madmae_b,
            "delta_madmae_A_minus_B": self.delta_madmae,
            "delta_madmae_ci_low": self.delta_madmae_ci_low,
            "delta_madmae_ci_high": self.delta_madmae_ci_high,
            "delta_madmae_significant": self.madmae_significant,
            "prob_A_better": self.prob_a_better,
            "prob_B_better": self.prob_b_better,
            "prob_tie": self.prob_tie,
        }
        if keep_samples:
            if self.delta_mae_samples is not None:
                d["delta_mae_samples"] = self.delta_mae_samples.tolist()
            if self.delta_madmae_samples is not None:
                d["delta_madmae_samples"] = self.delta_madmae_samples.tolist()
        return d


def align_pair(
    rd_a: RowData,
    rd_b: RowData,
    require_row_id: bool = True,
    allow_partial: bool = False,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, List[str]]:
    """Align two RowData by row_id into identical row order.

    v1.1 safeguards (review items 3/4/5):
      (4) require_row_id: refuse positional-index fallback for pairing.
      (3) duplicate ids -> error; partial overlap -> error unless allow_partial.
      (5) NaN handling is joint: a row NaN in BOTH files is dropped (with a
          note); a one-sided NaN is an ERROR.
      target equality on aligned rows is still enforced (same locked TEST).

    Returns (yA, yhatA, yB, yhatB, notes).
    """
    notes: List[str] = []

    if require_row_id and (not rd_a.had_row_id or not rd_b.had_row_id):
        missing = []
        if not rd_a.had_row_id:
            missing.append(f"A({rd_a.source_path})")
        if not rd_b.had_row_id:
            missing.append(f"B({rd_b.source_path})")
        raise ValueError(
            "Paired validation requires a genuine row_id column in BOTH files; "
            f"missing/positional in: {', '.join(missing)}. Positional alignment "
            "is unsafe for pairing (it assumes identical row order). Re-export "
            "the audit with a row_id/split_identity column, or pass "
            "require_row_id=False only if you have independently verified the "
            "two files list the same rows in the same order."
        )

    a_ids = [str(x) for x in rd_a.row_id]
    b_ids = [str(x) for x in rd_b.row_id]

    for tag, ids in (("A", a_ids), ("B", b_ids)):
        seen, dups = set(), set()
        for r in ids:
            if r in seen:
                dups.add(r)
            seen.add(r)
        if dups:
            raise ValueError(
                f"Duplicate row_id(s) in {tag}: {sorted(dups)[:10]}"
                f"{' ...' if len(dups) > 10 else ''}. Row identities must be "
                "unique for pairing."
            )

    a_map = {rid: i for i, rid in enumerate(a_ids)}
    b_map = {rid: i for i, rid in enumerate(b_ids)}
    set_a, set_b = set(a_ids), set(b_ids)
    common = [rid for rid in a_ids if rid in b_map]  # preserve A order

    if len(common) == 0:
        raise ValueError(
            "No shared row_id between the two prediction files. "
            f"Are they the same locked TEST split? (A n={len(a_ids)}, B n={len(b_ids)})"
        )

    only_a = set_a - set_b
    only_b = set_b - set_a
    if (only_a or only_b):
        msg = (
            f"Row-set mismatch: A has {len(only_a)} id(s) not in B, "
            f"B has {len(only_b)} id(s) not in A "
            f"(|A|={len(set_a)}, |B|={len(set_b)}, |common|={len(common)})."
        )
        if not allow_partial:
            raise ValueError(
                msg + " Two runs on the same locked TEST must have identical "
                "row sets. Pass allow_partial=True only if you deliberately "
                "intend to compare on the intersection."
            )
        notes.append("WARNING: " + msg + " Proceeding on intersection (allow_partial).")

    ia = np.array([a_map[r] for r in common], dtype=int)
    ib = np.array([b_map[r] for r in common], dtype=int)

    yA, yhatA = rd_a.y_lin[ia], rd_a.yhat_lin[ia]
    yB, yhatB = rd_b.y_lin[ib], rd_b.yhat_lin[ib]
    validA = rd_a.valid[ia]
    validB = rd_b.valid[ib]

    both_valid = validA & validB
    one_sided = validA ^ validB
    if one_sided.any():
        bad_ids = [common[k] for k in np.where(one_sided)[0]][:10]
        raise ValueError(
            f"One-sided NaN on {int(one_sided.sum())} row(s) "
            f"(valid in one file, missing in the other), e.g. {bad_ids}. "
            "A failed prediction in exactly one model would silently change the "
            "paired row set; refusing. Fix the export or drop those rows in both."
        )
    if not both_valid.all():
        n_drop = int((~both_valid).sum())
        notes.append(f"Dropped {n_drop} row(s) NaN in BOTH files.")
        keep = both_valid
        common = [common[k] for k in np.where(keep)[0]]
        yA, yhatA, yB, yhatB = yA[keep], yhatA[keep], yB[keep], yhatB[keep]

    if not np.allclose(yA, yB, rtol=1e-4, atol=1e-4):
        n_bad = int(np.sum(~np.isclose(yA, yB, rtol=1e-4, atol=1e-4)))
        raise ValueError(
            f"Aligned targets disagree on {n_bad}/{len(common)} rows. The two "
            "files are NOT evaluating the same locked TEST rows. Pairing invalid."
        )
    return yA, yhatA, yB, yhatB, notes


def bootstrap_paired(
    rd_a: RowData,
    rd_b: RowData,
    n_boot: int = 10000,
    ci_level: float = 0.95,
    seed: int = 20260728,
    require_row_id: bool = True,
    allow_partial: bool = False,
) -> Tuple[PairedResult, List[str]]:
    """Paired percentile bootstrap on delta MAE (primary) and delta MAD:MAE.

    Same resampled indices drive both models on every draw, so shared per-row
    difficulty cancels. MAD is identical for A and B per resample (shared
    targets), so delta MAD:MAE is a pure function of the MAE difference — which
    is exactly why delta MAE is the cleaner primary statistic.
    """
    yA, yhatA, yB, yhatB, notes = align_pair(
        rd_a, rd_b, require_row_id=require_row_id, allow_partial=allow_partial
    )
    n = len(yA)
    if n < 2:
        raise ValueError(f"Need >= 2 shared valid rows; got {n}.")

    rng = np.random.default_rng(seed)
    idx = rng.integers(0, n, size=(n_boot, n))
    d_mae = np.empty(n_boot, dtype=float)
    d_mm = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        ib = idx[b]
        yb = yA[ib]                 # == yB[ib] by construction
        maeA = np.mean(np.abs(yhatA[ib] - yb))
        maeB = np.mean(np.abs(yhatB[ib] - yb))
        madb = np.mean(np.abs(yb - np.mean(yb)))
        d_mae[b] = maeA - maeB
        d_mm[b] = (madb / max(maeA, 1e-9)) - (madb / max(maeB, 1e-9))

    mae_a = mae_linear(yA, yhatA)
    mae_b = mae_linear(yB, yhatB)
    mm_a = mad_mae(yA, yhatA)
    mm_b = mad_mae(yB, yhatB)
    lo_mae, hi_mae = _percentile_ci(d_mae, ci_level)
    lo_mm, hi_mm = _percentile_ci(d_mm, ci_level)

    prob_a = float(np.mean(d_mae < 0))   # A better == lower MAE
    prob_b = float(np.mean(d_mae > 0))
    prob_t = float(np.mean(d_mae == 0))

    res = PairedResult(
        n_rows=n, n_boot=n_boot, ci_level=ci_level,
        mae_a=mae_a, mae_b=mae_b, delta_mae=mae_a - mae_b,
        delta_mae_ci_low=lo_mae, delta_mae_ci_high=hi_mae,
        madmae_a=mm_a, madmae_b=mm_b, delta_madmae=mm_a - mm_b,
        delta_madmae_ci_low=lo_mm, delta_madmae_ci_high=hi_mm,
        prob_a_better=prob_a, prob_b_better=prob_b, prob_tie=prob_t,
        delta_mae_samples=d_mae, delta_madmae_samples=d_mm,
    )
    return res, notes
