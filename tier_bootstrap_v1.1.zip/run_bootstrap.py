#!/usr/bin/env python3
"""
run_bootstrap.py — automated paired bootstrap CI on the locked Tier-3 TEST set.

This is a STANDALONE analysis tool. It does not import torch/dgl and does not
need a GPU. It consumes the per-row prediction audit CSV(s) the training script
already writes and emits:

    <outdir>/bootstrap_<tag>.json          machine-readable results
    <outdir>/bootstrap_<tag>_summary.md    human-readable report
    <outdir>/bootstrap_<tag>_hist.png      distribution plot (if matplotlib)

Two modes
---------
1) SINGLE  — CI on MAD:MAE for one model on fixed TEST (use for the baseline
   headline; run once per seed and the tool will also aggregate across seeds).

     python run_bootstrap.py single \
         --pred reports/.../tier3_best_checkpoint_test_prediction_audit.csv \
         --tag baseline_seed42 --n-boot 10000

2) PAIRED  — delta MAD:MAE CI between model A and model B on the SAME TEST rows
   (this is what you'll use for bias-on vs bias-off later).

     python run_bootstrap.py paired \
         --pred-a .../bias_on_test_audit.csv \
         --pred-b .../bias_off_test_audit.csv \
         --tag bias_on_vs_off --n-boot 10000

Multi-seed aggregation (single mode): pass --pred multiple times; the tool runs
each, then reports the per-seed point estimates plus a combined pooled CI.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

# Make the package importable whether run from repo root or elsewhere.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from tier3_bootstrap_ci import core  # noqa: E402


def _try_plot_single(res, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return False
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.hist(res.samples, bins=60, color="#3b6ea5", alpha=0.85, edgecolor="none")
    ax.axvline(res.point, color="k", lw=2, label=f"point = {res.point:.3f}")
    ax.axvline(res.ci_low, color="#c0392b", ls="--", lw=1.5, label=f"CI low = {res.ci_low:.3f}")
    ax.axvline(res.ci_high, color="#c0392b", ls="--", lw=1.5, label=f"CI high = {res.ci_high:.3f}")
    ax.set_xlabel("MAD:MAE (bootstrap resamples)")
    ax.set_ylabel("count")
    ax.set_title(f"Bootstrap MAD:MAE  (n_rows={res.n_rows}, n_boot={res.n_boot})")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return True


def _try_plot_paired(res, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        return False
    # Two panels: primary delta MAE (left), secondary delta MAD:MAE (right).
    fig, (axl, axr) = plt.subplots(1, 2, figsize=(12, 4))

    axl.hist(res.delta_mae_samples, bins=60, color="#4a8a5c", alpha=0.85, edgecolor="none")
    axl.axvline(0.0, color="k", lw=2, label="no difference")
    axl.axvline(res.delta_mae, color="#2c3e50", ls="-", lw=1.5,
                label=f"delta MAE = {res.delta_mae:+.3f}")
    axl.axvline(res.delta_mae_ci_low, color="#c0392b", ls="--", lw=1.5,
                label=f"CI=[{res.delta_mae_ci_low:+.3f}, {res.delta_mae_ci_high:+.3f}]")
    axl.axvline(res.delta_mae_ci_high, color="#c0392b", ls="--", lw=1.5)
    vmae = "SIGNIFICANT" if res.mae_significant else "not significant"
    axl.set_xlabel("delta MAE (A - B); negative => A better")
    axl.set_ylabel("count")
    axl.set_title(f"PRIMARY: delta MAE ({vmae}, n={res.n_rows})")
    axl.legend(fontsize=8)

    axr.hist(res.delta_madmae_samples, bins=60, color="#3b6ea5", alpha=0.85, edgecolor="none")
    axr.axvline(0.0, color="k", lw=2, label="no difference")
    axr.axvline(res.delta_madmae, color="#2c3e50", ls="-", lw=1.5,
                label=f"delta MAD:MAE = {res.delta_madmae:+.3f}")
    axr.axvline(res.delta_madmae_ci_low, color="#c0392b", ls="--", lw=1.5,
                label=f"CI=[{res.delta_madmae_ci_low:+.3f}, {res.delta_madmae_ci_high:+.3f}]")
    axr.axvline(res.delta_madmae_ci_high, color="#c0392b", ls="--", lw=1.5)
    vmm = "SIGNIFICANT" if res.madmae_significant else "not significant"
    axr.set_xlabel("delta MAD:MAE (A - B); positive => A better")
    axr.set_title(f"SECONDARY: delta MAD:MAE ({vmm})")
    axr.legend(fontsize=8)

    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)
    return True


def run_single(args):
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    per_seed = []
    pooled_y = []
    pooled_yhat = []
    for i, p in enumerate(args.pred):
        rd = core.load_rows(p)
        t0 = time.time()
        res = core.bootstrap_single(rd, n_boot=args.n_boot, ci_level=args.ci_level,
                                     seed=args.seed + i)
        dt = time.time() - t0
        pm = core.point_metrics(rd)
        comp = core.component_summary(rd)   # review item (2): surface decomposition
        nan_note = (f"  [dropped {pm['n_dropped_nan']} NaN row(s)]"
                    if pm["n_dropped_nan"] else "")
        print(f"[single] {os.path.basename(p)}  "
              f"n={pm['n']}  MAD:MAE={res.point:.4f}  "
              f"CI[{res.ci_low:.4f},{res.ci_high:.4f}]  ({dt:.1f}s){nan_note}")
        if comp:
            adk = comp.get("structural_adapter_delta")
            if adk:
                print(f"           adapter delta: mean_abs={adk['mean_abs']:.4f} "
                      f"max_abs={adk['max_abs']:.4f}  (log units)")
        per_seed.append({
            "pred_path": p,
            "point_metrics": pm,
            "component_summary": comp,
            "bootstrap": res.as_dict(),
            "seconds": dt,
        })
        pooled_y.append(rd.y_lin)
        pooled_yhat.append(rd.yhat_lin)
        # per-seed plot
        _try_plot_single(res, outdir / f"bootstrap_{args.tag}_seed{i}_hist.png")

    # Cross-seed summary (point estimates)
    points = [s["bootstrap"]["point"] for s in per_seed]
    seed_summary = None
    if len(points) > 1:
        import numpy as np
        seed_summary = {
            "n_seeds": len(points),
            "points": points,
            "mean": float(np.mean(points)),
            "std": float(np.std(points, ddof=1)) if len(points) > 1 else 0.0,
            "min": float(np.min(points)),
            "max": float(np.max(points)),
        }

    result = {
        "mode": "single",
        "tag": args.tag,
        "n_boot": args.n_boot,
        "ci_level": args.ci_level,
        "per_seed": per_seed,
        "seed_summary": seed_summary,
    }

    json_path = outdir / f"bootstrap_{args.tag}.json"
    json_path.write_text(json.dumps(result, indent=2))

    # Markdown
    lines = [f"# Bootstrap MAD:MAE — {args.tag}", ""]
    lines.append(f"- n_boot = {args.n_boot}, CI level = {int(args.ci_level*100)}%, percentile interval")
    lines.append("")
    lines.append("| pred file | n | MAD:MAE (point) | CI low | CI high |")
    lines.append("|---|---|---|---|---|")
    for s in per_seed:
        b = s["bootstrap"]
        lines.append(f"| {os.path.basename(s['pred_path'])} | {b['n_rows']} | "
                     f"{b['point']:.4f} | {b['ci_low']:.4f} | {b['ci_high']:.4f} |")
    if seed_summary:
        lines += ["",
                  "## Across seeds (point estimates)",
                  f"- mean = {seed_summary['mean']:.4f}, "
                  f"std = {seed_summary['std']:.4f}, "
                  f"min = {seed_summary['min']:.4f}, max = {seed_summary['max']:.4f}",
                  f"- points: {', '.join(f'{p:.4f}' for p in seed_summary['points'])}"]
    md_path = outdir / f"bootstrap_{args.tag}_summary.md"
    md_path.write_text("\n".join(lines) + "\n")

    print(f"\nWrote:\n  {json_path}\n  {md_path}")
    return 0


def run_paired(args):
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    rd_a = core.load_rows(args.pred_a)
    rd_b = core.load_rows(args.pred_b)
    t0 = time.time()
    res, notes = core.bootstrap_paired(
        rd_a, rd_b, n_boot=args.n_boot, ci_level=args.ci_level, seed=args.seed,
        require_row_id=not args.allow_positional,
        allow_partial=args.allow_partial,
    )
    dt = time.time() - t0

    vmae = "SIGNIFICANT" if res.mae_significant else "NOT significant"
    print(f"[paired] A={os.path.basename(args.pred_a)}  B={os.path.basename(args.pred_b)}")
    for nt in notes:
        print(f"  note: {nt}")
    print(f"  shared n = {res.n_rows}")
    print(f"  PRIMARY  delta MAE (A-B) = {res.delta_mae:+.4f}  "
          f"CI[{res.delta_mae_ci_low:+.4f}, {res.delta_mae_ci_high:+.4f}] -> {vmae}")
    print(f"           MAE  A={res.mae_a:.4f}  B={res.mae_b:.4f}  "
          f"(negative delta => A better)")
    print(f"  2NDARY   delta MAD:MAE (A-B) = {res.delta_madmae:+.4f}  "
          f"CI[{res.delta_madmae_ci_low:+.4f}, {res.delta_madmae_ci_high:+.4f}]")
    print(f"           MAD:MAE A={res.madmae_a:.4f}  B={res.madmae_b:.4f}")
    print(f"  P(A better)={res.prob_a_better:.3f}  P(B better)={res.prob_b_better:.3f}  ({dt:.1f}s)")

    _try_plot_paired(res, outdir / f"bootstrap_{args.tag}_hist.png")

    result = {
        "mode": "paired",
        "tag": args.tag,
        "pred_a": args.pred_a,
        "pred_b": args.pred_b,
        "n_boot": args.n_boot,
        "ci_level": args.ci_level,
        "notes": notes,
        "component_summary_a": core.component_summary(rd_a),
        "component_summary_b": core.component_summary(rd_b),
        "result": res.as_dict(),
        "seconds": dt,
    }
    json_path = outdir / f"bootstrap_{args.tag}.json"
    json_path.write_text(json.dumps(result, indent=2))

    lines = [f"# Paired bootstrap — {args.tag}", ""]
    lines += [
        f"- A = `{args.pred_a}`",
        f"- B = `{args.pred_b}`",
        f"- shared TEST rows = {res.n_rows}",
        f"- n_boot = {args.n_boot}, CI level = {int(args.ci_level*100)}%",
    ]
    if notes:
        lines += ["", "**Notes:**"] + [f"- {nt}" for nt in notes]
    lines += [
        "",
        "## PRIMARY: delta MAE (linear)  — negative => A better",
        "",
        "| quantity | value |",
        "|---|---|",
        f"| MAE (A) | {res.mae_a:.4f} |",
        f"| MAE (B) | {res.mae_b:.4f} |",
        f"| delta MAE (A - B) | {res.delta_mae:+.4f} |",
        f"| delta MAE CI | [{res.delta_mae_ci_low:+.4f}, {res.delta_mae_ci_high:+.4f}] |",
        f"| P(A better) | {res.prob_a_better:.3f} |",
        f"| P(B better) | {res.prob_b_better:.3f} |",
        f"| verdict | **{vmae}** (CI {'excludes' if res.mae_significant else 'includes'} 0) |",
        "",
        "## SECONDARY: delta MAD:MAE  — positive => A better",
        "",
        "| quantity | value |",
        "|---|---|",
        f"| MAD:MAE (A) | {res.madmae_a:.4f} |",
        f"| MAD:MAE (B) | {res.madmae_b:.4f} |",
        f"| delta MAD:MAE (A - B) | {res.delta_madmae:+.4f} |",
        f"| delta MAD:MAE CI | [{res.delta_madmae_ci_low:+.4f}, {res.delta_madmae_ci_high:+.4f}] |",
        f"| verdict | **{'SIGNIFICANT' if res.madmae_significant else 'NOT significant'}** |",
        "",
        "> delta MAE is the primary statistic: because MAD is identical for A and "
        "B on every paired resample (shared targets), delta MAD:MAE is a pure "
        "function of the MAE difference. If the delta MAE CI excludes 0, the "
        "improvement is statistically resolved on this TEST set.",
    ]
    md_path = outdir / f"bootstrap_{args.tag}_summary.md"
    md_path.write_text("\n".join(lines) + "\n")

    print(f"\nWrote:\n  {json_path}\n  {md_path}")
    return 0


def build_parser():
    p = argparse.ArgumentParser(description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="mode", required=True)

    ps = sub.add_parser("single", help="CI on MAD:MAE for one or more models (per-seed).")
    ps.add_argument("--pred", action="append", required=True,
                    help="Path to a *_test_prediction_audit.csv. Repeat for multiple seeds.")
    ps.add_argument("--tag", default="baseline")
    ps.add_argument("--n-boot", type=int, default=10000)
    ps.add_argument("--ci-level", type=float, default=0.95)
    ps.add_argument("--seed", type=int, default=20260728)
    ps.add_argument("--outdir", default="bootstrap_out")
    ps.set_defaults(func=run_single)

    pp = sub.add_parser("paired", help="Paired delta MAD:MAE CI between two models.")
    pp.add_argument("--pred-a", required=True, help="Model A test audit CSV (e.g. bias ON).")
    pp.add_argument("--pred-b", required=True, help="Model B test audit CSV (e.g. bias OFF).")
    pp.add_argument("--tag", default="A_vs_B")
    pp.add_argument("--n-boot", type=int, default=10000)
    pp.add_argument("--ci-level", type=float, default=0.95)
    pp.add_argument("--seed", type=int, default=20260728)
    pp.add_argument("--outdir", default="bootstrap_out")
    pp.add_argument("--allow-partial", action="store_true",
                    help="Permit pairing on the row_id intersection when the two "
                         "files' row sets differ (default: hard error).")
    pp.add_argument("--allow-positional", action="store_true",
                    help="Permit positional (order-based) pairing when a real "
                         "row_id column is absent. UNSAFE; only if you have "
                         "independently verified identical row order.")
    pp.set_defaults(func=run_paired)
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
