# Changelog

## v1.1.0 — review-driven hardening of the paired path

Addresses five review comments. The **single-mode metric is unchanged**
(byte-identical point + CI vs v1.0), so existing baseline numbers stand and do
not need re-running. All changes are in the paired path and NaN handling.

- **(1) delta MAE is now the PRIMARY paired statistic** (delta MAD:MAE retained
  as secondary). Rationale: in the paired bootstrap MAD is identical for A and B
  on every resample (shared targets), so delta MAD:MAE is a pure function of the
  MAE difference; delta MAE is the more direct, more numerically stable quantity.
  Paired output now reports both, with per-metric CIs and significance.
- **(2) Adapter/process decomposition columns surfaced** (not ignored): single
  mode prints and records `component_summary` (mean / mean_abs / max_abs of
  `structural_adapter_delta`, `bounded_process_delta`, `family_offset_delta`,
  ...). These remain diagnostic only — never part of the metric.
- **(3) align_pair hardened**: duplicate row_ids -> error; partial row-set
  overlap -> error unless `--allow-partial`; order-independent id alignment.
- **(4) Genuine row_id required for pairing**: the positional-index fallback
  (fine for single mode) is refused in paired mode unless `--allow-positional`
  is explicitly passed. Prevents silent order-based mis-pairing.
- **(5) Alignment-safe NaN handling**: NaN rows are no longer dropped per file
  before pairing. A row NaN in BOTH files is dropped (with a note); a one-sided
  NaN (valid in one file, missing in the other) is an ERROR.

New self-tests (11 total) cover every safeguard: positional-fallback rejection,
duplicate ids, partial overlap (+ allow_partial), one-sided vs both-sided NaN,
and delta MAE / MAD:MAE sign consistency.

## v1.0.0 — initial release
Single + paired percentile bootstrap on the locked TEST; metric parity with the
v4.60.x headline; self-test with no-op (identical-model) detector.
