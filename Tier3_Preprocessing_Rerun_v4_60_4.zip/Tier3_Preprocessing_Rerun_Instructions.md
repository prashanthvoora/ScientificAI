# Tier 3 preprocessing rerun

This is a separate v4.60.4 copy of the attached v4.60.3 training script. It addresses item 1 only. Independently trained baselines and publication-grouped CV are subsequent tasks.

## What changed

- Numerical statistics are fitted after final split restoration, using observed finite values from TRAIN only.
- Seven per-field observation indicators are appended: 1 means observed and 0 means missing. Missing numerical inputs become zero after standardization. The process input is 38 dimensions (7 standardized values, 7 indicators, and 24 categorical embedding values).
- Duration and pressure retain the existing log1p transformation. Sample standard deviation is retained; unavailable, singleton or effectively constant fields use scale 1.
- The fixed domain vocabulary is canonicalized without fitting it on any partition. TDMA-Hf/TDMAHf/TDMAH, TEMA-Hf/TEMAH, TDMAZ/TDMAZr, and O2_plasma/O2 plasma merge. Different chemistries, including Hf versus Zr and molecular versus plasma oxygen, remain distinct. Missing and unknown categories have separate indices. Unknown labels appear in the categorical audit for review; they are not silently assigned to known chemistry.
- Categorical values are read as strings. The original numeric helper converted nonnumeric category names to missing values.
- Corrected Tier-3 reloads retain trained categorical embeddings. Original remapping removed those tensors even when reloading Tier-3 checkpoints.
- Row-level prediction audits now include the structural adapter and verify against the actual forward prediction.
- Outputs are isolated through --run_root. The original Tier-2 prior is reused; corrected Tier-3 branches initialize afresh. Saved reference VAL/TEST identities are required.
- Standalone evaluation restores the complete corrected checkpoint strictly, including TRAIN statistics, and uses the saved fitted-run dataframe to preserve donor assignments.

These category/reload/audit fixes are necessary for a coherent rerun. Differences from v63 therefore reflect the complete corrected pipeline, not normalization alone. No claim of improved accuracy is made before execution.

## Step 1 Prepare

Activate the same environment used for v63. Put the downloaded Python file in the directory containing highk_project. Run all commands from that directory. The following paths must exist:

```bash
ls highk_project/checkpoints/tier2_best.pt
ls highk_project/reports/tier3_splits/tier3_val_row_ids.csv
ls highk_project/reports/tier3_splits/tier3_test_row_ids.csv
ls highk_project/data/tier1_foundation.h5
ls highk_project/data/tier2_domain.h5
ls highk_project/data/tier3_project.h5
nvidia-smi
```

The source loader also uses highk_project/data/processed/process_db_clean.csv and the existing raw caches. Retain the same input data, environment and donor rules as v63. Use the actual retained Tier-2 checkpoint path if its filename differs.

## Step 2 Preflight before optimization

```bash
set -o pipefail
mkdir -p highk_project/reruns/preprocessing_seed42
python highk_alignn_train_v4_60_4_preprocessing_fixed.py \
  --mode tier3_finetune \
  --weights highk_project/checkpoints/tier2_best.pt \
  --run_root highk_project/reruns/preprocessing_seed42 \
  --seed 42 \
  --tier3_preflight \
  2>&1 | tee highk_project/reruns/preprocessing_seed42/preflight.log
```

Confirm both messages:

```text
PREPROCESSING AUDIT PASS: TRAIN=582 VAL=20 TEST=30; stats=TRAIN-only; input_dim=38; split fingerprints unchanged
PREPROCESSING PREFLIGHT PASS: no optimization or TEST predictions performed
```

Preflight sets up graphs, model and preprocessing; it performs no optimization or TEST predictions. It requires 500 experimental and 82 computed TRAIN records. A count, overlap or manifest mismatch aborts. Do not relax these checks to force a run: reconcile the cached source data and v63 manifests first.

Review these files in the run's reports/tier3_preprocessing directory:

- preprocessing_audit.json: input dimension, fitting partition, normalization buffers, seed, prior checksum and split checksums.
- numerical_audit.csv: observed, missing and genuine-zero counts for every field and partition.
- categorical_audit.csv: raw/canonical labels and missing/known/unknown counts. Review unexpected unknown categories before training. If chemically verified aliases need adding, freeze the rules, rerun preflight, and do not use TEST performance to choose them.
- partition_records.csv: all partition record identities and donor/structure fingerprints.
- effective_config.json: effective optimization settings.

The checkpoint audit saves an evaluation_frame.pkl, generated from your local data. Retain this file with the run for standalone evaluation.

## Step 3 Train seed 42

Use the same output directory as the successful preflight:

```bash
torchrun --standalone --nproc_per_node=2 \
  highk_alignn_train_v4_60_4_preprocessing_fixed.py \
  --mode tier3_finetune \
  --weights highk_project/checkpoints/tier2_best.pt \
  --run_root highk_project/reruns/preprocessing_seed42 \
  --seed 42 \
  2>&1 | tee highk_project/reruns/preprocessing_seed42/train.log
```

Defaults retain: bound 0.15; adapter rank 16; adapter LR 5e-5; process/embedding LR 1e-4; weight decay 1e-4; 16 records per GPU; 100 maximum epochs; minimum 20; patience 20; cosine scheduling; clip norm 1; penalties 1/5/5/1. Split seeds remain 42, independently of --seed. Check effective_config.json and training logs rather than trusting historical comments in the inherited script.

Confirm:

- PREPROCESSING AUDIT PASS appears again.
- Checkpoint selection uses VAL ln-MAE, including epoch zero.
- TEST remains excluded from optimization and checkpoint selection.
- EVIDENCE EXPORT PASS: training N=30 appears.
- The process exits successfully; there is no traceback.

A directory already containing tier3_best.pt is rejected for fresh training. Use a fresh run directory for an intentional restart; do not resume old Tier-3 weights into the new encoding. Initial process/adapter weights and training RNG use --seed; split identities stay fixed. Bitwise CUDA reproducibility across machines is not guaranteed.

## Step 4 Reproduce selected-checkpoint evaluation

```bash
python highk_alignn_train_v4_60_4_preprocessing_fixed.py \
  --mode tier3_evaluate \
  --weights highk_project/reruns/preprocessing_seed42/checkpoints/tier3_best.pt \
  --run_root highk_project/reruns/preprocessing_seed42 \
  2>&1 | tee highk_project/reruns/preprocessing_seed42/evaluate.log
```

Confirm:

```text
PREPROCESSING RESTORE PASS
EVIDENCE EXPORT PASS: evaluation N=30
EVALUATION PARITY PASS
```

These lines may include additional details. evaluation_parity.json must contain PASS=true and N=30. Parity requires identical record identities and a maximum absolute prediction/component difference no greater than 2e-6. Evaluation never refits numerical statistics. Old v4.60.3 checkpoints are rejected for this corrected evaluation.

The audit outputs use ln-MAE as the primary endpoint, consistent with the manuscript. Some inherited console labels still call linear metrics PRIMARY; use results_training.json/results_evaluation.json for the manuscript endpoints.

## Step 5 Repeat other seeds after seed 42 passes

Run the preflight and training commands separately for seeds 124 and 777, replacing BOTH --seed and the run directory suffix. Then evaluate each seed's selected checkpoint from that same directory. Do not change dataset files, alias rules, split files, bound or optimization settings between seeds. Skip systematic tuning based on TEST scores.

## Step 6 Capture evidence

Within each run's reports/tier3_preprocessing directory, retain:

| File | Evidence |
|---|---|
| preprocessing_audit.json | TRAIN-only fitting, schema, buffers, seed and checksums |
| numerical_audit.csv | Per-field missingness and genuine-zero counts |
| categorical_audit.csv | Alias mappings and category coverage |
| partition_records.csv | Partition identities and assigned donors/structures |
| effective_config.json | Table IV effective settings |
| test_predictions_training.csv | Actual selected-checkpoint TEST prediction, prior, adapter and process components |
| results_training.json | Selected epoch, selected VAL ln-MAE; prior/process-off/full metrics in both scales; row-paired ln-MAE intervals |
| test_predictions_evaluation.csv | Standalone reproduction |
| results_evaluation.json | Standalone metrics |
| evaluation_parity.json | Explicit prediction/identity reproduction result |
| runtime.json | Stopping epoch, GPU process count, timing scope |
| evaluation_frame.pkl | Exact fitted-run dataframe for reproduction |

Also preserve checkpoints/tier3_best.pt, reports/tier3_training_history_normal.json, existing prediction/optimizer/frozen-base audits, logs, and copied reports/tier3_splits. Paired intervals use 100,000 row resamples, RNG seed 2026. They are within-checkpoint comparisons, not independently trained baseline comparisons. Publication/condition-cluster uncertainty is not newly computed by this patch.

Inspect a concise metrics summary:

```bash
python - <<'PY'
import json
from pathlib import Path
base = Path('highk_project/reruns/preprocessing_seed42/reports/tier3_preprocessing')
for filename in ['results_training.json', 'evaluation_parity.json', 'runtime.json']:
    print(filename)
    print(json.dumps(json.loads((base / filename).read_text()), indent=2))
PY
```

## Step 7 Return the results

Share the seed-42 logs and reports first. For convenient packaging (includes local data, so intended for this project):

```bash
tar -czf Tier3_preprocessing_seed42_results.tar.gz \
  -C highk_project/reruns preprocessing_seed42
```

Table IV should contain configuration, not accuracy. Update Tables V/VI and Section II-D with the corrected encoding/preprocessing; update Tier-3 results/figures from the verified outputs. Remove preprocessing limitations only after all checks pass. Observation-level splitting and previous TEST-informed development remain limitations.

## Validation performed here

The script passed Python compilation and focused checks using extracted actual code for alias behavior, categorical strings, missing/unknown separation, finite values, zero-vs-missing distinction, the 38-dimensional process representation, TRAIN-only fitting under extreme held-out covariates, overlap rejection, and preservation of learned embeddings during remapping. Numeric tensor operations were checked with a NumPy-backed test double, not a PyTorch execution. PyTorch, ALIGNN, DGL, your data caches, Tier-2 checkpoint and GPUs were unavailable here. Full graph construction, DDP training and checkpoint reload must be verified by the preflight/training/evaluation sequence above. No new numerical results are claimed.
