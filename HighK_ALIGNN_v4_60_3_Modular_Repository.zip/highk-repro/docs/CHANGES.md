# Changes from v4_60_3_locked_disjoint_baseline

- Removed the 967-line historical header and version-change comment blocks.
- Removed the old combined extraction/training/full-pipeline dispatcher.
- Removed unused ALIGNN train/config imports and the unused append-to-tier path.
- Split the implementation into modules listed in the README; shortened long
  function docstrings and moved narrative diagnostics to DEBUG.
- Removed global warning suppression and import-time file/directory/log creation.
- Added configurable `--root` paths and CLI prerequisite errors.
- Moved pre-model Tier-1/2/3 transforms, donor imputation, dataset filtering,
  split creation/restoration and Tier-3 graph-schema checks into preparation.
- Prepared Phase-A loaders before training; training only binds local samplers.
- Removed runtime Tier-3 split rebuilding/reloading. The canonical prepared
  loaders are reused through final evaluation within the training run.
- Removed legacy non-bounded Tier-3 Phase-B2 branches. Public CLI retains the
  frozen, bounded, disjoint-VAL baseline defaults; it does not expose the former
  experimental adapter/split overrides or an automatic full-pipeline mode.
- Added exclusive preparation lock, atomic HDF5/prepared writes, checksums,
  missing-artifact errors, split-change checks and dependent-manifest invalidation.
- Corrected DDP device mapping to LOCAL_RANK and rank-guarded shared JSON reports,
  histories and checkpoint writes. Added checkpoint-read synchronization.
- Corrected process-flag lookup to use actual TRAIN subset indices.
- Padded the distributed sampler minimally to equalize rank batch counts.
  This affects uneven-size DDP runs and is documented; single-process sampling
  and core numerical kernels are retained.

Core algorithm parity is recorded in `kernel_parity.json`. This is static AST
parity after ignoring docstrings/log expressions, not empirical metric parity.
