# Validation

Completed in the refactoring environment:

- 18 automated tests: artifact round-trip, corrupt-artifact rejection, changed
  split rejection, missing-input error, interrupted-write preservation,
  preparation launch guard, exclusive lock, uneven-rank sampler counts,
  sampler reproducibility, sampler input validation, module compilation,
  unresolved-global checks, CLI help, LOCAL_RANK device binding and absence
  of preparation calls in training workflows.
- AST parity with the supplied source for the graph dataset, both encoders,
  HighKALIGNN, masked loss, donor imputation, numeric cleaning and stratified/
  random split algorithms. All nine comparisons passed.

The runtime here has NumPy/pandas, but not PyTorch, DGL, ALIGNN, jarvis-tools,
mp-api or pymatgen. No original datasets/checkpoints were supplied to this
execution. Therefore no actual raw acquisition, DGL graph collation,
scientific-package import, GPU training or numerical prediction comparison
has been performed. The test suite does not claim those checks passed.

## Acceptance in the original training environment

1. Record versions using `scripts/check_environment.py` and `pip freeze`.
2. Copy baseline tier caches and locked splits to an isolated root.
3. Prepare using `--reuse-caches`; confirm split row IDs/counts/hashes against
   the originals. Confirm train/VAL/TEST disjointness from the composition audit.
4. Evaluate the same existing checkpoints with the source and modular version;
   compare aligned per-row predictions and aggregate metrics to tolerance.
5. Run a short single-GPU and two-GPU smoke job on a separate fixture/root.
   Check equal rank step counts, finite losses, checkpoint restoration, complete
   report writes and clean distributed shutdown. If reducing epochs for this
   smoke test, edit the configuration and re-prepare before training.
6. For paper reproduction, run the full original schedules and compare final
   predictions using the exact source dataset, checkpoint lineage and seeds.

HDF5 failures in preparation still require the complete exception/backtrace.
Single-process preparation prevents concurrent-rank writers; it cannot repair
an already corrupted cache or missing compression filter. Test/restore such a
cache from a known-good source rather than disabling file locking.
