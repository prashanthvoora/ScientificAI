from __future__ import annotations
from .common import _DIST, dist, log, os, torch

def init_dist() -> bool:
    """Initialise NCCL process group when launched under torchrun.
    Returns True if distributed mode is active.
    Called once at the top of main() before anything else."""
    if 'RANK' not in os.environ:
        _DIST['device'] = 'cuda' if torch.cuda.is_available() else 'cpu'
        return False
    local_rank = int(os.environ.get('LOCAL_RANK', '0'))
    torch.cuda.set_device(local_rank)
    dist.init_process_group(backend='nccl', device_id=torch.device(f'cuda:{local_rank}'))
    rank = dist.get_rank()
    world = dist.get_world_size()
    _DIST.update({'rank': rank, 'world': world, 'active': True, 'device': f'cuda:{local_rank}', 'local_rank': local_rank})
    log.debug('[rank %d/%d] DDP active on cuda:%d', rank, world, local_rank)
    return True

def is_rank0() -> bool:
    """True for the primary process (rank 0), or in single-GPU mode."""
    return _DIST['rank'] == 0

def dist_barrier():
    """All-ranks barrier — no-op in single-GPU mode."""
    if _DIST['active']:
        dist.barrier()

def shutdown_dist():
    """Destroy the NCCL process group.
    Must be called before process exit to avoid the warning:
      "destroy_process_group() was not called before exit which can leak resources"
    Called in the finally block of main() so it fires on every exit path
    including exceptions, early returns, and normal completion.
    No-op in single-GPU mode."""
    if _DIST['active'] and dist.is_initialized():
        dist.destroy_process_group()
        log.debug('NCCL process group destroyed cleanly.')
