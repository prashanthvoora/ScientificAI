from __future__ import annotations
from .common import Path, _DIST, log, os, pd, time, torch

def _read_hdf_with_retry(path: Path, key: str='data', retries: int=8, delay_s: float=0.5) -> pd.DataFrame:
    """Read an HDF5 dataframe with bounded retry for transient filesystem locks."""
    last_exc = None
    for attempt in range(retries):
        try:
            return pd.read_hdf(path, key=key)
        except Exception as exc:
            last_exc = exc
            if attempt + 1 >= retries:
                break
            time.sleep(delay_s * (attempt + 1))
    raise last_exc

def _atomic_write_hdf(df: pd.DataFrame, path: Path, key: str='data') -> None:
    """Write HDF5 through a temporary file and atomically replace the cache."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.rank{int(_DIST.get('rank', 0))}.tmp")
    try:
        if tmp.exists():
            tmp.unlink()
        df.to_hdf(tmp, key=key, mode='w', complevel=6, complib='blosc')
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            try:
                tmp.unlink()
            except OSError:
                pass

def safe_load_checkpoint(path: Path, map_location: str='cpu') -> dict:
    """Load a checkpoint with integrity verification and clear error reporting."""
    if not path.exists():
        log.error('Checkpoint not found: %s', path)
        return None
    size_bytes = path.stat().st_size
    if size_bytes < 1024:
        log.error('Checkpoint appears corrupt (size=%d B): %s', size_bytes, path)
        return None
    try:
        ckpt = torch.load(path, map_location=map_location)
        if 'model_state_dict' not in ckpt:
            raise KeyError('model_state_dict key missing')
        log.debug('Checkpoint loaded: %s  (epoch=%s  val_mae=%.4f  size=%.1f MB)', path, ckpt.get('epoch', '?'), ckpt.get('val_mae', float('nan')), size_bytes / 1000000.0)
        return ckpt
    except Exception as exc:
        log.error('Failed to load checkpoint %s: %s', path, exc)
        return None
