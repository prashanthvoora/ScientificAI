from __future__ import annotations
from .common import CKPT_ROOT, DataLoader, Dict, Optional, PAPER_MAD_MAE_BENCHMARK, REPORT_ROOT, TASK_TO_COLUMN, _DIST, dist, json, log, math, nn, np, pd, time, torch
from .model import HighKALIGNN
from .loss import MaskedMultiTaskLoss
from .distributed import is_rank0

class ALIGNNTrainer:
    """
    Training engine for a single tier.
    Handles: optimizer setup, lr scheduling, checkpoint saving,
    early stopping, and metric logging.
    """

    def __init__(self, model: HighKALIGNN, tier_cfg: dict, device: str=None, ckpt_prefix: str='tier', ablate_context: bool=False):
        if device is None:
            device = _DIST['device'] if _DIST['active'] else 'cuda' if torch.cuda.is_available() else 'cpu'
        self.device = device
        self.ckpt_prefix = ckpt_prefix
        self.ablate_context = ablate_context
        model = model.to(device)
        if _DIST['active']:
            self.model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[_DIST['local_rank']], output_device=_DIST['local_rank'], find_unused_parameters=True, gradient_as_bucket_view=True)
            self.model_core = self.model.module
        else:
            self.model = model
            self.model_core = model
        self.cfg = tier_cfg
        self.optimizer = torch.optim.AdamW(filter(lambda p: p.requires_grad, self.model_core.parameters()), lr=tier_cfg['learning_rate'], weight_decay=tier_cfg['weight_decay'])
        self.criterion = MaskedMultiTaskLoss(upweight_high_k=True)
        self.best_val_mae = float('inf')
        self.best_epoch = 0
        self.patience = int(tier_cfg.get('patience', 30))
        self.patience_ctr = 0
        self._warned_no_grad_ablation = False
        self._process_delta_initial_state = {name: param.detach().cpu().clone() for name, param in self.model_core.process_delta_head.named_parameters()}
        self._categorical_embedding_initial_state = {name: param.detach().cpu().clone() for name, param in self.model_core._categorical_embedding_named_parameters()}
        self._write_optimizer_audit_manifest()
        log.debug('Trainer patience: %d epochs', self.patience)

    def _process_delta_parameter_diagnostics(self) -> dict:
        """Return residual-head norm and L2 movement from trainer initialization."""
        sq_norm = 0.0
        sq_change = 0.0
        for name, param in self.model_core.process_delta_head.named_parameters():
            cur = param.detach().float().cpu()
            sq_norm += float(torch.sum(cur * cur).item())
            init = self._process_delta_initial_state.get(name)
            if init is not None:
                diff = cur - init.float()
                sq_change += float(torch.sum(diff * diff).item())
        return {'process_delta_parameter_norm': math.sqrt(max(sq_norm, 0.0)), 'process_delta_parameter_change_from_init': math.sqrt(max(sq_change, 0.0))}

    def _categorical_embedding_parameter_diagnostics(self) -> dict:
        """Return categorical embedding norm and movement from initialization."""
        sq_norm = 0.0
        sq_change = 0.0
        max_abs_change = 0.0
        changed_tensors = 0
        count = 0
        initial = getattr(self, '_categorical_embedding_initial_state', {})
        for name, param in self.model_core._categorical_embedding_named_parameters():
            count += int(param.numel())
            cur = param.detach().float().cpu()
            sq_norm += float(torch.sum(cur * cur).item())
            init = initial.get(name)
            if init is not None:
                diff = cur - init.float()
                sq_change += float(torch.sum(diff * diff).item())
                local_max = float(diff.abs().max().item()) if diff.numel() else 0.0
                max_abs_change = max(max_abs_change, local_max)
                if local_max > 0.0:
                    changed_tensors += 1
        return {'categorical_embedding_parameter_count': count, 'categorical_embedding_parameter_norm': math.sqrt(max(sq_norm, 0.0)), 'categorical_embedding_parameter_change_from_init': math.sqrt(max(sq_change, 0.0)), 'categorical_embedding_max_abs_change_from_init': max_abs_change, 'categorical_embedding_changed_tensors': changed_tensors}

    def _adapter_parameter_diagnostics(self) -> dict:
        """Return structural-adapter norm and movement from Tier-3 initialization."""
        sq_norm = 0.0
        sq_change = 0.0
        max_abs_change = 0.0
        grad_sq = 0.0
        initial = getattr(self, '_adapter_initial_state', {})
        for name, param in self.model_core.tier3_structural_adapter.named_parameters():
            cur = param.detach().float().cpu()
            sq_norm += float(torch.sum(cur * cur).item())
            init = initial.get(name)
            if init is not None:
                diff = cur - init.float()
                sq_change += float(torch.sum(diff * diff).item())
                if diff.numel():
                    max_abs_change = max(max_abs_change, float(diff.abs().max().item()))
            if param.grad is not None:
                grad_sq += float(param.grad.detach().float().pow(2).sum().item())
        return {'adapter_parameter_norm': math.sqrt(max(sq_norm, 0.0)), 'adapter_parameter_change_l2': math.sqrt(max(sq_change, 0.0)), 'adapter_parameter_change_max_abs': max_abs_change, 'adapter_grad_norm_snapshot': math.sqrt(max(grad_sq, 0.0))}

    def rebuild_optimizer_for_current_trainables(self):
        """v4.58 AdamW groups for process residual and low-rank structural adapter."""
        adapter_params = [p for p in self.model_core.tier3_structural_adapter.parameters() if p.requires_grad]
        adapter_ids = {id(p) for p in adapter_params}
        process_params = [p for p in self.model_core.parameters() if p.requires_grad and id(p) not in adapter_ids]
        groups = []
        if process_params:
            groups.append({'params': process_params, 'lr': float(self.cfg.get('tier3_process_learning_rate', self.cfg['learning_rate'])), 'weight_decay': float(self.cfg.get('tier3_process_weight_decay', self.cfg['weight_decay'])), 'group_name': 'process_residual'})
        if adapter_params:
            groups.append({'params': adapter_params, 'lr': float(self.cfg.get('tier3_structural_adapter_learning_rate', 5e-05)), 'weight_decay': float(self.cfg.get('tier3_structural_adapter_weight_decay', self.cfg['weight_decay'])), 'group_name': 'structural_adapter'})
        if not groups:
            raise RuntimeError('v4.56: no trainable parameters after residual+adapter freeze')
        self.optimizer = torch.optim.AdamW(groups)
        self._process_delta_initial_state = {name: p.detach().cpu().clone() for name, p in self.model_core.process_delta_head.named_parameters()}
        self._categorical_embedding_initial_state = {name: p.detach().cpu().clone() for name, p in self.model_core._categorical_embedding_named_parameters()}
        self._adapter_initial_state = {name: p.detach().cpu().clone() for name, p in self.model_core.tier3_structural_adapter.named_parameters()}
        self._base_head_initial_state = {}
        self._write_optimizer_audit_manifest()
        all_trainable = process_params + adapter_params
        log.debug('v4.58 OPTIMIZER-REBUILD: tensors=%d params=%d groups=%s', len(all_trainable), sum((p.numel() for p in all_trainable)), [(g['group_name'], g['lr'], sum((p.numel() for p in g['params']))) for g in groups])

    def capture_frozen_base_reference(self):
        """Snapshot every frozen parameter and buffer outside residual head."""
        self._frozen_base_reference = {name: tensor.detach().cpu().clone() for name, tensor in self.model_core.state_dict().items() if not name.startswith('process_delta_head.') and (not name.startswith('tier3_structural_adapter.')) and (not (self.model_core.process_delta_use_categorical and name.startswith('proc_encoder.embeddings.')))}
        log.debug('v4.46 BASE-SNAPSHOT: captured %d frozen parameters/buffers', len(self._frozen_base_reference))

    def _frozen_base_state_diagnostics(self) -> dict:
        ref = getattr(self, '_frozen_base_reference', None)
        if not ref:
            return {'frozen_base_max_abs_change': float('nan'), 'frozen_base_l2_change': float('nan'), 'frozen_base_changed_tensors': -1}
        max_abs = 0.0
        sq = 0.0
        changed = 0
        current = self.model_core.state_dict()
        for name, old in ref.items():
            cur = current[name].detach().cpu()
            if cur.dtype.is_floating_point:
                diff = cur.float() - old.float()
                local_max = float(diff.abs().max().item()) if diff.numel() else 0.0
                local_sq = float((diff * diff).sum().item()) if diff.numel() else 0.0
            else:
                neq = cur.ne(old)
                local_max = 1.0 if bool(neq.any()) else 0.0
                local_sq = float(neq.sum().item())
            max_abs = max(max_abs, local_max)
            sq += local_sq
            if local_max > 0.0:
                changed += 1
        return {'frozen_base_max_abs_change': max_abs, 'frozen_base_l2_change': math.sqrt(max(sq, 0.0)), 'frozen_base_changed_tensors': changed}

    def _write_optimizer_audit_manifest(self):
        """Write trainable-parameter and optimizer-membership evidence for Tier-3 audit."""
        if not is_rank0() or not self.cfg.get('audit_write_optimizer_manifest', False):
            return
        audit_dir = REPORT_ROOT / 'tier3_prediction_audit' / ('ablation' if self.ablate_context else 'normal')
        audit_dir.mkdir(parents=True, exist_ok=True)
        opt_ids = {id(p) for g in self.optimizer.param_groups for p in g['params']}
        rows = []
        for name, p in self.model_core.named_parameters():
            if name.startswith('process_delta_head') or name.startswith('proc_encoder.embeddings') or p.requires_grad:
                lr = float('nan')
                for g in self.optimizer.param_groups:
                    if any((id(p) == id(q) for q in g['params'])):
                        lr = float(g.get('lr', float('nan')))
                        break
                group = 'categorical_embedding' if name.startswith('proc_encoder.embeddings') else 'process_delta_head' if name.startswith('process_delta_head') else 'other_trainable'
                rows.append({'parameter_group': group, 'parameter': name, 'shape': str(tuple(p.shape)), 'numel': int(p.numel()), 'requires_grad': bool(p.requires_grad), 'in_optimizer': id(p) in opt_ids, 'optimizer_lr': lr})
        out = audit_dir / f'{self.ckpt_prefix}_optimizer_parameter_manifest.csv'
        pd.DataFrame(rows).to_csv(out, index=False)
        delta_rows = [r for r in rows if r['parameter_group'] == 'process_delta_head']
        cat_rows = [r for r in rows if r['parameter_group'] == 'categorical_embedding']
        log.debug('v4.46 AUDIT optimizer manifest: residual_params=%d residual_all_in_optimizer=%s categorical_enabled=%s categorical_params=%d categorical_all_in_optimizer=%s path=%s', sum((r['numel'] for r in delta_rows)), bool(delta_rows) and all((r['requires_grad'] and r['in_optimizer'] for r in delta_rows)), bool(self.model_core.process_delta_use_categorical), sum((r['numel'] for r in cat_rows)), not self.model_core.process_delta_use_categorical or (bool(cat_rows) and all((r['requires_grad'] and r['in_optimizer'] for r in cat_rows))), out)

    def build_scheduler(self, n_steps_per_epoch: int, n_epochs: int):
        """One-cycle policy (paper section Methods) for pretrain.
        Cosine annealing for fine-tune stages."""
        sched_type = self.cfg.get('scheduler', 'onecycle')
        if sched_type == 'onecycle':
            return torch.optim.lr_scheduler.OneCycleLR(self.optimizer, max_lr=self.cfg['learning_rate'], total_steps=n_steps_per_epoch * n_epochs, pct_start=self.cfg.get('pct_start', 0.3))
        else:
            if len(self.optimizer.param_groups) > 1:
                return torch.optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda=[lambda ep, T=max(n_epochs, 1): 0.01 + 0.99 * 0.5 * (1.0 + math.cos(math.pi * ep / T)) for _ in self.optimizer.param_groups])
            return torch.optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=n_epochs, eta_min=self.cfg['learning_rate'] * 0.01)

    def train_epoch(self, loader: DataLoader, scheduler, target_col: str) -> dict:
        """Run one training epoch."""
        _residual_only_mode = bool(self.cfg.get('bounded_process_residual', False))
        _frozen_ablation = bool(self.ablate_context and _residual_only_mode)
        if _residual_only_mode:
            self.model_core.set_residual_only_train_mode(ablate_context=self.ablate_context)
        else:
            self.model.train()
        total_loss = 0.0
        n_batches = 0
        proc_avail_total = 0.0
        stack_avail_total = 0.0
        n_samples = 0
        delta_mean_sum = 0.0
        delta_max_seen = 0.0
        delta_active_sum = 0.0
        delta_diag_batches = 0
        proc_delta_grad_sum = 0.0
        categorical_embedding_grad_sum = 0.0
        primary_loss_sum = 0.0
        base_drift_loss_sum = 0.0
        base_drift_weighted_sum = 0.0
        base_head_grad_sum = 0.0
        base_change_mean_sum = 0.0
        base_change_max_seen = 0.0
        adapter_mean_sum = 0.0
        adapter_std_sum = 0.0
        adapter_mean_abs_sum = 0.0
        adapter_max_abs_seen = 0.0
        adapter_grad_sum = 0.0
        adapter_mag_loss_sum = 0.0
        adapter_center_loss_sum = 0.0
        process_center_loss_sum = 0.0
        orthogonal_loss_sum = 0.0
        branch_corr_sum = 0.0
        branch_corr_batches = 0
        for batch in loader:
            if batch is None:
                continue
            graph = batch['graph'].to(self.device)
            line_graph = batch['line_graph'].to(self.device)
            target = batch['target'].to(self.device)
            proc_ctx = batch.get('proc_context')
            stack_ctx = batch.get('stack_context')
            if proc_ctx is not None:
                proc_ctx = {k: v.to(self.device) for k, v in proc_ctx.items()}
                stack_ctx = {k: v.to(self.device) for k, v in stack_ctx.items()}
                proc_avail_total += proc_ctx['avail'].sum().item()
                stack_avail_total += stack_ctx['avail'].sum().item()
                n_samples += proc_ctx['avail'].numel()
            if self.ablate_context:
                proc_ctx = stack_ctx = None
            func_code = batch.get('functional_code')
            if func_code is not None:
                func_code = func_code.to(self.device)
            func_loss_weights = None
            fw_map = self.cfg.get('functional_loss_weights', {})
            if fw_map and func_code is not None:
                func_loss_weights = torch.ones(func_code.shape[0], dtype=torch.float32, device=self.device)
                for code, w in fw_map.items():
                    func_loss_weights[func_code == int(code)] = float(w)
            exp_w = float(self.cfg.get('exp_sample_weight', 1.0))
            if exp_w != 1.0:
                is_exp = batch.get('is_experimental')
                if is_exp is not None:
                    is_exp = is_exp.to(self.device).squeeze(-1)
                    exp_scale = 1.0 + (exp_w - 1.0) * is_exp
                    func_loss_weights = exp_scale if func_loss_weights is None else func_loss_weights * exp_scale
            self.optimizer.zero_grad()
            preds = self.model(graph, line_graph, task='__all__', proc_context=proc_ctx, stack_context=stack_ctx, functional_code=func_code)
            targets_dict = {target_col: target}
            aux_batch = batch.get('aux_targets', {})
            for task_name in preds.keys():
                if task_name == target_col:
                    continue
                if task_name in aux_batch:
                    targets_dict[task_name] = aux_batch[task_name].to(self.device)
                else:
                    col_name = TASK_TO_COLUMN.get(task_name, task_name)
                    if col_name in aux_batch:
                        targets_dict[task_name] = aux_batch[col_name].to(self.device)
            primary_loss = self.criterion(preds, targets_dict, functional_weights=func_loss_weights)
            loss = primary_loss
            structural_delta = getattr(self.model_core, '_last_structural_delta', None)
            process_delta_tensor = getattr(self.model_core, '_last_process_delta_tensor', None)
            adapter_mag_loss = torch.zeros((), device=self.device)
            adapter_center_loss = torch.zeros((), device=self.device)
            process_center_loss = torch.zeros((), device=self.device)
            orthogonal_loss = torch.zeros((), device=self.device)
            if structural_delta is not None:
                sd = structural_delta.squeeze(-1)
                adapter_mag_loss = torch.mean(sd * sd)
                adapter_center_loss = torch.mean(sd) ** 2
            if process_delta_tensor is not None:
                pdlt = process_delta_tensor.squeeze(-1)
                if proc_ctx is not None and 'avail' in proc_ctx:
                    active = proc_ctx['avail'].squeeze(-1) > 0
                    if bool(active.any()):
                        pdlt = pdlt[active]
                        process_center_loss = torch.mean(pdlt) ** 2
                        if structural_delta is not None:
                            sd_active = structural_delta.squeeze(-1)[active]
                            if sd_active.numel() > 1:
                                sdc = sd_active - sd_active.mean()
                                pdc = pdlt - pdlt.mean()
                                orthogonal_loss = torch.mean(sdc * pdc) ** 2
            loss = primary_loss + float(self.cfg.get('tier3_adapter_magnitude_weight', 1.0)) * adapter_mag_loss + float(self.cfg.get('tier3_adapter_center_weight', 5.0)) * adapter_center_loss + float(self.cfg.get('tier3_process_center_weight', 5.0)) * process_center_loss + float(self.cfg.get('tier3_adapter_process_orthogonal_weight', 1.0)) * orthogonal_loss
            base_drift_loss = adapter_mag_loss
            base_drift_weight = float(self.cfg.get('tier3_adapter_magnitude_weight', 1.0))
            primary_loss_sum += float(primary_loss.detach().item())
            base_drift_loss_sum += float(base_drift_loss.detach().item())
            base_drift_weighted_sum += float(base_drift_weight * base_drift_loss.detach().item())
            adapter_mag_loss_sum += float(adapter_mag_loss.detach().item())
            adapter_center_loss_sum += float(adapter_center_loss.detach().item())
            process_center_loss_sum += float(process_center_loss.detach().item())
            orthogonal_loss_sum += float(orthogonal_loss.detach().item())
            if structural_delta is not None:
                _sd = structural_delta.detach().reshape(-1)
                adapter_mean_sum += float(_sd.mean().item()) if _sd.numel() else 0.0
                adapter_std_sum += float(_sd.std(unbiased=False).item()) if _sd.numel() else 0.0
                adapter_mean_abs_sum += float(_sd.abs().mean().item()) if _sd.numel() else 0.0
                adapter_max_abs_seen = max(adapter_max_abs_seen, float(_sd.abs().max().item()) if _sd.numel() else 0.0)
            if structural_delta is not None and process_delta_tensor is not None:
                _s = structural_delta.detach().reshape(-1)
                _p = process_delta_tensor.detach().reshape(-1)
                if _s.numel() == _p.numel() and _s.numel() > 1:
                    _sc = _s - _s.mean()
                    _pc = _p - _p.mean()
                    _den = torch.sqrt(torch.sum(_sc * _sc) * torch.sum(_pc * _pc))
                    if float(_den.item()) > 0.0:
                        branch_corr_sum += float(torch.sum(_sc * _pc).item() / _den.item())
                        branch_corr_batches += 1
            base_change_mean_sum += float(getattr(self.model_core, '_last_base_change_mean_abs', 0.0))
            base_change_max_seen = max(base_change_max_seen, float(getattr(self.model_core, '_last_base_change_max_abs', 0.0)))
            has_trainable_graph = bool(loss.requires_grad and loss.grad_fn is not None)
            if has_trainable_graph:
                loss.backward()
            elif self.ablate_context and (not self._warned_no_grad_ablation):
                log.debug('v4.40 AUDIT+ABLATION-NOGRAD: context is disabled and the DFT base is frozen; running loss/metric-only epochs with no optimizer updates. This is the intended ablation baseline.')
                self._warned_no_grad_ablation = True
            grad_sq = 0.0
            if has_trainable_graph:
                for p in self.model_core.process_delta_head.parameters():
                    if p.grad is not None:
                        grad_sq += float(p.grad.detach().pow(2).sum().item())
            proc_delta_grad_sum += math.sqrt(grad_sq)
            adapter_grad_sq = 0.0
            if has_trainable_graph:
                for p in self.model_core.tier3_structural_adapter.parameters():
                    if p.grad is not None:
                        adapter_grad_sq += float(p.grad.detach().pow(2).sum().item())
            adapter_grad_sum += math.sqrt(adapter_grad_sq)
            cat_grad_sq = 0.0
            if has_trainable_graph:
                for _, p in self.model_core._categorical_embedding_named_parameters():
                    if p.grad is not None:
                        cat_grad_sq += float(p.grad.detach().pow(2).sum().item())
            categorical_embedding_grad_sum += math.sqrt(cat_grad_sq)
            base_grad_sq = 0.0
            if has_trainable_graph and self.cfg.get('process_delta_train_base_head', False):
                for p in self.model_core.task_heads['k_total_log'].parameters():
                    if p.grad is not None:
                        base_grad_sq += float(p.grad.detach().pow(2).sum().item())
            base_head_grad_sum += math.sqrt(base_grad_sq)
            delta_mean_sum += float(getattr(self.model_core, '_last_process_delta_mean_abs', 0.0))
            delta_max_seen = max(delta_max_seen, float(getattr(self.model_core, '_last_process_delta_max_abs', 0.0)))
            delta_active_sum += float(getattr(self.model_core, '_last_process_delta_active_pct', 0.0))
            delta_diag_batches += 1
            if has_trainable_graph:
                max_norm = self.cfg.get('max_grad_norm', 1.0)
                nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=max_norm)
                self.optimizer.step()
                if isinstance(scheduler, torch.optim.lr_scheduler.OneCycleLR):
                    scheduler.step()
            total_loss += loss.item()
            n_batches += 1
        _param_diag = self._process_delta_parameter_diagnostics()
        _cat_diag = self._categorical_embedding_parameter_diagnostics()
        _adapter_diag = self._adapter_parameter_diagnostics()
        _base_diag = self._frozen_base_state_diagnostics()
        base_param_sq = 0.0
        base_param_max = 0.0
        for name, p in self.model_core.task_heads['k_total_log'].named_parameters():
            old = getattr(self, '_base_head_initial_state', {}).get(name)
            if old is not None:
                d = p.detach().cpu().float() - old.float()
                base_param_sq += float((d * d).sum().item())
                base_param_max = max(base_param_max, float(d.abs().max().item()) if d.numel() else 0.0)
        if _residual_only_mode and (not self.cfg.get('process_delta_train_base_head', False)):
            tol = float(self.cfg.get('frozen_base_state_tolerance', 1e-08))
            if _base_diag['frozen_base_changed_tensors'] > 0 and _base_diag['frozen_base_max_abs_change'] > tol:
                raise RuntimeError(f"v4.46 FROZEN-BASE DRIFT: changed_tensors={_base_diag['frozen_base_changed_tensors']} max_abs={_base_diag['frozen_base_max_abs_change']:.3e} l2={_base_diag['frozen_base_l2_change']:.3e} tol={tol:.3e}")
        return {'loss': total_loss / max(n_batches, 1), 'proc_avail_pct': 100.0 * proc_avail_total / max(n_samples, 1), 'stack_avail_pct': 100.0 * stack_avail_total / max(n_samples, 1), 'process_delta_mean_abs': delta_mean_sum / max(delta_diag_batches, 1), 'process_delta_max_abs': delta_max_seen, 'process_delta_active_pct': delta_active_sum / max(delta_diag_batches, 1), 'process_delta_grad_norm': proc_delta_grad_sum / max(n_batches, 1), 'categorical_embedding_grad_norm': categorical_embedding_grad_sum / max(n_batches, 1), 'primary_loss': primary_loss_sum / max(n_batches, 1), 'adapter_output_mean': adapter_mean_sum / max(delta_diag_batches, 1), 'adapter_output_std': adapter_std_sum / max(delta_diag_batches, 1), 'adapter_output_mean_abs': adapter_mean_abs_sum / max(delta_diag_batches, 1), 'adapter_output_max_abs': adapter_max_abs_seen, 'adapter_grad_norm': adapter_grad_sum / max(n_batches, 1), 'adapter_magnitude_loss': adapter_mag_loss_sum / max(n_batches, 1), 'adapter_center_loss': adapter_center_loss_sum / max(n_batches, 1), 'process_center_loss': process_center_loss_sum / max(n_batches, 1), 'adapter_process_orthogonal_loss': orthogonal_loss_sum / max(n_batches, 1), 'adapter_process_correlation': branch_corr_sum / max(branch_corr_batches, 1), 'base_drift_loss': base_drift_loss_sum / max(n_batches, 1), 'base_drift_weighted': base_drift_weighted_sum / max(n_batches, 1), 'base_head_grad_norm': base_head_grad_sum / max(n_batches, 1), 'base_change_mean_abs_log': base_change_mean_sum / max(n_batches, 1), 'base_change_max_abs_log': base_change_max_seen, 'base_head_parameter_change_l2': math.sqrt(max(base_param_sq, 0.0)), 'base_head_parameter_change_max_abs': base_param_max, **_param_diag, **_cat_diag, **_adapter_diag, **_base_diag}

    @torch.no_grad()
    def evaluate(self, loader: DataLoader, target_col: str, return_preds: bool=False):
        """Evaluate MAE and RMSE on a validation/test split."""
        self.model.eval()
        preds_all = []
        targets_all = []
        with torch.no_grad():
            for batch in loader:
                if batch is None:
                    continue
                graph = batch['graph'].to(self.device)
                line_graph = batch['line_graph'].to(self.device)
                target = batch['target']
                proc_ctx = batch.get('proc_context')
                stack_ctx = batch.get('stack_context')
                if proc_ctx is not None:
                    proc_ctx = {k: v.to(self.device) for k, v in proc_ctx.items()}
                    stack_ctx = {k: v.to(self.device) for k, v in stack_ctx.items()}
                if self.ablate_context:
                    proc_ctx = stack_ctx = None
                func_code = batch.get('functional_code')
                if func_code is not None:
                    func_code = func_code.to(self.device)
                pred = self.model(graph, line_graph, task=target_col, proc_context=proc_ctx, stack_context=stack_ctx, functional_code=func_code)
                preds_all.append(pred.cpu())
                targets_all.append(target)
        if not preds_all:
            empty = torch.tensor([])
            return (float('inf'), float('inf'), empty, empty) if return_preds else (float('inf'), float('inf'))
        preds = torch.cat(preds_all).squeeze()
        targets = torch.cat(targets_all).squeeze()
        valid = ~torch.isnan(targets)
        mae = (preds[valid] - targets[valid]).abs().mean().item()
        rmse = ((preds[valid] - targets[valid]) ** 2).mean().sqrt().item()
        if return_preds:
            return (mae, rmse, preds, targets)
        return (mae, rmse)

    @torch.no_grad()
    def evaluate_multitask(self, loader: DataLoader, tier_cfg: dict, df_full: Optional[pd.DataFrame]=None) -> Dict[str, Dict[str, float]]:
        """FIX2 + MAD:MAE: Evaluate ALL task heads on a data split.
        Returns per-task: mae, rmse, mad, mad_mae_ratio, n, coverage_pct."""
        self.model.eval()
        primary_col = tier_cfg['target']
        aux_cols = tier_cfg.get('aux_targets', [])
        task_to_batch_key = {primary_col: '__primary__'}
        task_preds = {h: [] for h in self.model_core.task_heads}
        task_targets = {h: [] for h in self.model_core.task_heads}
        n_batches = 0
        for batch in loader:
            if batch is None:
                continue
            graph = batch['graph'].to(self.device)
            line_graph = batch['line_graph'].to(self.device)
            proc_ctx = batch.get('proc_context')
            stack_ctx = batch.get('stack_context')
            if proc_ctx is not None:
                proc_ctx = {k: v.to(self.device) for k, v in proc_ctx.items()}
                stack_ctx = {k: v.to(self.device) for k, v in stack_ctx.items()}
            if self.ablate_context:
                proc_ctx = stack_ctx = None
            func_code = batch.get('functional_code')
            if func_code is not None:
                func_code = func_code.to(self.device)
            all_preds = self.model_core.forward_all_tasks(graph, line_graph, proc_context=proc_ctx, stack_context=stack_ctx, functional_code=func_code)
            n_batches += 1
            for head_name, pred_t in all_preds.items():
                task_preds[head_name].append(pred_t.cpu())
                if df_full is not None and 'row_indices' in batch:
                    row_idxs = batch['row_indices'].tolist()
                    tgt_list = []
                    for ri in row_idxs:
                        try:
                            row_data = df_full.iloc[ri]
                            col = TASK_TO_COLUMN.get(head_name, head_name)
                            val = row_data.get(col)
                            if val is not None and (not (isinstance(val, float) and np.isnan(val))):
                                tgt_list.append(float(val))
                            else:
                                tgt_list.append(float('nan'))
                        except (KeyError, IndexError):
                            tgt_list.append(float('nan'))
                    tgt = torch.tensor(tgt_list, dtype=torch.float32)
                else:
                    tgt = torch.full((len(batch['row_indices']),), float('nan'), dtype=torch.float32)
                task_targets[head_name].append(tgt)
        if n_batches == 0:
            return {}
        full_mads: Dict[str, float] = {}
        if df_full is not None:
            for head_name, col_name in TASK_TO_COLUMN.items():
                if col_name in df_full.columns:
                    vals = df_full[col_name].dropna()
                    if len(vals) > 10:
                        full_mads[head_name] = float((vals - vals.mean()).abs().mean())
            if primary_col in df_full.columns:
                vals = df_full[primary_col].dropna()
                if len(vals) > 10:
                    full_mads[primary_col] = float((vals - vals.mean()).abs().mean())
        total_rows = len(torch.cat(task_targets[primary_col]).squeeze())
        results = {}
        for head_name in self.model_core.task_heads:
            if not task_preds[head_name]:
                results[head_name] = {'mae': float('nan'), 'rmse': float('nan'), 'mad': float('nan'), 'mad_mae_ratio': float('nan'), 'n': 0, 'coverage_pct': 0.0}
                continue
            preds = torch.cat(task_preds[head_name]).squeeze()
            targets = torch.cat(task_targets[head_name]).squeeze()
            valid = ~torch.isnan(targets)
            n_valid = int(valid.sum().item())
            if n_valid == 0:
                results[head_name] = {'mae': float('nan'), 'rmse': float('nan'), 'mad': float('nan'), 'mad_mae_ratio': float('nan'), 'n': 0, 'coverage_pct': 0.0}
                continue
            pred_valid = preds[valid]
            tgt_valid = targets[valid]
            mae_native = (pred_valid - tgt_valid).abs().mean().item()
            rmse_native = ((pred_valid - tgt_valid) ** 2).mean().sqrt().item()
            _is_log_head = str(head_name).endswith('_log')
            if _is_log_head:
                pred_linear = torch.exp(pred_valid)
                tgt_linear = torch.exp(tgt_valid)
                mae_linear = (pred_linear - tgt_linear).abs().mean().item()
                rmse_linear = ((pred_linear - tgt_linear) ** 2).mean().sqrt().item()
                mad_linear = float((tgt_linear - tgt_linear.mean()).abs().mean().item())
                mad_mae_linear = mad_linear / max(mae_linear, 1e-09)
                mad_source = 'same TEST rows, exp-space'
                mae_alias, rmse_alias, mad_alias, ratio_alias = (mae_linear, rmse_linear, mad_linear, mad_mae_linear)
            else:
                if head_name in full_mads:
                    mad_linear = full_mads[head_name]
                    mad_source = 'full dataset'
                else:
                    mad_linear = float((tgt_valid - tgt_valid.mean()).abs().mean().item())
                    mad_source = 'test split'
                mae_linear = mae_native
                rmse_linear = rmse_native
                mad_mae_linear = mad_linear / max(mae_linear, 1e-09)
                mae_alias, rmse_alias, mad_alias, ratio_alias = (mae_linear, rmse_linear, mad_linear, mad_mae_linear)
            results[head_name] = {'mae': mae_alias, 'rmse': rmse_alias, 'mae_log': mae_native if _is_log_head else float('nan'), 'rmse_log': rmse_native if _is_log_head else float('nan'), 'mae_linear': mae_linear, 'rmse_linear': rmse_linear, 'mad': mad_alias, 'mad_linear': mad_linear, 'mad_mae_ratio': ratio_alias, 'mad_mae_linear': mad_mae_linear, 'mad_source': mad_source, 'n': n_valid, 'coverage_pct': 100.0 * n_valid / max(total_rows, 1)}
        return results

    @torch.no_grad()
    def evaluate_adapter_diagnostics(self, loader: DataLoader, target_col: str, split_name: str='TEST', gather_distributed: bool=False) -> dict:
        """Measure adapter and process contributions on the exact evaluation rows."""
        self.model.eval()
        s_all, p_all = ([], [])
        for batch in loader:
            if batch is None:
                continue
            graph = batch['graph'].to(self.device)
            line_graph = batch['line_graph'].to(self.device)
            proc_ctx = batch.get('proc_context')
            stack_ctx = batch.get('stack_context')
            if proc_ctx is not None:
                proc_ctx = {k: v.to(self.device) for k, v in proc_ctx.items()}
                stack_ctx = {k: v.to(self.device) for k, v in stack_ctx.items()}
            if self.ablate_context:
                proc_ctx = stack_ctx = None
            func_code = batch.get('functional_code')
            if func_code is not None:
                func_code = func_code.to(self.device)
            _ = self.model(graph, line_graph, task=target_col, proc_context=proc_ctx, stack_context=stack_ctx, functional_code=func_code)
            sd = getattr(self.model_core, '_last_structural_delta', None)
            pd = getattr(self.model_core, '_last_process_delta_tensor', None)
            if sd is not None:
                s_all.append(sd.detach().reshape(-1).cpu())
            if pd is not None:
                p_all.append(pd.detach().reshape(-1).cpu())
        svec = torch.cat(s_all) if s_all else torch.empty(0)
        pvec = torch.cat(p_all) if p_all else torch.empty(0)
        if gather_distributed and dist.is_available() and dist.is_initialized():
            gathered_s = [None for _ in range(dist.get_world_size())]
            gathered_p = [None for _ in range(dist.get_world_size())]
            dist.all_gather_object(gathered_s, svec)
            dist.all_gather_object(gathered_p, pvec)
            svec = torch.cat([x for x in gathered_s if x is not None and x.numel()]) if any((x is not None and x.numel() for x in gathered_s)) else torch.empty(0)
            pvec = torch.cat([x for x in gathered_p if x is not None and x.numel()]) if any((x is not None and x.numel() for x in gathered_p)) else torch.empty(0)

        def stats(x):
            if not x.numel():
                return dict(mean=0.0, std=0.0, mean_abs=0.0, max_abs=0.0, n=0)
            return dict(mean=float(x.mean()), std=float(x.std(unbiased=False)), mean_abs=float(x.abs().mean()), max_abs=float(x.abs().max()), n=int(x.numel()))
        ss, ps = (stats(svec), stats(pvec))
        corr = 0.0
        n = min(svec.numel(), pvec.numel())
        if n > 1:
            sc = svec[:n] - svec[:n].mean()
            pc = pvec[:n] - pvec[:n].mean()
            den = torch.sqrt(torch.sum(sc * sc) * torch.sum(pc * pc))
            if float(den) > 0:
                corr = float(torch.sum(sc * pc) / den)
        result = {'adapter': ss, 'process': ps, 'correlation': corr, 'enabled': bool(self.model_core.use_tier3_structural_adapter), 'rank': int(self.model_core.tier3_structural_adapter_rank)}
        if is_rank0():
            log.debug('V4.58 ADAPTER-%s enabled=%s rank=%d n=%d mean=%+.6f std=%.6f mean_abs=%.6f max_abs=%.6f process_mean=%+.6f process_std=%.6f process_mean_abs=%.6f process_max_abs=%.6f corr=%+.4f', split_name.upper(), result['enabled'], result['rank'], ss['n'], ss['mean'], ss['std'], ss['mean_abs'], ss['max_abs'], ps['mean'], ps['std'], ps['mean_abs'], ps['max_abs'], corr)
        return result

    def print_multitask_results(self, results: Dict[str, Dict[str, float]], split_name: str='TEST', tier_name: str=''):
        """Print all task heads with explicit log-space and linear-space metrics."""
        hdr = f' {tier_name} -- {split_name} SET -- ALL TASK HEADS'
        line = '=' * max(132, len(hdr) + 2)
        log.debug('\n%s', line)
        log.debug(hdr)
        log.debug('%s', line)
        log.debug('  %-24s | %10s | %10s | %11s | %12s | %15s | %9s | %9s | %8s', 'Task', 'MAE(log)', 'RMSE(log)', 'MAE(linear)', 'RMSE(linear)', 'MAD:MAE(linear)', 'Paper ref', 'N valid', 'Coverage')
        log.debug('  %s', '-' * 128)
        primary_col = self.cfg.get('target', '')
        for task_name, m in results.items():
            n = int(m.get('n', 0) or 0)
            cov = float(m.get('coverage_pct', 0.0) or 0.0)
            is_pri = '<- primary' if task_name == primary_col else ''
            note = '(no data this tier)' if n == 0 else is_pri

            def _fmt(key: str, width: int=10) -> str:
                val = m.get(key, float('nan'))
                try:
                    ok = np.isfinite(float(val))
                except (TypeError, ValueError):
                    ok = False
                return f'{float(val):{width}.4f}' if ok else '--'.rjust(width)
            mae_log_s = _fmt('mae_log', 10)
            rmse_log_s = _fmt('rmse_log', 10)
            mae_lin_s = _fmt('mae_linear', 11)
            rmse_lin_s = _fmt('rmse_linear', 12)
            ratio = m.get('mad_mae_linear', m.get('mad_mae_ratio', float('nan')))
            try:
                ratio_ok = np.isfinite(float(ratio))
            except (TypeError, ValueError):
                ratio_ok = False
            ratio_s = f'{float(ratio):15.2f}' if ratio_ok else '--'.rjust(15)
            paper_ref = PAPER_MAD_MAE_BENCHMARK.get(task_name)
            if paper_ref is not None and ratio_ok:
                gap_pct = 100.0 * (paper_ref - float(ratio)) / paper_ref
                flag = ' v' if gap_pct > 5 else ' ^' if gap_pct < -5 else '  '
                paper_s = f'{paper_ref:7.2f}{flag}'
            elif paper_ref is not None:
                paper_s = f'{paper_ref:7.2f}  '
            else:
                paper_s = '   --     '
            display_name = str(m.get('display_name', task_name))
            log.debug('  %-24s | %s | %s | %s | %s | %s | %s | %9s | %7.1f%%  %s', display_name, mae_log_s, rmse_log_s, mae_lin_s, rmse_lin_s, ratio_s, paper_s, f'{n:,}', cov, note)
        log.debug('%s', line)
        log.debug('  k log-heads: log columns = optimization space; linear columns and MAD:MAE(linear) = exact exp-space metrics on the same rows.  v = below paper  ^ = beating paper')

    def save_checkpoint(self, epoch: int, val_mae: float, tag: str='best'):
        if not is_rank0():
            return
        path = CKPT_ROOT / f'{self.ckpt_prefix}_{tag}.pt'
        tmp_path = path.with_suffix('.pt.tmp')
        torch.save({'epoch': epoch, 'model_state_dict': self.model_core.state_dict(), 'optimizer_state': self.optimizer.state_dict(), 'val_mae': val_mae, 'config': self.cfg, 'adapter_runtime': {'enabled': bool(self.model_core.use_tier3_structural_adapter), 'rank': int(self.model_core.tier3_structural_adapter_rank)}}, tmp_path)
        tmp_path.replace(path)
        log.info('Checkpoint saved -> %s  (epoch=%d, val_mae=%.4f)', path, epoch, val_mae)

    def train(self, train_loader: DataLoader, val_loader: DataLoader, target_col: str, train_sampler=None):
        """Full training loop with early stopping and checkpoint saving."""
        n_epochs = self.cfg['epochs']
        scheduler = self.build_scheduler(len(train_loader), n_epochs)
        history = []
        log.debug("Starting training: %d epochs, target='%s', device=%s", n_epochs, target_col, self.device)
        for epoch in range(1, n_epochs + 1):
            if train_sampler is not None:
                train_sampler.set_epoch(epoch)
            t_start = time.time()
            epoch_stats = self.train_epoch(train_loader, scheduler, target_col)
            train_loss = epoch_stats['loss']
            val_mae, val_rmse = self.evaluate(val_loader, target_col)
            if not isinstance(scheduler, torch.optim.lr_scheduler.OneCycleLR):
                scheduler.step()
            improved = val_mae < self.best_val_mae
            if improved:
                self.best_val_mae = val_mae
                self.best_epoch = epoch
                self.patience_ctr = 0
                if is_rank0():
                    self.save_checkpoint(epoch, val_mae, tag='best')
            else:
                self.patience_ctr += 1
            elapsed = time.time() - t_start
            adapter_active = self.model_core.use_tier3_structural_adapter and epoch_stats.get('adapter_parameter_change_l2', 0.0) > 0.0 and (epoch_stats.get('adapter_output_mean_abs', 0.0) > 0.0) and (epoch_stats.get('adapter_grad_norm', 0.0) > 0.0)
            log.info('Epoch %3d/%d loss=%.4f val_MAE=%.4f val_RMSE=%.4f best=%.4f(ep%d) %.1fs %s', epoch, n_epochs, train_loss, val_mae, val_rmse, self.best_val_mae, self.best_epoch, elapsed, '✓' if improved else '')
            log.debug('V4.58 ADAPTER-EPOCH ep=%d enabled=%s active=%s rank=%d out_mean=%+.6f out_std=%.6f out_mean_abs=%.6f out_max_abs=%.6f grad=%.3e param_norm=%.3e param_change_l2=%.3e param_change_max=%.3e', epoch, bool(self.model_core.use_tier3_structural_adapter), adapter_active, int(self.model_core.tier3_structural_adapter_rank), epoch_stats.get('adapter_output_mean', 0.0), epoch_stats.get('adapter_output_std', 0.0), epoch_stats.get('adapter_output_mean_abs', 0.0), epoch_stats.get('adapter_output_max_abs', 0.0), epoch_stats.get('adapter_grad_norm', 0.0), epoch_stats.get('adapter_parameter_norm', 0.0), epoch_stats.get('adapter_parameter_change_l2', 0.0), epoch_stats.get('adapter_parameter_change_max_abs', 0.0))
            log.debug('V4.58 BRANCH-EPOCH ep=%d process_mean_abs=%.6f process_max_abs=%.6f process_active=%.1f%% process_grad=%.3e adapter_process_corr=%+.4f primary=%.6f adapter_mag=%.3e adapter_center=%.3e process_center=%.3e orthogonal=%.3e frozen_max=%.3e frozen_changed=%d', epoch, epoch_stats.get('process_delta_mean_abs', 0.0), epoch_stats.get('process_delta_max_abs', 0.0), epoch_stats.get('process_delta_active_pct', 0.0), epoch_stats.get('process_delta_grad_norm', 0.0), epoch_stats.get('adapter_process_correlation', 0.0), epoch_stats.get('primary_loss', train_loss), epoch_stats.get('adapter_magnitude_loss', 0.0), epoch_stats.get('adapter_center_loss', 0.0), epoch_stats.get('process_center_loss', 0.0), epoch_stats.get('adapter_process_orthogonal_loss', 0.0), epoch_stats.get('frozen_base_max_abs_change', float('nan')), int(epoch_stats.get('frozen_base_changed_tensors', -1)))
            history.append({'epoch': epoch, 'train_loss': train_loss, 'val_mae': val_mae, 'val_rmse': val_rmse, 'alpha': self.model_core.alpha.item(), 'beta': self.model_core.beta.item(), 'proc_avail_pct': epoch_stats['proc_avail_pct'], 'stack_avail_pct': epoch_stats['stack_avail_pct'], 'process_delta_mean_abs': epoch_stats.get('process_delta_mean_abs', 0.0), 'process_delta_max_abs': epoch_stats.get('process_delta_max_abs', 0.0), 'process_delta_active_pct': epoch_stats.get('process_delta_active_pct', 0.0), 'process_delta_grad_norm': epoch_stats.get('process_delta_grad_norm', 0.0), 'process_delta_parameter_norm': epoch_stats.get('process_delta_parameter_norm', 0.0), 'process_delta_parameter_change_from_init': epoch_stats.get('process_delta_parameter_change_from_init', 0.0), 'adapter_output_mean': epoch_stats.get('adapter_output_mean', 0.0), 'adapter_output_std': epoch_stats.get('adapter_output_std', 0.0), 'adapter_output_mean_abs': epoch_stats.get('adapter_output_mean_abs', 0.0), 'adapter_output_max_abs': epoch_stats.get('adapter_output_max_abs', 0.0), 'adapter_grad_norm': epoch_stats.get('adapter_grad_norm', 0.0), 'adapter_parameter_norm': epoch_stats.get('adapter_parameter_norm', 0.0), 'adapter_parameter_change_l2': epoch_stats.get('adapter_parameter_change_l2', 0.0), 'adapter_parameter_change_max_abs': epoch_stats.get('adapter_parameter_change_max_abs', 0.0), 'adapter_process_correlation': epoch_stats.get('adapter_process_correlation', 0.0), 'adapter_magnitude_loss': epoch_stats.get('adapter_magnitude_loss', 0.0), 'adapter_center_loss': epoch_stats.get('adapter_center_loss', 0.0), 'process_center_loss': epoch_stats.get('process_center_loss', 0.0), 'adapter_process_orthogonal_loss': epoch_stats.get('adapter_process_orthogonal_loss', 0.0), 'categorical_embedding_grad_norm': epoch_stats.get('categorical_embedding_grad_norm', 0.0), 'categorical_embedding_parameter_count': epoch_stats.get('categorical_embedding_parameter_count', 0), 'categorical_embedding_parameter_norm': epoch_stats.get('categorical_embedding_parameter_norm', 0.0), 'categorical_embedding_parameter_change_from_init': epoch_stats.get('categorical_embedding_parameter_change_from_init', 0.0), 'categorical_embedding_max_abs_change_from_init': epoch_stats.get('categorical_embedding_max_abs_change_from_init', 0.0), 'categorical_embedding_changed_tensors': epoch_stats.get('categorical_embedding_changed_tensors', 0), 'frozen_base_max_abs_change': epoch_stats.get('frozen_base_max_abs_change', float('nan')), 'frozen_base_l2_change': epoch_stats.get('frozen_base_l2_change', float('nan')), 'frozen_base_changed_tensors': epoch_stats.get('frozen_base_changed_tensors', -1), 'primary_loss': epoch_stats.get('primary_loss', train_loss), 'base_drift_loss': epoch_stats.get('base_drift_loss', 0.0), 'base_drift_weighted': epoch_stats.get('base_drift_weighted', 0.0), 'base_head_grad_norm': epoch_stats.get('base_head_grad_norm', 0.0), 'base_change_mean_abs_log': epoch_stats.get('base_change_mean_abs_log', 0.0), 'base_change_max_abs_log': epoch_stats.get('base_change_max_abs_log', 0.0), 'base_head_parameter_change_l2': epoch_stats.get('base_head_parameter_change_l2', 0.0), 'base_head_parameter_change_max_abs': epoch_stats.get('base_head_parameter_change_max_abs', 0.0)})
            if self.cfg.get('process_delta_train_base_head', False):
                mean_lim = float(self.cfg.get('tier3_base_change_warn_mean', 0.03))
                max_lim = float(self.cfg.get('tier3_base_change_warn_max', 0.1))
                if epoch_stats.get('base_change_mean_abs_log', 0.0) > mean_lim or epoch_stats.get('base_change_max_abs_log', 0.0) > max_lim:
                    log.warning('v4.56 BASE-CHANGE LIMIT: mean=%.4f (limit %.4f), max=%.4f (limit %.4f). Increase --tier3_base_drift_weight or reduce --tier3_base_head_lr.', epoch_stats.get('base_change_mean_abs_log', 0.0), mean_lim, epoch_stats.get('base_change_max_abs_log', 0.0), max_lim)
            if epoch == 1 and self.cfg.get('save_epoch1_checkpoint', False) and is_rank0():
                self.save_checkpoint(epoch, val_mae, tag='epoch1')
            if epoch in set(self.cfg.get('audit_checkpoint_epochs', [])) and is_rank0():
                self.save_checkpoint(epoch, val_mae, tag=f'audit_ep{epoch}')
            if epoch % 50 == 0 and is_rank0():
                self.save_checkpoint(epoch, val_mae, tag=f'ep{epoch}')
            use_es = self.cfg.get('early_stopping', True)
            min_ep = self.cfg.get('min_epochs', 0)
            if use_es and epoch >= min_ep and (self.patience_ctr >= self.patience):
                log.info('Early stopping at epoch %d (no improvement for %d epochs, min_epochs=%d)', epoch, self.patience, min_ep)
                break
        hist_path = REPORT_ROOT / f"{self.ckpt_prefix}_training_history_{('ablation' if self.ablate_context else 'normal')}.json"
        if is_rank0():
            with open(hist_path, 'w') as f:
                json.dump(history, f, indent=2)
        log.info('Training complete. Best val_MAE=%.4f at epoch %d.', self.best_val_mae, self.best_epoch)
        return history
