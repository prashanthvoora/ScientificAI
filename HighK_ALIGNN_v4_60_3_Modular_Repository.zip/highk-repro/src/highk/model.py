from __future__ import annotations
from .common import ALIGNN, ALIGNNConfig, ALIGNN_BASE_CONFIG, Dict, FUNCTIONAL_CODE, Optional, PROCESS_PARAMS_FEATURES, Path, STACK_CONTEXT_FEATURES, log, nn, pd, torch
from .encoders import ProcessParamsEncoder, StackContextEncoder

class HighKALIGNN(nn.Module):
    """
    ALIGNN model extended with:
    1. Multi-task output heads (k, band_gap, J_g, E_BD)
    2. Layer-selective freezing for transfer learning
    3. Uncertainty quantification via MC-Dropout

    Architecture matches paper Table 1 defaults:
    - 4 ALIGNN layers + 4 GCN layers
    - Hidden dim: 256, edge features: 80, triplet features: 40
    """

    def __init__(self, config: dict=None, n_output_tasks: int=1, dropout_rate: float=0.1, task_names: list=None):
        super().__init__()
        cfg = {**ALIGNN_BASE_CONFIG, **(config or {})}
        self.n_tasks = n_output_tasks
        self.dropout_rate = dropout_rate
        if task_names is None:
            task_names = ['k_total_log', 'band_gap', 'J_g_A_cm2', 'E_BD_MV_cm']
        self.task_names = task_names
        alignn_cfg = ALIGNNConfig(name='alignn', alignn_layers=cfg['alignn_layers'], gcn_layers=cfg['gcn_layers'], edge_input_features=cfg['edge_input_features'], triplet_input_features=cfg['triplet_input_features'], embedding_features=cfg['embedding_features'], hidden_features=cfg['hidden_features'], output_features=cfg['output_features'])
        self.backbone = ALIGNN(alignn_cfg)
        backbone_out_dim = cfg['hidden_features']
        self.task_heads = nn.ModuleDict({name: self._make_head(backbone_out_dim) for name in task_names})
        self.dropout = nn.Dropout(p=dropout_rate)
        self.frozen_layers = 0
        self.proc_encoder = ProcessParamsEncoder()
        self.stack_encoder = StackContextEncoder()
        self.alpha = nn.Parameter(torch.tensor(0.001))
        self.beta = nn.Parameter(torch.tensor(0.001))
        self.context_proj = nn.Sequential(nn.Linear(64 + 64, backbone_out_dim), nn.SiLU(), nn.Dropout(p=dropout_rate), nn.Linear(backbone_out_dim, backbone_out_dim))
        nn.init.zeros_(self.context_proj[-1].weight)
        nn.init.zeros_(self.context_proj[-1].bias)
        n_proc_num = len(PROCESS_PARAMS_FEATURES['numerical'])
        n_proc_cat = len(PROCESS_PARAMS_FEATURES['categorical']) * PROCESS_PARAMS_FEATURES.get('embed_dim', 8)
        self.process_delta_use_categorical = False
        self.process_delta_bound = 0.1
        self.use_bounded_process_residual = False
        self.process_delta_head = nn.Sequential(nn.Linear(n_proc_num + n_proc_cat, 64), nn.SiLU(), nn.Dropout(p=dropout_rate), nn.Linear(64, 32), nn.SiLU(), nn.Linear(32, 1))
        nn.init.zeros_(self.process_delta_head[-1].weight)
        nn.init.zeros_(self.process_delta_head[-1].bias)
        self._last_process_delta_mean_abs = 0.0
        self._last_process_delta_max_abs = 0.0
        self._last_process_delta_active_pct = 0.0
        self._last_process_delta_tensor = None
        self.tier3_structural_adapter_rank = 16
        self.tier3_structural_adapter = nn.Sequential(nn.Linear(backbone_out_dim, self.tier3_structural_adapter_rank, bias=False), nn.SiLU(), nn.Linear(self.tier3_structural_adapter_rank, 1, bias=True))
        nn.init.zeros_(self.tier3_structural_adapter[-1].weight)
        nn.init.zeros_(self.tier3_structural_adapter[-1].bias)
        self.use_tier3_structural_adapter = False
        self._last_structural_delta = None
        self._last_structural_delta_mean = 0.0
        self._last_structural_delta_std = 0.0
        self._last_structural_delta_mean_abs = 0.0
        self._last_structural_delta_max_abs = 0.0
        self._last_adapter_process_correlation = 0.0
        object.__setattr__(self, '_tier3_base_head_reference', None)
        self._last_adapted_base_log = None
        self._last_reference_base_log = None
        self._last_base_change_mean_abs = 0.0
        self._last_base_change_max_abs = 0.0
        n_func = len(FUNCTIONAL_CODE) + 1
        self.func_embedding = nn.Embedding(n_func, 16)
        self.func_proj = nn.Linear(16, backbone_out_dim, bias=False)
        nn.init.zeros_(self.func_proj.weight)

    @staticmethod
    def _make_head(in_dim: int) -> nn.Sequential:
        return nn.Sequential(nn.Linear(in_dim, 128), nn.SiLU(), nn.Dropout(0.1), nn.Linear(128, 1))

    def freeze_alignn_layers(self, n_layers: int):
        """Freeze the first n_layers ALIGNN update layers.
        Called at start of fine-tuning to preserve pretrained representations
        while allowing upper layers to adapt to the new domain."""
        self.frozen_layers = n_layers
        frozen_count = 0
        for i, layer in enumerate(self.backbone.alignn_layers[:n_layers]):
            for param in layer.parameters():
                param.requires_grad = False
            frozen_count += sum((p.numel() for p in layer.parameters()))
        log.debug('Froze %d ALIGNN layers (%d parameters)', n_layers, frozen_count)

    def unfreeze_all(self):
        """Unfreeze all layers for final fine-tuning stage."""
        for param in self.backbone.parameters():
            param.requires_grad = True
        self.frozen_layers = 0
        log.debug('All layers unfrozen for fine-tuning.')

    def freeze_backbone(self):
        """Freeze ALIGNN backbone; keep task_heads, context, encoders, alpha/beta trainable."""
        for param in self.backbone.parameters():
            param.requires_grad = False
        for param in self.context_proj.parameters():
            param.requires_grad = True
        for param in self.proc_encoder.parameters():
            param.requires_grad = True
        for param in self.stack_encoder.parameters():
            param.requires_grad = True
        for param in [self.alpha, self.beta]:
            param.requires_grad = True
        for param in self.task_heads.parameters():
            param.requires_grad = True
        for param in self.func_embedding.parameters():
            param.requires_grad = True
        for param in self.func_proj.parameters():
            param.requires_grad = True
        log.debug(' ALIGNN backbone frozen. Training: task_heads, context_proj, proc_encoder, stack_encoder alpha, beta, func_embedding')

    def unfreeze_backbone(self, lr=None):
        """Unfreeze the ALIGNN backbone for gentle joint adaptation after Phase B."""
        for param in self.backbone.parameters():
            param.requires_grad = True
        if lr is not None:
            log.debug('Unfroze backbone at lr=%.2e', lr)
        else:
            log.debug('ALIGNN backbone unfrozen (LR unchanged).')

    def _categorical_embedding_named_parameters(self):
        """Yield process categorical embedding parameters used by residual path."""
        if not bool(getattr(self, 'process_delta_use_categorical', False)):
            return []
        return [(f'proc_encoder.embeddings.{name}', param) for name, module in self.proc_encoder.embeddings.items() for param_name, param in module.named_parameters() for name in [f'{name}.{param_name}']]

    def freeze_for_bounded_process_residual(self, train_base_head: bool=False):
        """v4.56 freeze complete Tier-2 base; train process branch + structural adapter."""
        for p in self.parameters():
            p.requires_grad = False
        for p in self.process_delta_head.parameters():
            p.requires_grad = True
        if self.process_delta_use_categorical:
            for p in self.proc_encoder.embeddings.parameters():
                p.requires_grad = True
        if self.use_tier3_structural_adapter:
            for p in self.tier3_structural_adapter.parameters():
                p.requires_grad = True
        object.__setattr__(self, '_tier3_base_head_reference', None)
        self._residual_train_base_head = False
        n_trainable = sum((p.numel() for p in self.parameters() if p.requires_grad))
        log.debug('v4.56 RESIDUAL+ADAPTER freeze: Tier-2 head/backbone frozen; structural_adapter=%s rank=%d trainable_params=%d', self.use_tier3_structural_adapter, self.tier3_structural_adapter_rank, n_trainable)

    def set_residual_only_train_mode(self, ablate_context: bool=False):
        """Keep the frozen base deterministic and train only the residual head."""
        self.eval()
        if not ablate_context:
            self.process_delta_head.train()
            if self.process_delta_use_categorical:
                self.proc_encoder.embeddings.train()
        if self.use_tier3_structural_adapter and (not ablate_context):
            self.tier3_structural_adapter.train()
        if 'k_total_log' in self.task_heads:
            self.task_heads['k_total_log'].eval()

    def _fuse(self, crystal_emb: torch.Tensor, proc_context: Optional[dict], stack_context: Optional[dict]) -> torch.Tensor:
        """Residual context fusion."""
        dev = crystal_emb.device
        B = crystal_emb.size(0)
        proc_active = proc_context is not None and bool(proc_context['avail'].any())
        stack_active = stack_context is not None and bool(stack_context['avail'].any())
        if not proc_active and (not stack_active):
            return crystal_emb
        if proc_context is not None:
            proc_emb = self.proc_encoder(proc_context['num'].to(dev), proc_context['cat'].to(dev), proc_context['avail'].to(dev))
        else:
            proc_emb = torch.zeros(B, 64, device=dev)
        if stack_context is not None:
            stack_emb = self.stack_encoder(stack_context['num'].to(dev), stack_context['cat'].to(dev), stack_context['avail'].to(dev))
        else:
            stack_emb = torch.zeros(B, 64, device=dev)
        ctx = torch.cat([self.alpha * proc_emb, self.beta * stack_emb], dim=-1)
        delta = self.context_proj(ctx)
        return crystal_emb + delta

    def fit_encoder_stats(self, df: pd.DataFrame):
        """Fit ProcessParamsEncoder and StackContextEncoder normalisation stats."""
        self.proc_encoder.fit_stats(df)
        self.stack_encoder.fit_stats(df)
        log.debug('Encoder stats fitted  rows=%d  proc_num=%d  stack_num=%d', len(df), len(PROCESS_PARAMS_FEATURES['numerical']), len(STACK_CONTEXT_FEATURES['numerical']))

    def reset_bounded_process_residual(self, seed: int=42):
        """Deterministically reset Tier-3-only residual parameters."""
        seed = int(seed)
        cuda_devices = []
        if torch.cuda.is_available():
            try:
                cuda_devices = [torch.cuda.current_device()]
            except Exception:
                cuda_devices = []
        reset_names = []
        with torch.random.fork_rng(devices=cuda_devices, enabled=True):
            torch.manual_seed(seed)
            if torch.cuda.is_available():
                torch.cuda.manual_seed_all(seed)
            for name, module in self.process_delta_head.named_modules():
                if name and isinstance(module, nn.Linear):
                    module.reset_parameters()
                    reset_names.append(f'process_delta_head.{name}')
            if bool(getattr(self, 'process_delta_use_categorical', False)):
                for name, module in self.proc_encoder.embeddings.items():
                    module.reset_parameters()
                    reset_names.append(f'proc_encoder.embeddings.{name}')
            nn.init.zeros_(self.process_delta_head[-1].weight)
            nn.init.zeros_(self.process_delta_head[-1].bias)
        log.debug('T3-PROC-RESET: deterministic Tier-3 residual reset seed=%d; modules=%s; final_layer_zero=True', seed, reset_names)

    def configure_structural_adapter(self, enabled: bool=True, rank: int=16, reset: bool=False):
        """Configure the low-rank structural correction."""
        rank = int(rank)
        in_dim = ALIGNN_BASE_CONFIG['hidden_features']
        rebuilt = False
        if rank != self.tier3_structural_adapter_rank:
            dev = next(self.parameters()).device
            self.tier3_structural_adapter_rank = rank
            self.tier3_structural_adapter = nn.Sequential(nn.Linear(in_dim, rank, bias=False), nn.SiLU(), nn.Linear(rank, 1, bias=True)).to(dev)
            rebuilt = True
        if reset or rebuilt:
            nn.init.zeros_(self.tier3_structural_adapter[-1].weight)
            nn.init.zeros_(self.tier3_structural_adapter[-1].bias)
        self.use_tier3_structural_adapter = bool(enabled)
        log.debug('v4.58 STRUCTURAL-ADAPTER: enabled=%s rank=%d reset=%s rebuilt=%s', enabled, rank, reset, rebuilt)

    def _structural_adapter_delta(self, embedding: torch.Tensor) -> torch.Tensor:
        if not self.use_tier3_structural_adapter:
            delta = torch.zeros(embedding.shape[0], 1, device=embedding.device)
        else:
            delta = self.tier3_structural_adapter(embedding.detach())
        self._last_structural_delta = delta
        d = delta.detach().reshape(-1)
        self._last_structural_delta_mean = float(d.mean().item()) if d.numel() else 0.0
        self._last_structural_delta_std = float(d.std(unbiased=False).item()) if d.numel() else 0.0
        self._last_structural_delta_mean_abs = float(d.abs().mean().item()) if d.numel() else 0.0
        self._last_structural_delta_max_abs = float(d.abs().max().item()) if d.numel() else 0.0
        return delta

    def configure_bounded_process_residual(self, enabled: bool=True, bound: float=0.1, use_categorical: bool=False):
        """Enable/disable the DFT-base + bounded process-residual path."""
        self.use_bounded_process_residual = bool(enabled)
        self.process_delta_bound = float(bound)
        self.process_delta_use_categorical = bool(use_categorical)
        log.debug('RESIDUAL-PROC mode: enabled=%s  bound=%.3f log(k)  use_categorical=%s', self.use_bounded_process_residual, self.process_delta_bound, self.process_delta_use_categorical)

    def _process_bounded_delta(self, proc_context: Optional[dict]) -> Optional[torch.Tensor]:
        """Return bounded process correction [B,1] in log(k) units, or None."""
        if proc_context is None:
            return None
        dev = next(self.parameters()).device
        family_offset = proc_context.get('family_offset', None)
        if family_offset is not None:
            family_offset = family_offset.to(dev)
        else:
            num0 = proc_context['num'].to(dev)
            family_offset = torch.zeros(num0.shape[0], 1, device=dev)
        avail = proc_context['avail'].to(dev)
        if not bool(avail.any()):
            num = proc_context['num'].to(dev)
            dummy_in = torch.zeros(num.shape[0], self.process_delta_head[0].in_features, device=dev)
            learned_zero = 0.0 * self.process_delta_head(dummy_in)
            total_delta = family_offset + learned_zero
            self._last_process_delta_mean_abs = float(total_delta.detach().abs().mean().item())
            self._last_process_delta_max_abs = float(total_delta.detach().abs().max().item())
            self._last_process_delta_active_pct = 0.0
            self._last_process_delta_tensor = learned_zero
            return total_delta
        num = proc_context['num'].to(dev)
        num_norm = (num - self.proc_encoder.num_mean.to(dev)) / self.proc_encoder.num_std.to(dev)
        num_norm = num_norm * avail
        if self.process_delta_use_categorical:
            cat = proc_context['cat'].to(dev)
            cat_embs = [self.proc_encoder.embeddings[name](cat[:, i]) for i, name in enumerate(self.proc_encoder._cat_cols)]
            x = torch.cat([num_norm] + cat_embs, dim=-1)
        else:
            n_extra = self.process_delta_head[0].in_features - num_norm.shape[-1]
            if n_extra > 0:
                zeros = torch.zeros(num_norm.shape[0], n_extra, device=dev)
                x = torch.cat([num_norm, zeros], dim=-1)
            else:
                x = num_norm
        raw = self.process_delta_head(x)
        learned_delta = self.process_delta_bound * torch.tanh(raw) * avail
        total_delta = family_offset + learned_delta
        self._last_process_delta_mean_abs = float(total_delta.detach().abs().mean().item())
        self._last_process_delta_max_abs = float(total_delta.detach().abs().max().item())
        self._last_process_delta_active_pct = float(100.0 * avail.detach().mean().item())
        self._last_process_delta_tensor = learned_delta
        return total_delta

    def _record_base_adaptation(self, embedding: torch.Tensor, adapted_base: torch.Tensor):
        """Record adapted and frozen-reference base predictions for drift loss."""
        ref_head = getattr(self, '_tier3_base_head_reference', None)
        if ref_head is None:
            self._last_adapted_base_log = adapted_base
            self._last_reference_base_log = adapted_base.detach()
            self._last_base_change_mean_abs = 0.0
            self._last_base_change_max_abs = 0.0
            return
        with torch.no_grad():
            reference_base = ref_head(embedding.detach())
        self._last_adapted_base_log = adapted_base
        self._last_reference_base_log = reference_base.detach()
        diff = (adapted_base.detach() - reference_base.detach()).abs()
        self._last_base_change_mean_abs = float(diff.mean().item()) if diff.numel() else 0.0
        self._last_base_change_max_abs = float(diff.max().item()) if diff.numel() else 0.0

    def forward(self, graph, line_graph, task: str='k_measured', proc_context: Optional[dict]=None, stack_context: Optional[dict]=None, functional_code: Optional[torch.Tensor]=None):
        """Unified forward pass."""
        embedding = self.backbone((graph, line_graph, None))
        if not self.use_bounded_process_residual:
            embedding = self.dropout(embedding)
        embedding = self._apply_func_conditioning(embedding, functional_code)
        if self.use_bounded_process_residual:
            delta = self._process_bounded_delta(proc_context)
            if task == '__all__':
                out = {}
                for t, head in self.task_heads.items():
                    base = head(embedding)
                    if t == 'k_total_log':
                        structural_delta = self._structural_adapter_delta(embedding)
                        out[t] = base + structural_delta + (delta if delta is not None else 0.0)
                    else:
                        out[t] = base
                return out
            base = self.task_heads[task](embedding)
            if task == 'k_total_log':
                structural_delta = self._structural_adapter_delta(embedding)
                return base + structural_delta + (delta if delta is not None else 0.0)
            return base
        fused = self._fuse(embedding, proc_context, stack_context)
        if task == '__all__':
            return {t: head(fused) for t, head in self.task_heads.items()}
        return self.task_heads[task](fused)

    def forward_all_tasks(self, graph, line_graph, proc_context: Optional[dict]=None, stack_context: Optional[dict]=None, functional_code: Optional[torch.Tensor]=None) -> Dict[str, torch.Tensor]:
        """Convenience wrapper — delegates to forward(task='__all__')."""
        return self(graph, line_graph, task='__all__', proc_context=proc_context, stack_context=stack_context, functional_code=functional_code)

    def _apply_func_conditioning(self, crystal_emb: torch.Tensor, functional_code: Optional[torch.Tensor]) -> torch.Tensor:
        """Add functional-specific offset to crystal embedding."""
        if functional_code is None:
            return crystal_emb
        n_func = self.func_embedding.num_embeddings
        fc = functional_code.long().clamp(0, n_func - 1).to(crystal_emb.device)
        delta = self.func_proj(self.func_embedding(fc))
        return crystal_emb + delta

    def load_pretrained_weights(self, checkpoint_path: Path, strict: bool=False):
        """Load pretrained weights with flexible matching.
        strict=False allows loading Tier N weights into Tier N+1 model
        even if output heads differ."""
        ckpt = torch.load(checkpoint_path, map_location='cpu')
        state = ckpt.get('model_state_dict', ckpt)
        state = _remap_state_dict(state)
        missing, unexpected = self.load_state_dict(state, strict=strict)
        if missing:
            log.debug('load_pretrained_weights: %d missing keys (new heads, will train from scratch): %s', len(missing), missing[:5])
        if unexpected:
            log.debug('load_pretrained_weights: %d unexpected keys (old heads, skipped): %s', len(unexpected), unexpected[:5])
        log.debug('Loaded weights from %s  (missing=%d  unexpected=%d)', checkpoint_path, len(missing), len(unexpected))
        return self

def _remap_state_dict(state: dict) -> dict:
    """Translate legacy checkpoint key names and strip size-mismatched tensors
    before load_state_dict, so both strict=True and strict=False work cleanly."""
    KEY_REMAP = {'task_heads.k_measured_log.': 'task_heads.k_total_log.', 'task_heads.k_measured.': 'task_heads.k_total.'}
    STRIP_PREFIXES = ('proc_encoder.embeddings.anneal_ambient.', 'proc_encoder.embeddings.precursor_type.', 'proc_encoder.embeddings.oxidant_type.')
    remapped = {}
    n_renamed = 0
    n_stripped = 0
    for key, val in state.items():
        if key.startswith(STRIP_PREFIXES):
            n_stripped += 1
            continue
        new_key = key
        for old_prefix, new_prefix in KEY_REMAP.items():
            if key.startswith(old_prefix):
                new_key = new_prefix + key[len(old_prefix):]
                n_renamed += 1
                break
        remapped[new_key] = val
    if n_renamed:
        log.debug('_remap_state_dict: renamed %d legacy task-head keys (k_measured[_log] → k_total[_log])', n_renamed)
    if n_stripped:
        log.debug('_remap_state_dict: stripped %d proc_encoder embedding keys with vocab-size mismatch (BUG-5 expansion). These tables will be randomly re-initialised — safe because Tier 2 never trains these (avail_flag=0 for all T2 rows).', n_stripped)
    return remapped

def _load_state_dict_shape_compatible(model: nn.Module, state: dict, checkpoint_label: str='checkpoint'):
    """Load exact tensors and migrate expanded categorical embedding tables."""
    key_remap = {'task_heads.k_measured_log.': 'task_heads.k_total_log.', 'task_heads.k_measured.': 'task_heads.k_total.'}
    renamed = {}
    for key, value in state.items():
        new_key = key
        for old_prefix, new_prefix in key_remap.items():
            if key.startswith(old_prefix):
                new_key = new_prefix + key[len(old_prefix):]
                break
        renamed[new_key] = value
    target = model.state_dict()
    compatible, resized, skipped = ({}, [], [])
    for key, value in renamed.items():
        if key not in target:
            compatible[key] = value
            continue
        expected = target[key]
        if tuple(value.shape) == tuple(expected.shape):
            compatible[key] = value
        elif key.startswith('proc_encoder.embeddings.') and key.endswith('.weight') and (value.ndim == 2) and (expected.ndim == 2):
            migrated = expected.detach().clone()
            rows = min(value.shape[0], expected.shape[0])
            cols = min(value.shape[1], expected.shape[1])
            migrated[:rows, :cols] = value[:rows, :cols].to(dtype=migrated.dtype, device=migrated.device)
            compatible[key] = migrated
            resized.append((key, tuple(value.shape), tuple(expected.shape), rows, cols))
        else:
            skipped.append((key, tuple(value.shape), tuple(expected.shape)))
    missing, unexpected = model.load_state_dict(compatible, strict=False)
    for key, old_shape, new_shape, rows, cols in resized:
        log.warning('CKPT-EVAL-COMPAT: migrated %s %s -> %s; copied overlap [%d,%d] from %s', key, old_shape, new_shape, rows, cols, checkpoint_label)
    for key, old_shape, new_shape in skipped:
        log.warning('CKPT-EVAL-COMPAT: skipped incompatible tensor %s %s -> %s from %s', key, old_shape, new_shape, checkpoint_label)
    return (missing, unexpected)
