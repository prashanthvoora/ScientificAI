from __future__ import annotations
from .artifacts import require_single_process
from .cache import _atomic_write_hdf
from .common import Any, DATA_ROOT, FUNCTIONAL_CODE, JAtoms, JarvisAtomsAdaptor, MPRester, MP_API_KEY, Optional, Path, datetime, hashlib, jdata, json, log, np, pd, tqdm
from .imputation import _clean_numeric_series

class DatasetExtractor:
    """
    Pulls full datasets from JARVIS-DFT, Materials Project, and QM9.
    Implements the row_hash deduplication strategy from ScalableDatasetManager.
    """
    JARVIS_DATASET_KEYS = {'dft_3d': 'Full JARVIS-DFT 3D dataset (~55,722 entries)', 'qm9_std_jctc': 'QM9 standardized via JCTC (~130,829 molecules)'}
    JARVIS_FIELD_MAP = {'jid': 'jid', 'formula': 'formula', 'formation_energy_peratom': 'formation_energy_per_atom', 'optb88vdw_bandgap': 'band_gap', 'mbj_bandgap': 'band_gap_mbj', 'epsilon_ionic': 'epsilon_ionic', 'epsilon_elec': 'epsilon_elec', 'ehull': 'e_above_hull', 'bulk_modulus_kv': 'bulk_modulus', 'shear_modulus_gv': 'shear_modulus', 'atoms': 'atoms_dict'}
    MP_ELECTRIC_FIELDS = ['material_id', 'formula_pretty', 'e_total', 'e_ionic', 'e_electronic']

    def __init__(self, cache_dir: Path=DATA_ROOT / 'raw_cache'):
        require_single_process()
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def pull_jarvis_dft(self, force_refresh: bool=False) -> pd.DataFrame:
        """Pull full JARVIS-DFT 3D dataset via jarvis-tools figshare module."""
        cache_path = self.cache_dir / 'jarvis_dft_3d_full.h5'
        if cache_path.exists() and (not force_refresh):
            log.debug('Loading cached JARVIS-DFT dataset from %s', cache_path)
            return pd.read_hdf(cache_path, key='data')
        log.debug('Downloading full JARVIS-DFT 3D dataset (~55,722 entries)...')
        log.debug('This is a ~400 MB download from Figshare -- takes 5–10 min first run.')
        raw = jdata('dft_3d')
        log.debug('Raw JARVIS-DFT entries loaded: %d', len(raw))
        rows = []
        for entry in tqdm(raw, desc='Parsing JARVIS-DFT entries'):
            row = self._parse_jarvis_entry(entry, source='JARVIS-DFT')
            if row is not None:
                rows.append(row)
        df = pd.DataFrame(rows)
        log.debug('Parsed JARVIS-DFT entries: %d', len(df))
        _atomic_write_hdf(df, cache_path)
        log.debug('JARVIS-DFT cached at %s', cache_path)
        return df

    def _parse_jarvis_entry(self, entry: dict, source: str) -> Optional[dict]:
        """Parse a single JARVIS-DFT entry dict into the unified schema row."""
        try:
            atoms_dict = entry.get('atoms')
            if atoms_dict is None:
                return None
            j_atoms = JAtoms.from_dict(atoms_dict)
            formula = j_atoms.composition.reduced_formula
            has_structure = True
            eps_ionic = entry.get('epsilon_ionic', None)
            eps_elec = entry.get('epsilon_elec', None)
            k_total = self._compute_k_from_tensor(eps_ionic, eps_elec)
            band_gap = self._safe_float(entry.get('optb88vdw_bandgap'))
            band_gap_mbj = self._safe_float(entry.get('mbj_bandgap'))
            Ef = self._safe_float(entry.get('formation_energy_peratom'))
            e_hull = self._safe_float(entry.get('ehull'))
            bulk_mod = self._safe_float(entry.get('bulk_modulus_kv'))
            shear_mod = self._safe_float(entry.get('shear_modulus_gv'))
            jid = entry.get('jid', '')
            row_hash = hashlib.md5(f'JARVIS_{jid}_{formula}'.encode()).hexdigest()[:12]
            return {'source': source, 'jid': jid, 'mp_id': None, 'formula': formula, 'k_measured': k_total, 'k_total': k_total, 'k_ionic': self._compute_k_from_tensor(eps_ionic, None), 'k_elec': self._compute_k_from_tensor(None, eps_elec), 'band_gap': band_gap, 'band_gap_mbj': band_gap_mbj, 'formation_energy_per_atom': Ef, 'e_above_hull': e_hull, 'bulk_modulus': bulk_mod, 'shear_modulus': shear_mod, 'has_structure': has_structure, 'atoms_dict': json.dumps(atoms_dict), 'dft_functional': 'OptB88vdW', 'functional_code': FUNCTIONAL_CODE['OptB88vdW'], 'band_gap_optb88vdw': band_gap, 'band_gap_pbe': np.nan, 'row_hash': row_hash, 'tier': None, 'date_added': datetime.date.today().isoformat()}
        except Exception as e:
            log.debug('Skipping JARVIS entry %s: %s', entry.get('jid', '?'), e)
            return None

    def pull_materials_project(self, force_refresh: bool=False) -> pd.DataFrame:
        """Pull full Materials Project dataset via mp-api."""
        cache_path = self.cache_dir / 'mp_full.h5'
        if cache_path.exists() and (not force_refresh):
            log.debug('Loading cached MP dataset from %s', cache_path)
            return pd.read_hdf(cache_path, key='data')
        if not MP_API_KEY:
            log.warning('MP_API_KEY not set. Set env var MP_API_KEY to enable MP pull. Skipping Materials Project download.')
            return pd.DataFrame()
        log.debug('Pulling Materials Project -- dielectric entries first...')
        rows = []
        with MPRester(MP_API_KEY) as mpr:
            log.debug('  MP Query 1: summary endpoint -- materials with dielectric data...')
            docs_dielectric = mpr.materials.summary.search(has_props=['dielectric'], fields=['material_id', 'formula_pretty', 'structure', 'band_gap', 'formation_energy_per_atom', 'energy_above_hull', 'is_metal', 'e_total', 'e_ionic', 'e_electronic'])
            log.debug('  MP dielectric entries returned: %d', len(docs_dielectric))
            n_parsed = 0
            n_e_total_set = 0
            n_k_total_set = 0
            n_k_above_10 = 0
            n_has_structure = 0
            _sample_etotal = []
            for doc in tqdm(docs_dielectric, desc='Parsing MP dielectric entries'):
                raw_et = getattr(doc, 'e_total', 'MISSING')
                if len(_sample_etotal) < 5:
                    _sample_etotal.append(f"{getattr(doc, 'material_id', '?')} e_total={raw_et!r:.40}")
                if raw_et not in (None, 'MISSING'):
                    n_e_total_set += 1
                row = self._parse_mp_entry(doc, has_dielectric=True, summary_doc=doc)
                if row is not None:
                    n_parsed += 1
                    rows.append(row)
                    if row.get('k_total') is not None:
                        n_k_total_set += 1
                        if row['k_total'] > 10:
                            n_k_above_10 += 1
                    if row.get('has_structure'):
                        n_has_structure += 1
            log.debug('MP dielectric parse audit (single-query):\n  entries from summary search   : %d\n  entries with e_total present  : %d  (%.1f%%)\n  rows successfully parsed       : %d\n  rows with k_total non-null     : %d  (%.1f%% of parsed)\n  rows with k_total > 10         : %d  (Tier 2 candidates)\n  rows with has_structure=True   : %d  (%.1f%% of parsed)\n  ── both k_total and has_structure should be ~100%% ──────────', len(docs_dielectric), n_e_total_set, 100.0 * n_e_total_set / max(len(docs_dielectric), 1), n_parsed, n_k_total_set, 100.0 * n_k_total_set / max(n_parsed, 1), n_k_above_10, n_has_structure, 100.0 * n_has_structure / max(n_parsed, 1))
            if _sample_etotal:
                log.debug('MP e_total sample (first 5):\n  %s', '\n  '.join(_sample_etotal))
            log.debug('  MP Query 2: all oxide entries (for Ef + Eg pretraining)...')
            docs_oxides = mpr.materials.summary.search(elements=['O'], fields=['material_id', 'formula_pretty', 'structure', 'band_gap', 'energy_above_hull', 'formation_energy_per_atom'])
            log.debug('  MP oxide entries: %d', len(docs_oxides))
            existing_ids = {r['mp_id'] for r in rows if r}
            for doc in tqdm(docs_oxides, desc='Parsing MP oxide entries'):
                if doc.material_id in existing_ids:
                    continue
                row = self._parse_mp_entry(doc, has_dielectric=False)
                if row is not None:
                    rows.append(row)
        df = pd.DataFrame([r for r in rows if r is not None])
        log.debug('Total MP entries parsed: %d', len(df))
        _atomic_write_hdf(df, cache_path)
        log.debug('MP dataset cached at %s', cache_path)
        return df

    def _parse_mp_entry(self, doc, has_dielectric: bool, summary_doc=None) -> Optional[dict]:
        """Parse a single Materials Project API document into unified schema.
        FIX5: Detects DFT functional from is_hubbard; adds functional_code and
              band_gap_pbe columns so model can learn per-functional offsets.
              (run_type is not a valid summary endpoint field; is_hubbard used instead.)"""
        try:
            if summary_doc:
                formula = summary_doc.formula_pretty
                mp_id = summary_doc.material_id
                band_gap = self._safe_float(getattr(summary_doc, 'band_gap', None))
                Ef = self._safe_float(getattr(summary_doc, 'formation_energy_per_atom', None))
                e_hull = self._safe_float(getattr(summary_doc, 'energy_above_hull', None))
                structure = getattr(summary_doc, 'structure', None)
            else:
                formula = getattr(doc, 'formula_pretty', None)
                mp_id = getattr(doc, 'material_id', None)
                band_gap = self._safe_float(getattr(doc, 'band_gap', None))
                Ef = self._safe_float(getattr(doc, 'formation_energy_per_atom', None))
                e_hull = self._safe_float(getattr(doc, 'energy_above_hull', None))
                structure = getattr(doc, 'structure', None)
            _run_src = summary_doc if summary_doc is not None else doc
            is_hubbard = bool(getattr(_run_src, 'is_hubbard', False) or False)
            if is_hubbard:
                dft_functional = 'GGA+U'
                functional_code = FUNCTIONAL_CODE['GGA+U']
            else:
                dft_functional = 'PBE'
                functional_code = FUNCTIONAL_CODE['PBE']
            band_gap_pbe = band_gap if functional_code in (FUNCTIONAL_CODE['PBE'], FUNCTIONAL_CODE['GGA+U']) else np.nan
            k_total = None
            k_ionic = None
            k_elec = None
            if has_dielectric:
                k_total = self._safe_float(getattr(doc, 'e_total', None))
                k_ionic = self._safe_float(getattr(doc, 'e_ionic', None))
                k_elec = self._safe_float(getattr(doc, 'e_electronic', None))
            atoms_dict = None
            has_structure = False
            if structure is not None:
                try:
                    j_atoms = JarvisAtomsAdaptor.get_atoms(structure)
                    atoms_dict = json.dumps(j_atoms.to_dict())
                    has_structure = True
                except Exception:
                    pass
            row_hash = hashlib.md5(f'MP_{mp_id}_{formula}'.encode()).hexdigest()[:12]
            return {'source': 'MaterialsProject', 'jid': None, 'mp_id': mp_id, 'formula': formula, 'k_measured': k_total, 'k_total': k_total, 'k_ionic': k_ionic, 'k_elec': k_elec, 'band_gap': band_gap, 'band_gap_mbj': None, 'formation_energy_per_atom': Ef, 'e_above_hull': e_hull, 'bulk_modulus': None, 'shear_modulus': None, 'has_structure': has_structure, 'atoms_dict': atoms_dict, 'dft_functional': dft_functional, 'functional_code': functional_code, 'band_gap_optb88vdw': np.nan, 'band_gap_pbe': band_gap_pbe, 'row_hash': row_hash, 'tier': None, 'date_added': datetime.date.today().isoformat()}
        except Exception as e:
            log.debug('Skipping MP entry %s: %s', getattr(doc, 'material_id', '?'), e)
            return None

    def pull_qm9(self, force_refresh: bool=False) -> pd.DataFrame:
        """Pull QM9 molecular dataset via JARVIS figshare module."""
        cache_path = self.cache_dir / 'qm9_full.h5'
        if cache_path.exists() and (not force_refresh):
            log.debug('Loading cached QM9 dataset from %s', cache_path)
            return pd.read_hdf(cache_path, key='data')
        log.debug('Downloading QM9 via JARVIS figshare (~130K molecules, ~200 MB)...')
        raw = jdata('qm9_std_jctc')
        log.debug('QM9 raw entries: %d', len(raw))
        rows = []
        for entry in tqdm(raw, desc='Parsing QM9 entries'):
            row = self._parse_qm9_entry(entry)
            if row is not None:
                rows.append(row)
        df = pd.DataFrame(rows)
        log.debug('QM9 parsed entries: %d', len(df))
        _atomic_write_hdf(df, cache_path)
        log.debug('QM9 cached at %s', cache_path)
        return df

    def _parse_qm9_entry(self, entry: dict) -> Optional[dict]:
        """Parse a QM9 entry. Maps QM9 properties to unified schema."""
        try:
            qm9_id = entry.get('id', '')
            atoms_dict = entry.get('atoms')
            if atoms_dict is None:
                return None
            alpha = self._safe_float(entry.get('alpha'))
            gap = self._safe_float(entry.get('gap'))
            homo = self._safe_float(entry.get('HOMO'))
            lumo = self._safe_float(entry.get('LUMO'))
            mu = self._safe_float(entry.get('mu'))
            U0 = self._safe_float(entry.get('U0'))
            j_atoms = JAtoms.from_dict(atoms_dict)
            formula = j_atoms.composition.reduced_formula
            row_hash = hashlib.md5(f'QM9_{qm9_id}_{formula}'.encode()).hexdigest()[:12]
            return {'source': 'QM9', 'jid': f'qm9_{qm9_id}', 'mp_id': None, 'formula': formula, 'k_measured': alpha, 'k_total': None, 'k_ionic': None, 'k_elec': None, 'band_gap': gap, 'band_gap_mbj': None, 'formation_energy_per_atom': U0, 'e_above_hull': None, 'bulk_modulus': None, 'shear_modulus': None, 'has_structure': True, 'atoms_dict': json.dumps(atoms_dict), 'qm9_extras': json.dumps({'HOMO': homo, 'LUMO': lumo, 'mu': mu, 'alpha': alpha}), 'row_hash': row_hash, 'tier': None, 'date_added': datetime.date.today().isoformat(), 'is_molecule': True}
        except Exception as e:
            log.debug('Skipping QM9 entry %s: %s', entry.get('id', '?'), e)
            return None

    def load_experimental_process_db(self, path: Path=DATA_ROOT / 'processed' / 'process_db_clean.csv') -> pd.DataFrame:
        """Load the hand-curated experimental process database from Week 1.
        This is the Tier 3 experimental contribution -- real ALD/anneal data
        paired with measured k, J_g, D_it."""
        if not path.exists():
            log.warning('Experimental process DB not found at %s. Tier 3 will train on DFT entries only until Week 1 data is ready.', path)
            return pd.DataFrame()
        df = pd.read_csv(path)
        if 'data_quality' in df.columns:
            df['data_quality'] = df['data_quality'].fillna('verified').astype(str).str.strip().str.lower()
            q_counts = df['data_quality'].value_counts(dropna=False).to_dict()
            log.debug('QUALITY-AWARE-DB: input data_quality counts: %s', q_counts)
            n_before_q = len(df)
            df = df[df['data_quality'] != 'reject'].copy()
            if len(df) != n_before_q:
                log.warning('QUALITY-AWARE-DB: dropped %d reject rows before Tier-3 build', n_before_q - len(df))
        else:
            df['data_quality'] = 'verified'
        if 'data_split_policy' not in df.columns:
            df['data_split_policy'] = np.where(df['data_quality'].eq('weak_expanded'), 'train_only_no_val_test', 'train_val_test_allowed')
        df['source'] = 'Experimental'
        df['is_molecule'] = False
        df['tier'] = 3
        target_renames = {'k_dielectric_constant': 'k_measured', 'dielectric_constant_k': 'k_measured', 'dielectric_k': 'k_measured', 'k_total': 'k_measured', 'k_measured': 'k_measured', 'epsilon_total': 'k_measured', 'band_gap_eV': 'band_gap', 'band_gap': 'band_gap', 'Eg_eV': 'band_gap', 'J_g_A_cm2_at_1V': 'J_g_A_cm2', 'J_g_A_cm2_at_1v': 'J_g_A_cm2', 'leakage_J_A_cm2_at_field': 'J_g_A_cm2', 'leakage_current_J_A_cm2': 'J_g_A_cm2', 'J_g': 'J_g_A_cm2', 'J_g_A_cm2': 'J_g_A_cm2', 'breakdown_field_MV_cm': 'E_BD_MV_cm', 'E_breakdown_MV_cm': 'E_BD_MV_cm', 'E_BD': 'E_BD_MV_cm', 'E_BD_MV_cm': 'E_BD_MV_cm', 'material_system': 'material', 'row_id': 'paper_id'}
        df = df.rename(columns={k: v for k, v in target_renames.items() if k in df.columns})
        for tgt in ['k_measured', 'band_gap', 'J_g_A_cm2', 'E_BD_MV_cm']:
            n = int(df[tgt].notna().sum()) if tgt in df.columns else 0
            pct = 100.0 * n / max(len(df), 1)
            log.debug('  FIX-T3-8 target %-20s  %d/%d rows filled  (%.1f%%)', tgt + ':', n, len(df), pct)
        _numeric_target_cols = ['k_measured', 'band_gap', 'J_g_A_cm2', 'E_BD_MV_cm']
        _numeric_proc_cols = ['substrate_temp_C', 'anneal_temp_C', 'anneal_duration_min', 'growth_rate_A_per_cycle', 'n_cycles', 'film_thickness_A', 'pressure_mTorr']
        log.debug('FIX-T3-11: cleaning numeric columns (strip ~/range/suffix)...')
        for _col in _numeric_target_cols + _numeric_proc_cols:
            if _col in df.columns:
                df[_col] = _clean_numeric_series(df[_col], col_name=_col)
        log.debug('FIX-T3-11 post-clean target coverage:')
        for tgt in ['k_measured', 'band_gap', 'J_g_A_cm2', 'E_BD_MV_cm']:
            n = int(df[tgt].notna().sum()) if tgt in df.columns else 0
            pct = 100.0 * n / max(len(df), 1)
            log.debug('  %-20s  %d/%d rows filled  (%.1f%%)', tgt + ':', n, len(df), pct)
        proc_renames = {'ald_substrate_temp_C': 'substrate_temp_C', 'ald_substrate_temp_c': 'substrate_temp_C', 'deposition_temp_C': 'substrate_temp_C', 'anneal_temp_PDA_C': 'anneal_temp_C', 'post_anneal_temp_C': 'anneal_temp_C', 'anneal_duration': 'anneal_duration_min', 'anneal_duration_min': 'anneal_duration_min', 'ald_cycle_count': 'n_cycles', 'num_cycles_or_thickness': 'n_cycles', 'chamber_base_pressure_Torr': 'pressure_mTorr', 'chamber_base_pressure_mTorr': 'pressure_mTorr', 'chamber_pressure': 'pressure_mTorr', 'anneal_atmosphere': 'anneal_ambient', 'post_anneal_atm': 'anneal_ambient', 'precursor_type_Hf': 'precursor_type', 'precursor_metal': 'precursor_type', 'precursor_oxidant': 'oxidant_type', 'oxidant_type': 'oxidant_type'}
        df = df.rename(columns={k: v for k, v in proc_renames.items() if k in df.columns})
        if 'gpc_nm_per_cycle' in df.columns:
            df['growth_rate_A_per_cycle'] = pd.to_numeric(df['gpc_nm_per_cycle'], errors='coerce') * 10.0
            df = df.drop(columns=['gpc_nm_per_cycle'])
            log.debug('FIX-T3-1: gpc_nm_per_cycle → growth_rate_A_per_cycle (×10)')
        if 'film_thickness_nm' in df.columns:
            df['film_thickness_A'] = pd.to_numeric(df['film_thickness_nm'], errors='coerce') * 10.0
            df = df.drop(columns=['film_thickness_nm'])
            log.debug('FIX-T3-1: film_thickness_nm → film_thickness_A (×10)')
        if 'pressure_mTorr' in df.columns:
            df['pressure_mTorr'] = pd.to_numeric(df['pressure_mTorr'], errors='coerce') * 1000.0
            n_p = int(df['pressure_mTorr'].notna().sum())
            log.debug('BUG-3 FIX: pressure_mTorr ← chamber_base_pressure_Torr ×1000  (%d rows,  range [%.2e, %.2e] mTorr)', n_p, float(df['pressure_mTorr'].min()) if n_p > 0 else float('nan'), float(df['pressure_mTorr'].max()) if n_p > 0 else float('nan'))
        if 'anneal_duration_min' in df.columns:
            import re as _re_dur

            def _parse_duration_to_min(raw) -> float:
                if raw is None or (isinstance(raw, float) and np.isnan(raw)):
                    return float('nan')
                s = str(raw).strip().lower()
                if not s or s in ('nan', 'none', 'n/a', '-'):
                    return float('nan')
                m = _re_dur.match('^(\\d+\\.?\\d*)\\s*s(?:ec(?:onds?)?)?$', s)
                if m:
                    return float(m.group(1)) / 60.0
                m = _re_dur.match('^(\\d+\\.?\\d*)\\s*m(?:in(?:utes?)?)?$', s)
                if m:
                    return float(m.group(1))
                m = _re_dur.match('^(\\d+\\.?\\d*)\\s*h(?:r|ours?)?$', s)
                if m:
                    return float(m.group(1)) * 60.0
                try:
                    return float(s)
                except ValueError:
                    log.debug("BUG-4: anneal_duration_min unparseable value '%s' → NaN", raw)
                    return float('nan')
            n_before = int(df['anneal_duration_min'].notna().sum())
            df['anneal_duration_min'] = df['anneal_duration_min'].apply(_parse_duration_to_min)
            n_after = int(df['anneal_duration_min'].notna().sum())
            log.debug('BUG-4 FIX: anneal_duration_min unit-parse: %d non-null strings → %d valid floats (minutes)', n_before, n_after)
        _proc_num_final = ['substrate_temp_C', 'anneal_temp_C', 'anneal_duration_min', 'growth_rate_A_per_cycle', 'n_cycles', 'film_thickness_A', 'pressure_mTorr']
        for _col in _proc_num_final:
            if _col in df.columns:
                _before = int(df[_col].notna().sum())
                df[_col] = pd.to_numeric(df[_col], errors='coerce')
                _after = int(df[_col].notna().sum())
                if _before != _after:
                    log.debug('FIX-PROC-COERCE: %s coerced %d non-numeric strings → NaN  (%d → %d valid rows)', _col, _before - _after, _before, _after)
        proc_num_cols = ['substrate_temp_C', 'anneal_temp_C', 'anneal_duration_min', 'growth_rate_A_per_cycle', 'n_cycles', 'film_thickness_A', 'pressure_mTorr']
        proc_cat_cols = ['anneal_ambient', 'precursor_type', 'oxidant_type']
        for col in proc_num_cols + proc_cat_cols:
            n_filled = int(df[col].notna().sum()) if col in df.columns else 0
            pct = 100.0 * n_filled / max(len(df), 1)
            log.debug('  FIX-T3-1 proc col %-28s  %d/%d rows filled  (%.1f%%)', col + ':', n_filled, len(df), pct)
        if 'k_measured' in df.columns:
            df['k_total'] = df['k_measured']
        else:
            df['k_total'] = np.nan

        def _safe_hash_val(row, *keys):
            for k in keys:
                v = row.get(k, None)
                if v is not None and str(v) not in ('nan', 'None', ''):
                    return str(v)
            return '?'
        df['row_hash'] = [hashlib.md5(f"EXP_{_safe_hash_val(row, 'paper_id', 'doi')}_{_safe_hash_val(row, 'material')}_{_safe_hash_val(row, 'substrate_temp_C')}_{_safe_hash_val(row, 'precursor_type')}_{_safe_hash_val(row, 'oxidant_type')}_{_safe_hash_val(row, 'n_cycles')}_{idx}".encode()).hexdigest()[:12] for idx, row in enumerate(df.to_dict('records'))]
        log.debug('Experimental process DB loaded: %d rows', len(df))
        return df

    @staticmethod
    def _compute_k_from_tensor(eps_ionic: Any, eps_elec: Any) -> Optional[float]:
        """Compute scalar isotropic dielectric constant from ionic + electronic
        contributions, each of which may be a 3x3 tensor or scalar."""

        def _tensor_trace_avg(x):
            if x is None or x == 'na' or x == '':
                return None
            try:
                if isinstance(x, (list, tuple)):
                    arr = np.array(x, dtype=float)
                    if arr.ndim == 2 and arr.shape == (3, 3):
                        return float(np.mean(np.diag(arr)))
                    elif arr.ndim == 1 and len(arr) == 3:
                        return float(np.mean(arr))
                    elif arr.ndim == 1 and len(arr) == 1:
                        return float(arr[0])
                return float(x)
            except Exception:
                return None
        ionic = _tensor_trace_avg(eps_ionic)
        elec = _tensor_trace_avg(eps_elec)
        if ionic is not None and elec is not None:
            return ionic + elec
        elif ionic is not None:
            return ionic
        elif elec is not None:
            return elec
        return None

    @staticmethod
    def _safe_float(x: Any) -> Optional[float]:
        """Convert to float, returning np.nan on failure."""
        if x is None or x == 'na' or x == '':
            return float('nan')
        try:
            v = float(x)
            return float('nan') if np.isnan(v) or np.isinf(v) else v
        except Exception:
            return float('nan')
