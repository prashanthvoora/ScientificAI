"""Attach rank-local samplers to prepared, immutable dataset subsets."""
from .common import DataLoader, Subset, _DIST
from .splits import BalancedDistributedSampler

def bind_training_loader(loader):
    if loader is None:
        return None, None
    subset = loader.dataset
    if not isinstance(subset, Subset):
        raise TypeError('Expected a prepared Subset.')
    dataset = subset.dataset
    flags = [int(dataset.df.loc[dataset.valid_idx[int(i)], 'source'] == 'Experimental')
             if 'source' in dataset.df.columns else 0 for i in subset.indices]
    sampler = None
    if _DIST['active']:
        sampler = BalancedDistributedSampler(subset, flags, num_replicas=_DIST['world'],
                                             rank=_DIST['rank'], shuffle=True)
    result = DataLoader(subset, batch_size=loader.batch_size, shuffle=sampler is None,
                        sampler=sampler, num_workers=loader.num_workers,
                        collate_fn=loader.collate_fn, drop_last=loader.drop_last,
                        pin_memory=loader.pin_memory)
    if len(result) == 0:
        raise RuntimeError('Prepared TRAIN is too small for this batch size/world size.')
    return result, sampler

def bind_state(state):
    state = dict(state)
    state['train_loader'], state['train_sampler'] = bind_training_loader(state['train_loader'])
    if state.get('pa_loader') is not None:
        state['pa_loader'], _ = bind_training_loader(state['pa_loader'])
    return state
