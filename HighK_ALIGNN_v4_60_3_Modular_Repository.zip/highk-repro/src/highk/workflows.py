from __future__ import annotations
from .trainer import ALIGNNTrainer
from .common import ALIGNN_BASE_CONFIG, CKPT_ROOT, Optional, PROCESS_PARAMS_FEATURES, Path, REPORT_ROOT, TIER3_TEST_SPLIT_PATH, _DIST, json, log, math, np, pd, torch
from .model import HighKALIGNN, _remap_state_dict
from .distributed import dist_barrier, is_rank0
from .graph_data import infer_material_family_from_row, material_family_log_offset_from_row
from .cache import safe_load_checkpoint

def run_tier1_pretrain(state, pretrained_weights=None, ablate_context=False):
    _main_ds_t1 = state['_main_ds_t1']
    cfg = state['cfg']
    task_names = state['task_names']
    test_loader = state['test_loader']
    train_loader = state['train_loader']
    train_sampler = state['train_sampler']
    val_loader = state['val_loader']
    df_tier1 = state['df_tier1']
    model = HighKALIGNN(config=ALIGNN_BASE_CONFIG, task_names=task_names)
    model.fit_encoder_stats(df_tier1)
    trainer = ALIGNNTrainer(model, cfg, ckpt_prefix='tier1', ablate_context=ablate_context)
    history = trainer.train(train_loader, val_loader, target_col=cfg['target'], train_sampler=train_sampler)
    best_ckpt = CKPT_ROOT / 'tier1_best.pt'
    dist_barrier()
    ckpt = safe_load_checkpoint(best_ckpt)
    if ckpt is not None:
        trainer.model_core.load_state_dict(ckpt['model_state_dict'], strict=False)
    else:
        log.warning('Could not load best checkpoint; evaluating with final weights.')
    test_mae, test_rmse = trainer.evaluate(test_loader, cfg['target'])
    log.info('Tier 1 TEST  MAE=%.4f  RMSE=%.4f  (target: %s)', test_mae, test_rmse, cfg['target'])
    mt_results = trainer.evaluate_multitask(test_loader, cfg, df_full=_main_ds_t1.df)
    trainer.print_multitask_results(mt_results, split_name='TEST', tier_name='TIER 1')
    out_path = REPORT_ROOT / 'tier1_test_results.json'
    if is_rank0():
        with open(out_path, 'w') as f:
            json.dump({'primary_mae': test_mae, 'primary_rmse': test_rmse, 'multitask': mt_results}, f, indent=2)
    log.debug('Tier 1 test results saved -> %s', out_path)
    return CKPT_ROOT / 'tier1_best.pt'

def run_tier2_finetune(state, pretrained_weights=None, ablate_context=False):
    _main_ds_t2 = state['_main_ds_t2']
    cfg = state['cfg']
    df_t2_k = state['df_t2_k']
    target_col = state['target_col']
    task_names = state['task_names']
    test_loader = state['test_loader']
    train_loader = state['train_loader']
    train_sampler = state['train_sampler']
    val_loader = state['val_loader']
    df_tier2 = state['df_tier2']
    pa_loader = state['pa_loader']
    model = HighKALIGNN(config=ALIGNN_BASE_CONFIG, task_names=task_names)
    model.load_pretrained_weights(pretrained_weights, strict=False)
    model.fit_encoder_stats(df_t2_k)
    model.unfreeze_all()
    trainer = ALIGNNTrainer(model, cfg, ckpt_prefix='tier2', ablate_context=ablate_context)
    phase_a_target = cfg.get('phase_a_target', 'band_gap')
    phase_a_epochs = cfg.get('phase_a_epochs', 30)
    log.debug('Tier 2 Phase A: ALL oxide rows=%d  target=%s  epochs=%d', len(df_tier2), phase_a_target, phase_a_epochs)
    pa_loader = state['pa_loader']
    pa_sampler = pa_loader.sampler if _DIST['active'] else None
    cfg_pa = {**cfg, 'epochs': phase_a_epochs, 'scheduler': 'cosine', 'early_stopping': False}
    trainer.cfg = cfg_pa
    sched_pa = trainer.build_scheduler(len(pa_loader), phase_a_epochs)
    for epoch in range(1, phase_a_epochs + 1):
        ep_stats = trainer.train_epoch(pa_loader, sched_pa, phase_a_target)
        log.info('Phase A  ep %3d/%d  loss=%.4f', epoch, phase_a_epochs, ep_stats['loss'])
    log.debug('Tier 2 Phase B: k_total_log rows=%d  lr=%.2e  epochs=%d', len(df_t2_k), cfg.get('learning_rate_unfreeze', cfg['learning_rate'] * 0.5), cfg['epochs'] - phase_a_epochs)
    trainer.optimizer = torch.optim.AdamW(model.parameters(), lr=cfg.get('learning_rate_unfreeze', cfg['learning_rate'] * 0.5), weight_decay=cfg['weight_decay'])
    remaining_epochs = cfg['epochs'] - phase_a_epochs
    cfg_pb = {**cfg, 'epochs': remaining_epochs}
    trainer.cfg = cfg_pb
    history = trainer.train(train_loader, val_loader, target_col=target_col, train_sampler=train_sampler)
    best_ckpt = CKPT_ROOT / 'tier2_best.pt'
    dist_barrier()
    ckpt = safe_load_checkpoint(best_ckpt)
    if ckpt is not None:
        trainer.model_core.load_state_dict(ckpt['model_state_dict'], strict=False)
    else:
        log.warning('Could not load best checkpoint; evaluating with final weights.')
    test_mae_log, test_rmse_log, preds_log, trues_log = trainer.evaluate(test_loader, target_col, return_preds=True)
    if cfg.get('log_transform', False):
        valid = ~torch.isnan(trues_log)
        p_valid = preds_log[valid]
        t_valid = trues_log[valid]
        mae_k_exact = (torch.exp(p_valid) - torch.exp(t_valid)).abs().mean().item()
        rmse_k_exact = ((torch.exp(p_valid) - torch.exp(t_valid)) ** 2).mean().sqrt().item()
        _t2_true_k = torch.exp(t_valid).cpu().numpy()
        mad_k_exact = float(np.mean(np.abs(_t2_true_k - np.mean(_t2_true_k))))
        mad_mae_k_exact = mad_k_exact / mae_k_exact if mae_k_exact > 0 else float('nan')
        n_k_exact = int(valid.sum().item())
        log.debug('')
        log.debug('─' * 68)
        log.debug('  TIER 2 TEST RESULTS  (k_total_log target)')
        log.debug('─' * 68)
        log.debug('  Diagnostic log-space  MAE  = %.4f  [log(k) units]', test_mae_log)
        log.debug('  Diagnostic log-space  RMSE = %.4f', test_rmse_log)
        log.debug('  exp(MAE)                  = %.4f×  → ±%.1f%% average relative error', math.exp(test_mae_log), (math.exp(test_mae_log) - 1) * 100)
        log.debug('')
        log.debug('  PRIMARY benchmark (linear-k) MAE  = %.4f  [dielectric units, exact]', mae_k_exact)
        log.debug('  PRIMARY benchmark (linear-k) RMSE = %.4f  [dielectric units]', rmse_k_exact)
        log.debug('  Benchmark scale for publication: LINEAR-K')
        log.debug('  ALIGNN paper    MAE  ≈ 0.81  [linear k, JARVIS DFPT, k range 5–100]')
        log.debug('  Our distribution     k = 3.9–386 (100× wider → higher linear MAE expected)')
        log.debug('  MAD:MAE (benchmark scale)  — see multitask table below for full breakdown')
        log.debug('─' * 68)
    else:
        log.info('Tier 2 TEST  MAE=%.4f  RMSE=%.4f  (target: k_total)', test_mae_log, test_rmse_log)
    mt_results = trainer.evaluate_multitask(test_loader, cfg, df_full=_main_ds_t2.df)
    if cfg.get('log_transform', False) and cfg['target'] in mt_results:
        mt_results[cfg['target']].update({'mae_log': float(test_mae_log), 'rmse_log': float(test_rmse_log), 'mae_linear': float(mae_k_exact), 'rmse_linear': float(rmse_k_exact), 'mad_linear': float(mad_k_exact), 'mad_mae_linear': float(mad_mae_k_exact), 'mae': float(mae_k_exact), 'rmse': float(rmse_k_exact), 'mad': float(mad_k_exact), 'mad_mae_ratio': float(mad_mae_k_exact), 'n': int(n_k_exact), 'coverage_pct': 100.0, 'mad_source': 'same fixed TEST rows as primary evaluation', 'metric_scale': 'dual: log diagnostic + linear exact', 'display_name': 'k_total'})
    trainer.print_multitask_results(mt_results, split_name='TEST', tier_name='TIER 2')
    out_path = REPORT_ROOT / 'tier2_test_results.json'
    primary_metrics = {'mae': test_mae_log, 'rmse': test_rmse_log, 'mae_log_k': test_mae_log, 'rmse_log_k': test_rmse_log, 'exp_mae_multiplier': math.exp(test_mae_log), 'benchmark_scale': 'linear', 'diagnostic_scale': 'log'}
    if cfg.get('log_transform', False):
        primary_metrics['mae_linear_k'] = mae_k_exact
        primary_metrics['rmse_linear_k'] = rmse_k_exact
        primary_metrics['mad_linear_k'] = mad_k_exact
        primary_metrics['mad_mae_linear'] = mad_mae_k_exact
        primary_metrics['n_test'] = n_k_exact
        primary_metrics['mae'] = mae_k_exact
        primary_metrics['rmse'] = rmse_k_exact
    if is_rank0():
        with open(out_path, 'w') as f:
            json.dump({'primary': primary_metrics, 'multitask': mt_results}, f, indent=2)
    log.debug('Tier 2 test results saved → %s', out_path)
    return CKPT_ROOT / 'tier2_best.pt'

def run_tier3_finetune(state, pretrained_weights=None, ablate_context=False):
    _canonical_test_n = state['_canonical_test_n']
    _canonical_val_n = state['_canonical_val_n']
    _main_ds_t3 = state['_main_ds_t3']
    _n_phase_b = state['_n_phase_b']
    _tier3_disjoint_val_active = state['_tier3_disjoint_val_active']
    cfg = state['cfg']
    df_phase_b = state['df_phase_b']
    df_structural = state['df_structural']
    task_names_t3 = state['task_names_t3']
    test_loader = state['test_loader']
    train_loader = state['train_loader']
    train_sampler = state['train_sampler']
    val_loader = state['val_loader']
    pa_loader = state['pa_loader']
    model = HighKALIGNN(config=ALIGNN_BASE_CONFIG, task_names=task_names_t3)
    model.load_pretrained_weights(pretrained_weights, strict=False)
    model.configure_bounded_process_residual(enabled=cfg.get('bounded_process_residual', False), bound=cfg.get('process_delta_bound', 0.1), use_categorical=cfg.get('process_delta_use_categorical', False))
    model.configure_structural_adapter(enabled=cfg.get('tier3_use_structural_adapter', True), rank=cfg.get('tier3_structural_adapter_rank', 16), reset=True)
    if cfg.get('bounded_process_residual', False):
        model.reset_bounded_process_residual(seed=cfg.get('process_delta_init_seed', 42))
    model.unfreeze_all()
    model.fit_encoder_stats(df_structural)
    trainer = ALIGNNTrainer(model, cfg, ckpt_prefix='tier3', ablate_context=ablate_context)

    def _eval_exact_k_for_diag(loader, split_name: str, stage_name: str) -> dict:
        """Evaluate log-space and exact linear-k metrics for Tier-3 diagnostics."""
        mae_log, rmse_log, preds_log, trues_log = trainer.evaluate(loader, cfg['target'], return_preds=True)
        out = {'stage': stage_name, 'split': split_name, 'mae_log': float(mae_log), 'rmse_log': float(rmse_log), 'mae_k': float('nan'), 'rmse_k': float('nan'), 'mad_k': float('nan'), 'mad_mae_k': float('nan'), 'n': 0}
        if cfg.get('log_transform', False) and trues_log.numel() > 0:
            valid = ~torch.isnan(trues_log)
            out['n'] = int(valid.sum())
            if out['n'] > 0:
                p_lin = torch.exp(preds_log[valid])
                t_lin = torch.exp(trues_log[valid])
                out['mae_k'] = float((p_lin - t_lin).abs().mean().item())
                out['rmse_k'] = float(((p_lin - t_lin) ** 2).mean().sqrt().item())
                t_np = t_lin.cpu().numpy()
                out['mad_k'] = float(np.mean(np.abs(t_np - np.mean(t_np))))
                out['mad_mae_k'] = out['mad_k'] / out['mae_k'] if out['mae_k'] > 0 else float('nan')
        _expected_diag_n = _canonical_val_n if split_name.upper() == 'VAL' else _canonical_test_n
        if split_name.upper() in ('VAL', 'TEST') and out['n'] != _expected_diag_n:
            raise RuntimeError(f"v4.43 AUDIT COUNT MISMATCH at {stage_name}/{split_name}: observed N={out['n']} expected N={_expected_diag_n}")
        log.debug('RESIDUAL-PROC-DIAG | %-18s | %-5s | log_MAE=%.4f log_RMSE=%.4f | linear_MAE=%.4f linear_RMSE=%.4f MAD=%.4f MAD:MAE=%.2f N=%d', stage_name, split_name, out['mae_log'], out['rmse_log'], out['mae_k'], out['rmse_k'], out['mad_k'], out['mad_mae_k'], out['n'])
        return out

    def _write_tier3_prediction_audit(loader, df_ref: pd.DataFrame, split_name: str, stage_name: str, top_n: int=20) -> Optional[Path]:
        """Dump per-row Tier-3 prediction, residual, donor, and error diagnostics."""
        if not is_rank0():
            return None
        audit_dir = REPORT_ROOT / 'tier3_prediction_audit' / ('ablation' if trainer.ablate_context else 'normal')
        audit_dir.mkdir(parents=True, exist_ok=True)
        safe_stage = str(stage_name).replace('/', '_').replace(' ', '_')
        safe_split = str(split_name).lower().replace('/', '_').replace(' ', '_')
        model_core = trainer.model_core
        model_core.eval()
        rows = []

        def _row_val(row, *cols, default=''):
            for c in cols:
                if c in row.index:
                    v = row.get(c)
                    try:
                        if pd.isna(v):
                            continue
                    except Exception:
                        pass
                    return v
            return default
        with torch.no_grad():
            for batch in loader:
                if batch is None:
                    continue
                graph = batch['graph'].to(trainer.device)
                line_graph = batch['line_graph'].to(trainer.device)
                target = batch['target'].detach().cpu().view(-1)
                proc_ctx_original = batch.get('proc_context')
                stack_ctx_original = batch.get('stack_context')
                proc_ctx = proc_ctx_original
                stack_ctx = stack_ctx_original
                if proc_ctx is not None:
                    proc_ctx = {k: v.to(trainer.device) for k, v in proc_ctx.items()}
                    stack_ctx = {k: v.to(trainer.device) for k, v in stack_ctx.items()}
                if trainer.ablate_context:
                    proc_ctx = stack_ctx = None
                func_code = batch.get('functional_code')
                if func_code is not None:
                    func_code = func_code.to(trainer.device)
                embedding = model_core.backbone((graph, line_graph, None))
                if not getattr(model_core, 'use_bounded_process_residual', False):
                    embedding = model_core.dropout(embedding)
                embedding = model_core._apply_func_conditioning(embedding, func_code)
                task_name = cfg['target']
                base_log = model_core.task_heads[task_name](embedding).detach().cpu().view(-1)
                raw_delta = torch.zeros_like(base_log)
                bounded_learned_delta = torch.zeros_like(base_log)
                family_offset_delta = torch.zeros_like(base_log)
                delta_log = torch.zeros_like(base_log)
                if getattr(model_core, 'use_bounded_process_residual', False) and proc_ctx is not None:
                    dev = trainer.device
                    avail_t = proc_ctx['avail'].to(dev)
                    num_t = proc_ctx['num'].to(dev)
                    num_norm = (num_t - model_core.proc_encoder.num_mean.to(dev)) / model_core.proc_encoder.num_std.to(dev)
                    num_norm = num_norm * avail_t
                    if model_core.process_delta_use_categorical:
                        cat_t = proc_ctx['cat'].to(dev)
                        cat_embs = [model_core.proc_encoder.embeddings[name](cat_t[:, i]) for i, name in enumerate(model_core.proc_encoder._cat_cols)]
                        x_delta = torch.cat([num_norm] + cat_embs, dim=-1)
                    else:
                        n_extra = model_core.process_delta_head[0].in_features - num_norm.shape[-1]
                        x_delta = torch.cat([num_norm, torch.zeros(num_norm.shape[0], max(n_extra, 0), device=dev)], dim=-1) if n_extra > 0 else num_norm
                    raw_t = model_core.process_delta_head(x_delta)
                    bounded_t = model_core.process_delta_bound * torch.tanh(raw_t) * avail_t
                    family_t = proc_ctx.get('family_offset', torch.zeros_like(avail_t)).to(dev)
                    raw_delta = raw_t.detach().cpu().view(-1)
                    bounded_learned_delta = bounded_t.detach().cpu().view(-1)
                    family_offset_delta = family_t.detach().cpu().view(-1)
                    delta_log = bounded_learned_delta + family_offset_delta
                pred_log = base_log + delta_log
                row_indices = batch.get('row_indices')
                if row_indices is None:
                    row_indices = torch.arange(len(pred_log))
                row_indices = row_indices.detach().cpu().view(-1).tolist()
                proc_avail = None
                proc_num_cpu = None
                proc_cat_cpu = None
                if proc_ctx_original is not None and 'avail' in proc_ctx_original:
                    proc_avail = proc_ctx_original['avail'].detach().cpu().view(-1).tolist()
                    proc_num_cpu = proc_ctx_original['num'].detach().cpu()
                    proc_cat_cpu = proc_ctx_original['cat'].detach().cpu()
                for j, row_idx in enumerate(row_indices):
                    if row_idx not in df_ref.index:
                        continue
                    meta = df_ref.loc[row_idx]
                    true_log = float(target[j].item()) if j < len(target) and (not torch.isnan(target[j])) else float('nan')
                    pred_l = float(pred_log[j].item())
                    base_l = float(base_log[j].item())
                    delta_l = float(delta_log[j].item())
                    if cfg.get('log_transform', False):
                        k_true = float(math.exp(true_log)) if np.isfinite(true_log) else float('nan')
                        k_pred = float(math.exp(pred_l)) if np.isfinite(pred_l) else float('nan')
                        k_dft = float(math.exp(base_l)) if np.isfinite(base_l) else float('nan')
                    else:
                        k_true, k_pred, k_dft = (true_log, pred_l, base_l)
                    abs_error = abs(k_pred - k_true) if np.isfinite(k_true) and np.isfinite(k_pred) else float('nan')
                    log_error = abs(pred_l - true_log) if np.isfinite(true_log) and np.isfinite(pred_l) else float('nan')
                    rows.append({'stage': stage_name, 'split': split_name, 'dataset_row_idx': int(row_idx), 'split_identity': _tier3_split_key_from_row(meta), 'row_id': _row_val(meta, 'row_id', default=''), 'paper_id': _row_val(meta, 'paper_id', default=''), 'doi': _row_val(meta, 'doi', default=''), 'data_quality': _row_val(meta, 'data_quality', default=''), 'source': _row_val(meta, 'source', default=''), 'material': _row_val(meta, 'material', 'material_system', default=''), 'material_family': _row_val(meta, 'material_family', default=''), 'material_family_offset_log': _row_val(meta, 'material_family_offset_log', default=material_family_log_offset_from_row(meta)), 'formula': _row_val(meta, 'formula', 'composition', default=''), 'k_true': k_true, 'k_pred': k_pred, 'k_dft': k_dft, 'raw_process_delta': float(raw_delta[j].item()) if j < len(raw_delta) else 0.0, 'bounded_process_delta': float(bounded_learned_delta[j].item()) if j < len(bounded_learned_delta) else 0.0, 'family_offset_delta': float(family_offset_delta[j].item()) if j < len(family_offset_delta) else 0.0, 'delta_log_pred': delta_l, 'delta_k_pred': k_pred - k_dft if np.isfinite(k_pred) and np.isfinite(k_dft) else float('nan'), 'abs_error': abs_error, 'log_error': log_error, 'k_true_log': true_log, 'k_pred_log': pred_l, 'k_dft_log': base_l, 'prediction_decomposition_error': pred_l - (base_l + delta_l) if np.isfinite(pred_l) and np.isfinite(base_l) and np.isfinite(delta_l) else float('nan'), 'proc_avail': proc_avail[j] if proc_avail is not None and j < len(proc_avail) else float('nan'), 'process_numeric_feature_count': int(torch.count_nonzero(proc_num_cpu[j]).item()) if proc_num_cpu is not None and j < len(proc_num_cpu) else 0, 'process_categorical_feature_count': int(torch.count_nonzero(proc_cat_cpu[j] >= 0).item()) if proc_cat_cpu is not None and j < len(proc_cat_cpu) else 0, 'process_feature_count': int(torch.count_nonzero(proc_num_cpu[j]).item()) + int(torch.count_nonzero(proc_cat_cpu[j] >= 0).item()) if proc_num_cpu is not None and proc_cat_cpu is not None and (j < len(proc_num_cpu)) else 0, 'process_feature_mask': '|'.join((str(int(abs(float(v)) > 0.0)) for v in proc_num_cpu[j].tolist())) if proc_num_cpu is not None and j < len(proc_num_cpu) else '', 'is_experimental': int(str(_row_val(meta, 'source', default='')) == 'Experimental'), 'imputed_structure': bool(_row_val(meta, 'imputed_structure', default=False)), 'has_structure': bool(_row_val(meta, 'has_structure', default=False)), 'donor_id': _row_val(meta, 'imputed_from', 'jid', 'mp_id', default=''), 'donor_formula': _row_val(meta, 'imputed_donor_formula', default=''), 'donor_source': _row_val(meta, 'imputed_donor_source', default=''), 'donor_strategy': _row_val(meta, 'imputed_donor_strategy', default=''), 'donor_phase': _row_val(meta, 'imputed_phase_hint', default=''), 'donor_score': _row_val(meta, 'imputed_donor_score', default=''), 'candidate_formulas': _row_val(meta, 'imputed_candidate_formulas', default=''), 'substrate_temp_C': _row_val(meta, 'substrate_temp_C', 'ald_substrate_temp_C', default=''), 'precursor_type': _row_val(meta, 'precursor_type', 'precursor_type_Hf', default=''), 'oxidant_type': _row_val(meta, 'oxidant_type', default=''), 'n_cycles': _row_val(meta, 'n_cycles', 'ald_cycle_count', default=''), 'film_thickness_A': _row_val(meta, 'film_thickness_A', default=''), 'film_thickness_nm': _row_val(meta, 'film_thickness_nm', default=''), 'anneal_temp_C': _row_val(meta, 'anneal_temp_C', 'anneal_temp_PDA_C', default=''), 'anneal_ambient': _row_val(meta, 'anneal_ambient', 'anneal_atmosphere', default=''), 'anneal_duration_min': _row_val(meta, 'anneal_duration_min', 'anneal_duration', default=''), 'substrate_type': _row_val(meta, 'substrate_type', 'substrate', default=''), 'stack_structure': _row_val(meta, 'stack_structure', 'stack_config', default='')})
        audit_df = pd.DataFrame(rows)
        if safe_split in ('test', 'val'):
            _expected_audit_n = _canonical_val_n if safe_split == 'val' else _canonical_test_n
            if len(audit_df) != _expected_audit_n:
                raise RuntimeError(f'v4.41 prediction audit count mismatch {safe_stage}/{safe_split}: {len(audit_df)} != {_expected_audit_n}')
            if 'split_identity' in audit_df.columns and audit_df['split_identity'].duplicated().any():
                dups = int(audit_df['split_identity'].duplicated().sum())
                raise RuntimeError(f'v4.41 prediction audit has {dups} duplicate split keys at {safe_stage}/{safe_split}')
        pred_path = audit_dir / f'tier3_{safe_stage}_{safe_split}_prediction_audit.csv'
        top_path = audit_dir / f'tier3_{safe_stage}_{safe_split}_top{top_n}_errors.csv'
        mat_path = audit_dir / f'tier3_{safe_stage}_{safe_split}_material_statistics.csv'
        donor_path = audit_dir / f'tier3_{safe_stage}_{safe_split}_donor_statistics.csv'
        resid_path = audit_dir / f'tier3_{safe_stage}_{safe_split}_residual_statistics.csv'
        if len(audit_df) == 0:
            audit_df.to_csv(pred_path, index=False)
            log.warning('Tier3 audit %s/%s: no rows written → %s', stage_name, split_name, pred_path)
            return pred_path
        audit_df = audit_df.sort_values('abs_error', ascending=False, na_position='last')
        audit_df.to_csv(pred_path, index=False)
        audit_df.head(top_n).to_csv(top_path, index=False)
        if 'material' in audit_df.columns:
            mat_stats = audit_df.groupby(['material', 'material_family'], dropna=False).agg(n=('abs_error', 'count'), mean_abs_error=('abs_error', 'mean'), std_abs_error=('abs_error', 'std'), max_abs_error=('abs_error', 'max'), mean_k_true=('k_true', 'mean'), mean_k_pred=('k_pred', 'mean'), mean_delta_log=('delta_log_pred', 'mean')).reset_index().sort_values(['mean_abs_error', 'n'], ascending=[False, False])
            mat_stats.to_csv(mat_path, index=False)
        donor_keys = ['donor_formula', 'donor_phase', 'donor_strategy', 'donor_source']
        if all((k in audit_df.columns for k in donor_keys)):
            donor_stats = audit_df.groupby(donor_keys, dropna=False).agg(n=('abs_error', 'count'), mean_abs_error=('abs_error', 'mean'), std_abs_error=('abs_error', 'std'), max_abs_error=('abs_error', 'max'), mean_k_true=('k_true', 'mean'), mean_k_pred=('k_pred', 'mean'), mean_delta_log=('delta_log_pred', 'mean')).reset_index().sort_values(['mean_abs_error', 'n'], ascending=[False, False])
            donor_stats.to_csv(donor_path, index=False)
        resid_summary = pd.DataFrame([{'stage': stage_name, 'split': split_name, 'n': int(len(audit_df)), 'mean_abs_error': float(audit_df['abs_error'].mean()), 'median_abs_error': float(audit_df['abs_error'].median()), 'mean_log_error': float(audit_df['log_error'].mean()), 'mean_k_true': float(audit_df['k_true'].mean()), 'mean_k_pred': float(audit_df['k_pred'].mean()), 'mean_k_dft': float(audit_df['k_dft'].mean()), 'mean_delta_log_pred': float(audit_df['delta_log_pred'].mean()), 'std_delta_log_pred': float(audit_df['delta_log_pred'].std()), 'mean_delta_k_pred': float(audit_df['delta_k_pred'].mean()), 'max_abs_error': float(audit_df['abs_error'].max())}])
        resid_summary.to_csv(resid_path, index=False)
        subgroup_rows = []
        subgroup_defs = {'all': pd.Series(True, index=audit_df.index), 'experimental': audit_df['is_experimental'].astype(bool), 'native_dft': ~audit_df['is_experimental'].astype(bool), 'imputed_experimental': audit_df['is_experimental'].astype(bool) & audit_df['imputed_structure'].astype(bool), 'proc_available': pd.to_numeric(audit_df['proc_avail'], errors='coerce').fillna(0).gt(0), 'proc_unavailable': pd.to_numeric(audit_df['proc_avail'], errors='coerce').fillna(0).le(0), 'experimental_proc_available': audit_df['is_experimental'].astype(bool) & pd.to_numeric(audit_df['proc_avail'], errors='coerce').fillna(0).gt(0)}
        for subgroup, mask in subgroup_defs.items():
            g = audit_df[mask]
            if len(g) == 0:
                continue
            log_err = pd.to_numeric(g['log_error'], errors='coerce').dropna()
            abs_err = pd.to_numeric(g['abs_error'], errors='coerce').dropna()
            subgroup_rows.append({'stage': stage_name, 'split': split_name, 'subgroup': subgroup, 'n': int(len(g)), 'log_mae': float(log_err.mean()) if len(log_err) else float('nan'), 'linear_mae': float(abs_err.mean()) if len(abs_err) else float('nan'), 'linear_rmse': float(np.sqrt(np.mean(np.square(pd.to_numeric(g['k_pred'], errors='coerce') - pd.to_numeric(g['k_true'], errors='coerce'))))), 'mean_raw_delta': float(pd.to_numeric(g['raw_process_delta'], errors='coerce').mean()), 'mean_abs_bounded_delta': float(pd.to_numeric(g['bounded_process_delta'], errors='coerce').abs().mean()), 'mean_process_feature_count': float(pd.to_numeric(g['process_feature_count'], errors='coerce').mean())})
        subgroup_path = audit_dir / f'tier3_{safe_stage}_{safe_split}_subgroup_metrics.csv'
        pd.DataFrame(subgroup_rows).to_csv(subgroup_path, index=False)
        log.debug('Tier3 audit written [%s/%s]: rows=%d  pred=%s  top=%s  material=%s  donor=%s  residual=%s', stage_name, split_name, len(audit_df), pred_path, top_path, mat_path, donor_path, resid_path)
        return pred_path

    def _write_tier3_dataset_composition_audit():
        if not is_rank0() or not cfg.get('audit_write_dataset_composition', False):
            return
        audit_dir = REPORT_ROOT / 'tier3_prediction_audit' / ('ablation' if trainer.ablate_context else 'normal')
        audit_dir.mkdir(parents=True, exist_ok=True)
        df_a = _main_ds_t3.df.copy()
        split_map = {}
        for label, subset in [('train', train_loader.dataset), ('val', val_loader.dataset), ('test', test_loader.dataset)]:
            for pos in getattr(subset, 'indices', []):
                if 0 <= int(pos) < len(_main_ds_t3.valid_idx):
                    split_map[int(_main_ds_t3.valid_idx[int(pos)])] = label
        rows = []
        proc_cols = list(PROCESS_PARAMS_FEATURES['numerical']) + list(PROCESS_PARAMS_FEATURES['categorical'].keys())
        for idx, r in df_a.iterrows():
            count = sum((0 if pd.isna(r.get(c, np.nan)) else 1 for c in proc_cols))
            rows.append({'dataset_row_idx': int(idx), 'row_id': r.get('row_id', ''), 'source': r.get('source', ''), 'material': r.get('material', r.get('material_system', '')), 'formula': r.get('formula', ''), 'material_family': infer_material_family_from_row(r), 'is_experimental': int(str(r.get('source', '')) == 'Experimental'), 'imputed_structure': bool(r.get('imputed_structure', False)), 'imputed_from': r.get('imputed_from', ''), 'has_structure': bool(r.get('has_structure', False)), 'target_valid': bool(pd.notna(r.get(cfg['target'], np.nan))), 'process_feature_count': int(count), 'proc_avail': int(count > 0), 'split': split_map.get(int(idx), 'excluded')})
        comp = pd.DataFrame(rows)
        comp_path = audit_dir / 'tier3_dataset_composition.csv'
        comp.to_csv(comp_path, index=False)
        summary = comp.groupby(['split', 'source', 'imputed_structure', 'proc_avail'], dropna=False).size().reset_index(name='n')
        summary.to_csv(audit_dir / 'tier3_dataset_composition_summary.csv', index=False)
        observed_test = int((comp['split'] == 'test').sum())
        observed_val = int((comp['split'] == 'val').sum())
        if observed_test != _canonical_test_n:
            raise RuntimeError(f'v4.42 composition TEST count {observed_test} != canonical {_canonical_test_n}')
        if _tier3_disjoint_val_active:
            if observed_val != _canonical_val_n:
                raise RuntimeError(f'DISJOINT-VAL composition VAL count {observed_val} != canonical {_canonical_val_n}')
            log.debug('DISJOINT-VAL AUDIT dataset composition written: %s (train-disjoint val=%d, test=%d)', comp_path, observed_val, observed_test)
    _write_tier3_dataset_composition_audit()
    log.debug('─' * 68)
    log.debug('RESIDUAL-PROC-DIAG: epoch-0 baseline before any Tier-3 gradient update')
    log.debug('Purpose: if epoch-0/epoch-1 already matches final performance, the gain is from the loaded Tier-2 DFT baseline rather than Tier-3 process-residual learning.')
    diag_epoch0_val = _eval_exact_k_for_diag(val_loader, 'VAL', 'epoch0_pretrain')
    diag_epoch0_test = None
    _write_tier3_prediction_audit(val_loader, _main_ds_t3.df, 'VAL', 'epoch0_pretrain')
    log.debug('BASELINE TEST-SEAL: TEST skipped at epoch 0; selection diagnostics use VAL only.')
    if cfg.get('bounded_process_residual', False) and np.isfinite(diag_epoch0_val.get('mae_log', float('nan'))):
        trainer.best_val_mae = float(diag_epoch0_val['mae_log'])
        trainer.best_epoch = 0
        trainer.patience_ctr = 0
        if is_rank0():
            trainer.save_checkpoint(0, trainer.best_val_mae, tag='best')
            trainer.save_checkpoint(0, trainer.best_val_mae, tag='epoch0')
        log.debug('v4.29: epoch-0 DFT baseline registered as best candidate (val_log_MAE=%.4f). Tier3 residual must improve over this to replace it.', trainer.best_val_mae)
    log.debug('─' * 68)
    phase_a_steps = cfg['phase_a_steps']
    if phase_a_steps > 0 and len(df_structural) > 0:
        df_pa = df_structural[df_structural['band_gap'].notna()].copy()
        log.debug('─' * 68)
        log.debug('TIER 3 PHASE A: band_gap consolidation (Tier 3 data) rows=%d  budget=%d  lr=%.2e', len(df_pa), phase_a_steps, cfg['phase_a_lr'])
        phase_b_steps = int(_n_phase_b * cfg['train_ratio'] / cfg['batch_size']) * cfg.get('epochs', 100)
        log.debug('  Purpose: anchor backbone in HfO2 family representation subspace  before Phase B k_total_log fine-tuningPhase A:Phase B step ratio = %d:%d = %.2fx', phase_a_steps, phase_b_steps, phase_a_steps / max(phase_b_steps, 1))
        pa_loader = state['pa_loader']
        pa_sampler = pa_loader.sampler if _DIST['active'] else None
        pa_optimizer = torch.optim.AdamW(model.parameters(), lr=cfg['phase_a_lr'], weight_decay=cfg['weight_decay'])
        _saved_cfg = trainer.cfg
        _saved_optimizer = trainer.optimizer
        trainer.optimizer = pa_optimizer
        import itertools as _itools

        class _StepBudgetLoader:
            """Wraps a DataLoader and stops after `max_steps` batches."""

            def __init__(self, loader, max_steps):
                self._loader = loader
                self._max = max_steps
                self._done = 0

            def __iter__(self):
                for batch in self._loader:
                    if self._done >= self._max:
                        return
                    yield batch
                    self._done += 1

            def __len__(self):
                return min(self._max, len(self._loader))
        _cycled_loader = _StepBudgetLoader(type('_CycledLoader', (), {'__iter__': lambda self: _itools.islice(_itools.cycle(pa_loader), phase_a_steps), '__len__': lambda self: phase_a_steps})(), max_steps=phase_a_steps)
        trainer.cfg = {**cfg, 'epochs': 1, 'early_stopping': False}
        sched_pa = trainer.build_scheduler(phase_a_steps, 1)
        ep = trainer.train_epoch(_cycled_loader, sched_pa, 'band_gap')
        log.debug('Tier 3 Phase A  %d steps complete  loss=%.4f  proc_avail=%.1f%%', phase_a_steps, ep['loss'], ep.get('proc_avail_pct', 0.0))
        trainer.cfg = _saved_cfg
        trainer.optimizer = _saved_optimizer
        log.debug('Tier 3 Phase A complete (%d steps) — starting Phase B k_total_log fine-tuning', phase_a_steps)
        log.debug('─' * 68)
    elif phase_a_steps > 0 and len(df_structural) == 0:
        log.warning('Phase_ A: df_structural is empty. Skipping Phase A conslidation. ')
    log.debug('v4.38 PROCESS-RESIDUAL EXPERIMENT | epochs=%d lr=%.2e bound=%.3f categorical=%s family_offset=%s train_base_head=%s', cfg.get('epochs', 0), cfg.get('learning_rate', 0.0), cfg.get('process_delta_bound', 0.0), cfg.get('process_delta_use_categorical', False), cfg.get('enable_material_family_offset', False), cfg.get('process_delta_train_base_head', False))
    freeze_backbone = cfg.get('freeze_backbone', False)
    residual_proc_mode = bool(cfg.get('bounded_process_residual', False))
    if freeze_backbone:
        if residual_proc_mode:
            model.freeze_for_bounded_process_residual(train_base_head=cfg.get('process_delta_train_base_head', False))
            trainer.rebuild_optimizer_for_current_trainables()
            trainer.capture_frozen_base_reference()
        else:
            model.freeze_backbone()
        log.debug('─' * 68)
        log.debug('Tier 3 Phase B: %s  rows=%d  epochs=%d  lr≈%.2e  batch_size=%d', 'DFT-only base + bounded process residual' if residual_proc_mode else 'backbone-frozen single-task k_total_log fine-tuning', _n_phase_b, cfg['epochs'], cfg['learning_rate'], cfg['batch_size'])
        if residual_proc_mode:
            log.debug(' Frozen : ALIGNN backbone, functional conditioning, and base task head; training bounded process_delta_head only (unless train_base_head=True).')
        else:
            log.debug(' Frozen : ALIGNN backbone (all message passing layers)')
            log.debug(' Training task_heads, context_proj, proc_encoder, stack_encoder, alpha, beta')
        if _tier3_disjoint_val_active:
            pb_loader = train_loader
            pb_val_loader = val_loader
            pb_test_loader = test_loader
            pb_sampler = train_sampler
            log.debug('DISJOINT-VAL Phase B: reusing carved TRAIN(%d)/VAL(%d); TEST(%d) untouched.', len(getattr(pb_loader.dataset, 'indices', [])), len(getattr(pb_val_loader.dataset, 'indices', [])), _canonical_test_n)
        _pb_expected_val_n = _canonical_val_n if _tier3_disjoint_val_active else _canonical_test_n
        if len(getattr(pb_val_loader.dataset, 'indices', [])) != _pb_expected_val_n:
            raise RuntimeError('Phase-B validation split size %d differs from expected %s split size %d' % (len(getattr(pb_val_loader.dataset, 'indices', [])), 'disjoint-VAL' if _tier3_disjoint_val_active else 'TEST', _pb_expected_val_n))
        _saved_optimizer = None
        pb_history = trainer.train(pb_loader, pb_val_loader, target_col=cfg['target'], train_sampler=pb_sampler)
        dist_barrier()
        _pb_best_epoch = trainer.best_epoch
        _pb_best_mae = trainer.best_val_mae
        log.debug('Phase B complete: best val MAE=%.4f  at epoch=%d', _pb_best_mae, _pb_best_epoch)
        diag_epoch1_val = diag_epoch1_test = None
        if pb_history:
            h1 = pb_history[0]
            log.debug('RESIDUAL-PROC-DIAG | epoch1 history | VAL   | log_MAE=%.4f log_RMSE=%.4f  train_loss=%.4f  proc_avail=%.1f%% stack_avail=%.1f%%', h1.get('val_mae', float('nan')), h1.get('val_rmse', float('nan')), h1.get('train_loss', float('nan')), h1.get('proc_avail_pct', 0.0), h1.get('stack_avail_pct', 0.0))
        audit_epochs = sorted(set((int(e) for e in cfg.get('audit_checkpoint_epochs', [1, 10]))))
        for audit_epoch in audit_epochs:
            candidates = [CKPT_ROOT / f'tier3_audit_ep{audit_epoch}.pt', CKPT_ROOT / f'tier3_epoch{audit_epoch}.pt']
            audit_ckpt = next((x for x in candidates if x.exists()), None)
            if audit_ckpt is None:
                log.warning('v4.40 AUDIT: checkpoint for epoch %d not found', audit_epoch)
                continue
            ckpt_a = safe_load_checkpoint(audit_ckpt)
            if ckpt_a is None:
                continue
            state_a = _remap_state_dict(ckpt_a['model_state_dict'])
            missing_a, unexpected_a = trainer.model_core.load_state_dict(state_a, strict=False)
            stage_a = f'epoch{audit_epoch}_ckpt'
            log.debug('v4.40 AUDIT: reloaded %s (missing=%d unexpected=%d)', audit_ckpt.name, len(missing_a), len(unexpected_a))
            _eval_exact_k_for_diag(val_loader, 'VAL', stage_a)
            _write_tier3_prediction_audit(val_loader, _main_ds_t3.df, 'VAL', stage_a)
            log.debug('BASELINE TEST-SEAL: TEST skipped for %s; checkpoint audit is VAL-only.', stage_a)
        log.debug('─' * 68)
        if residual_proc_mode:
            log.debug('RESIDUAL-PROC: skipping Phase B2 backbone unfreeze so the final model remains DFT-base + bounded process correction.')
    dist_barrier()
    best_ckpt = CKPT_ROOT / 'tier3_best.pt'
    if best_ckpt.exists():
        ckpt = safe_load_checkpoint(best_ckpt)
        if ckpt is not None:
            state = _remap_state_dict(ckpt['model_state_dict'])
            missing, unexpected = trainer.model_core.load_state_dict(state, strict=False)
            log.debug('Reloaded tier3_best.pt for evaluation  (missing=%d  unexpected=%d)', len(missing), len(unexpected))
    test_mae_log, test_rmse_log, preds_log, trues_log = trainer.evaluate(test_loader, cfg['target'], return_preds=True)
    _write_tier3_prediction_audit(test_loader, _main_ds_t3.df, 'TEST', 'best_checkpoint')
    log.debug('BASELINE TEST-UNSEAL: TEST evaluated once after tier3_best.pt was frozen.')
    log.debug('─' * 68)
    _adapter_test_diag = trainer.evaluate_adapter_diagnostics(test_loader, cfg['target'], split_name='TEST-BEST')
    log.debug('TIER 3 TEST RESULTS')
    log.debug('─' * 68)
    if cfg.get('log_transform', False):
        log.debug('  Diagnostic log-space  MAE  = %.4f  [log(k) units]', test_mae_log)
        log.debug('  Diagnostic log-space  RMSE = %.4f', test_rmse_log)
        log.debug('  exp(MAE)                  = %.4f×  → ±%.1f%% avg relative error', math.exp(test_mae_log), (math.exp(test_mae_log) - 1) * 100)
        log.debug('')
        valid_mask = ~torch.isnan(trues_log)
        n_valid = int(valid_mask.sum())
        if n_valid > 0:
            p_lin = torch.exp(preds_log[valid_mask])
            t_lin = torch.exp(trues_log[valid_mask])
            mae_k_linear = (p_lin - t_lin).abs().mean().item()
            rmse_k_linear = ((p_lin - t_lin) ** 2).mean().sqrt().item()
            t_np = t_lin.cpu().numpy()
            mad_k_linear = float(np.mean(np.abs(t_np - np.mean(t_np))))
            mad_mae_linear = mad_k_linear / mae_k_linear if mae_k_linear > 0 else float('nan')
            log.debug('  PRIMARY (linear-k exact)  MAE  = %.4f  [dielectric units]', mae_k_linear)
            log.debug('  PRIMARY (linear-k exact)  RMSE = %.4f  [dielectric units]', rmse_k_linear)
            log.debug('  PRIMARY (linear-k exact)  MAD  = %.4f  → MAD:MAE = %.2f  (N=%d)', mad_k_linear, mad_mae_linear, n_valid)
            log.debug('─' * 68)
            if mad_mae_linear >= 2.5:
                log.debug('  STATUS: ✓ PROJECT GOAL MET  (MAD:MAE %.2f ≥ 2.5)', mad_mae_linear)
            elif mad_mae_linear >= 1.63:
                log.debug('  STATUS: ✓ PAPER BENCHMARK MET  (MAD:MAE %.2f ≥ 1.63) — push toward 2.5 goal', mad_mae_linear)
            else:
                log.debug('  STATUS: ✗ BELOW PAPER BENCHMARK  (MAD:MAE %.2f < 1.63) — check data count and process encoder activation', mad_mae_linear)
        else:
            log.warning('  No valid k_measured predictions on test set (n_valid=0). Check --rebuild_tier3 log for k_measured_log coverage.')
            mae_k_linear = rmse_k_linear = mad_k_linear = mad_mae_linear = float('nan')
            n_valid = 0
    else:
        test_mae_log, test_rmse_log = trainer.evaluate(test_loader, cfg['target'])
        log.debug('  k_total (linear)  MAE  = %.4f  [dielectric units]', test_mae_log)
        log.debug('  k_total (linear)  RMSE = %.4f  [dielectric units]', test_rmse_log)
        mae_k_linear = test_mae_log
        rmse_k_linear = test_rmse_log
        mad_k_linear = mad_mae_linear = float('nan')
        n_valid = 0
    log.debug('─' * 68)
    log.debug('TIER 3 FINAL SUMMARY  (linear-k, exact exp-space)')
    log.debug('  k_total  MAE=%.4f  RMSE=%.4f  MAD=%.4f  MAD:MAE=%.2f  N=%d', mae_k_linear, rmse_k_linear, mad_k_linear, mad_mae_linear, n_valid)
    log.debug('  paper benchmark: MAD:MAE ≥ 1.63 (44K JARVIS, no transfer)  |  project goal: MAD:MAE ≥ 2.5 (three-tier + process conditioning)')
    log.debug('─' * 68)
    log.debug('RESIDUAL-PROC-DIAG SUMMARY: epoch-0 vs epoch-1 vs best checkpoint')
    log.debug('  epoch0 VAL : log_MAE=%.4f  linear_MAE=%.4f  MAD:MAE=%.2f', diag_epoch0_val.get('mae_log', float('nan')), diag_epoch0_val.get('mae_k', float('nan')), diag_epoch0_val.get('mad_mae_k', float('nan')))
    if diag_epoch0_test is not None:
        log.debug('  epoch0 TEST: log_MAE=%.4f  linear_MAE=%.4f  MAD:MAE=%.2f', diag_epoch0_test.get('mae_log', float('nan')), diag_epoch0_test.get('mae_k', float('nan')), diag_epoch0_test.get('mad_mae_k', float('nan')))
    else:
        log.debug('  epoch0 TEST: sealed (skipped during optimization; reported once post-freeze)')
    if 'diag_epoch1_val' in locals() and diag_epoch1_val is not None:
        log.debug('  epoch1 VAL : log_MAE=%.4f  linear_MAE=%.4f  MAD:MAE=%.2f', diag_epoch1_val.get('mae_log', float('nan')), diag_epoch1_val.get('mae_k', float('nan')), diag_epoch1_val.get('mad_mae_k', float('nan')))
    if 'diag_epoch1_test' in locals() and diag_epoch1_test is not None:
        log.debug('  epoch1 TEST: log_MAE=%.4f  linear_MAE=%.4f  MAD:MAE=%.2f', diag_epoch1_test.get('mae_log', float('nan')), diag_epoch1_test.get('mae_k', float('nan')), diag_epoch1_test.get('mad_mae_k', float('nan')))
    log.debug('  BEST TEST  : log_MAE=%.4f  linear_MAE=%.4f  MAD:MAE=%.2f  best_epoch=%d', test_mae_log, mae_k_linear, mad_mae_linear, trainer.best_epoch)
    if trainer.best_epoch <= 1:
        log.warning('RESIDUAL-PROC-DIAG INTERPRETATION: best_epoch=%d. If epoch0/epoch1 metrics are close to BEST, the Tier-3 process residual is not yet adding measurable value; the result is mostly the fixed Tier-2 DFT baseline.', trainer.best_epoch)
    else:
        log.debug('RESIDUAL-PROC-DIAG INTERPRETATION: best_epoch=%d. Tier-3 training improved validation after the initial checkpoint baseline; compare epoch0/epoch1/BEST test metrics to quantify the gain.', trainer.best_epoch)
    out_path = REPORT_ROOT / 'tier3_test_results.json'
    primary_metrics = {'mae_log_k': test_mae_log, 'rmse_log_k': test_rmse_log, 'exp_mae_multiplier': math.exp(test_mae_log) if cfg.get('log_transform') else float('nan'), 'mae_k_exact': mae_k_linear, 'rmse_k_exact': rmse_k_linear, 'mad_k_exact': mad_k_linear, 'mad_mae_k_exact': mad_mae_linear, 'n_test': n_valid, 'mae': mae_k_linear, 'rmse': rmse_k_linear, 'benchmark_scale': 'linear', 'diagnostic_scale': 'log'}
    primary_metrics['residual_proc_diag'] = {'epoch0_val': diag_epoch0_val, 'epoch0_test': diag_epoch0_test, 'epoch1_val': diag_epoch1_val if 'diag_epoch1_val' in locals() else None, 'epoch1_test': diag_epoch1_test if 'diag_epoch1_test' in locals() else None, 'best_epoch': int(trainer.best_epoch), 'best_val_mae_log': float(trainer.best_val_mae)}
    mt_results_t3 = trainer.evaluate_multitask(test_loader, cfg, df_full=_main_ds_t3.df)
    _t3_primary = cfg['target']
    if _t3_primary in mt_results_t3:
        mt_results_t3[_t3_primary].update({'mae_log': float(test_mae_log), 'rmse_log': float(test_rmse_log), 'mae_linear': float(mae_k_linear), 'rmse_linear': float(rmse_k_linear), 'mad_linear': float(mad_k_linear), 'mad_mae_linear': float(mad_mae_linear), 'mae': float(mae_k_linear), 'rmse': float(rmse_k_linear), 'mad': float(mad_k_linear), 'mad_mae_ratio': float(mad_mae_linear), 'n': int(n_valid), 'coverage_pct': 100.0, 'mad_source': 'same fixed TEST rows as RESIDUAL-PROC-DIAG', 'metric_scale': 'linear-k exact', 'display_name': 'k_total'})
    trainer.print_multitask_results(mt_results_t3, split_name='TEST', tier_name='TIER 3')
    if is_rank0():
        with open(out_path, 'w') as f:
            json.dump({'primary': primary_metrics, 'multitask': mt_results_t3}, f, indent=2)
    log.debug('Tier 3 test results saved → %s', out_path)
    return CKPT_ROOT / 'tier3_best.pt'
from .splits import _tier3_split_key_from_row
