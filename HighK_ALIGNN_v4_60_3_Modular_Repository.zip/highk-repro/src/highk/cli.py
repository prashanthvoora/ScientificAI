"""Public CLI. Help and preparation guards work without GPU dependencies."""
from __future__ import annotations
import argparse
import json
import logging
import os
from pathlib import Path
from .artifacts import require_single_process, preparation_lock, save_prepared, load_prepared, sha256

def parser():
    p = argparse.ArgumentParser(description='High-k three-tier ALIGNN: prepare once, train separately.')
    p.add_argument('--root', type=Path, default=Path('highk_project'), help='Data/checkpoint/report root; same path for all commands.')
    p.add_argument('--verbose', action='store_true', help='Enable detailed research diagnostics.')
    sub = p.add_subparsers(dest='command', required=True)
    prep = sub.add_parser('prepare', help='Single-process acquisition, preprocessing, imputation and split creation.')
    prep.add_argument('--tier', choices=('1','2','3','all'), default='all')
    prep.add_argument('--force-refresh', action='store_true', help='Re-download remote raw sources.')
    prep.add_argument('--force-rebuild', action='store_true', help='Rebuild the selected tier dataframe caches.')
    prep.add_argument('--process-db', type=Path, help='Experimental CSV (required for a new Tier-3 cache).')
    prep.add_argument('--reuse-caches', action='store_true', help='Offline conversion of existing baseline HDF5 caches; never download.')
    train = sub.add_parser('train', help='Read prepared inputs and train; supports torchrun.')
    train.add_argument('--tier', type=int, choices=(1,2,3), required=True)
    train.add_argument('--weights', type=Path, help='Previous-tier checkpoint; defaults to checkpoints/tierN_best.pt.')
    train.add_argument('--ablate-context', action='store_true')
    evaluate = sub.add_parser('evaluate', help='Single-process frozen-checkpoint evaluation.')
    evaluate.add_argument('--tier', type=int, choices=(1,2,3), required=True)
    evaluate.add_argument('--weights', type=Path)
    evaluate.add_argument('--ablate-context', action='store_true')
    return p

def prepare(args):
    from .common import DATA_ROOT, SPLIT_ROOT, TIER1_TRAIN_CONFIG, TIER2_TRAIN_CONFIG, TIER3_TRAIN_CONFIG
    from .extraction import DatasetExtractor
    from .tier_builder import TierDatasetBuilder
    from .preparation import prepare_tier1_state, prepare_tier2_state, prepare_tier3_state
    import pandas as pd
    wanted = [1,2,3] if args.tier == 'all' else [int(args.tier)]
    maximum = max(wanted)
    with preparation_lock(args.root):
        extractor, builder = DatasetExtractor(), TierDatasetBuilder()
        # Invalidate selected ready manifests before modifying any dependencies.
        for tier in range(min(wanted), 4):
            (DATA_ROOT / 'prepared' / f'tier{tier}.json').unlink(missing_ok=True)
        frames = {}
        upstream_changed = False
        for tier in range(1, maximum + 1):
            path = builder.TIER_PATHS[tier]
            rebuild = upstream_changed or (args.force_rebuild and tier in wanted) or (tier == 1 and args.force_refresh) or (tier == 3 and args.process_db is not None)
            if path.exists() and not rebuild:
                frames[tier] = pd.read_hdf(path, key='data')
            elif args.reuse_caches:
                raise FileNotFoundError(f'Offline cache is missing: {path}')
            elif tier == 1:
                upstream_changed = True
                # Validate credential only if raw MP extraction needs it.
                mp_cache = extractor.cache_dir / 'mp_full.h5'
                if (args.force_refresh or not mp_cache.exists()) and not os.getenv('MP_API_KEY'):
                    raise RuntimeError('Set MP_API_KEY for Materials Project acquisition (never commit your key).')
                frames[1] = builder.build_tier1(extractor.pull_jarvis_dft(args.force_refresh),
                    extractor.pull_materials_project(args.force_refresh), extractor.pull_qm9(args.force_refresh),
                    force_rebuild=True, skip_cross_dedup=False)
            elif tier == 2:
                upstream_changed = True
                frames[2] = builder.build_tier2(frames[1], force_rebuild=True)
            else:
                process_path = args.process_db or DATA_ROOT / 'processed/process_db_clean.csv'
                if not process_path.exists():
                    raise FileNotFoundError(f'Experimental process database missing: {process_path}. Supply --process-db.')
                frames[3] = builder.build_tier3(frames[2], extractor.load_experimental_process_db(process_path), force_rebuild=True)
        configs = [TIER1_TRAIN_CONFIG,TIER2_TRAIN_CONFIG,TIER3_TRAIN_CONFIG]
        functions = [prepare_tier1_state,prepare_tier2_state,prepare_tier3_state]
        for tier in wanted:
            state = functions[tier-1](df_tier1=frames.get(1),df_tier2=frames.get(2),df_tier3=frames.get(3))
            split_hashes = {p.name:sha256(p) for p in SPLIT_ROOT.glob('tier3_*_row_ids.csv')} if tier==3 else {}
            counts = {name:len(state[name+'_loader'].dataset) for name in ('train','val','test')}
            save_prepared(args.root,tier,state,{'config':configs[tier-1], 'split_counts':counts,
                'split_sha256':split_hashes, 'source_cache_sha256':{builder.TIER_PATHS[t].name:sha256(builder.TIER_PATHS[t]) for t in range(1,tier+1)}})
            logging.getLogger('highk').info('Tier %d prepared: %s',tier,counts)

def main(argv=None):
    args = parser().parse_args(argv)
    args.root = args.root.expanduser().resolve()
    # Reject preparation under torchrun before importing scientific dependencies or writing files.
    if args.command != 'train':
        require_single_process()
    os.environ['HIGHK_ROOT'] = str(args.root)
    rank = int(os.getenv('RANK','0'))
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    if rank:
        logging.getLogger('highk').setLevel(logging.WARNING)
    if args.command == 'prepare':
        for name in ('data','checkpoints','reports','logs','reports/tier3_splits'):
            (args.root/name).mkdir(parents=True,exist_ok=True)
        prepare(args)
        return
    # Deserialize/verify prepared inputs before DDP initialization. No HDF5 readers in train.
    state, manifest = load_prepared(args.root,args.tier)
    from .common import CKPT_ROOT, REPORT_ROOT, TIER1_TRAIN_CONFIG, TIER2_TRAIN_CONFIG, TIER3_TRAIN_CONFIG
    configs = [TIER1_TRAIN_CONFIG,TIER2_TRAIN_CONFIG,TIER3_TRAIN_CONFIG]
    if manifest['config'] != json.loads(json.dumps(configs[args.tier-1])):
        raise RuntimeError('Configuration changed after preparation. Prepare this tier again.')
    if args.command == 'evaluate':
        from .evaluation import run_tier_evaluate
        key = {1:'df_tier1',2:'df_t2_k',3:'df_structural'}[args.tier]
        weights = args.weights or CKPT_ROOT / f'tier{args.tier}_best.pt'
        if not weights.exists():raise FileNotFoundError(weights)
        run_tier_evaluate(args.tier,state[key],weights,ablate_context=args.ablate_context)
        return
    weights = args.weights or CKPT_ROOT / f'tier{args.tier-1}_best.pt'
    if args.tier>1 and not weights.exists():raise FileNotFoundError(weights)
    from .distributed import init_dist, shutdown_dist
    from .runtime import bind_state
    from .workflows import run_tier1_pretrain, run_tier2_finetune, run_tier3_finetune
    try:
        init_dist()
        state = bind_state(state)
        logging.getLogger('highk').info('Training Tier %d from verified prepared inputs.',args.tier)
        [run_tier1_pretrain,run_tier2_finetune,run_tier3_finetune][args.tier-1](state,weights,ablate_context=args.ablate_context)
    finally:
        shutdown_dist()

if __name__ == '__main__':
    main()
