from __future__ import annotations
from .artifacts import require_single_process
from .cache import _atomic_write_hdf
from .common import DATA_ROOT, FUNCTIONAL_CODE, JAtoms, JarvisAtomsAdaptor, Optional, TIER2_K_MIN, _DIST, datetime, hashlib, json, log, np, pd, tqdm
from .cache import _atomic_write_hdf, _read_hdf_with_retry
from .distributed import dist_barrier, is_rank0

class TierDatasetBuilder:
    """
    Assembles the three-tier dataset from extracted raw data.

    Tier assignment logic:
    ---------------------
    Tier 1: all entries (JARVIS + MP + QM9)  -- general oxide + molecular physics
    Tier 2: subset -- oxide dielectrics with k > 10, Eg > 1 eV, has_structure=True
            contains at least one Tier 2 cation
    Tier 3: subset -- HfO2 family specifically + experimental entries
    """
    TIER_PATHS = {1: DATA_ROOT / 'tier1_foundation.h5', 2: DATA_ROOT / 'tier2_domain.h5', 3: DATA_ROOT / 'tier3_project.h5'}
    MANIFEST_PATH = DATA_ROOT / 'dataset_manifest.json'

    def __init__(self):
        require_single_process()
        self._load_or_init_manifest()

    def _load_or_init_manifest(self):
        """Load manifest or create empty version."""
        if self.MANIFEST_PATH.exists():
            with open(self.MANIFEST_PATH) as f:
                self.manifest = json.load(f)
        else:
            self.manifest = {'schema_version': '1.2', 'created': datetime.date.today().isoformat(), 'last_updated': datetime.date.today().isoformat(), 'tiers': {str(i): {'row_count': 0, 'last_updated': None} for i in [1, 2, 3]}, 'growth_log': []}

    def _save_manifest(self):
        self.manifest['last_updated'] = datetime.date.today().isoformat()
        with open(self.MANIFEST_PATH, 'w') as f:
            json.dump(self.manifest, f, indent=2)

    @staticmethod
    def _atoms_json_to_pymatgen(atoms_json: Optional[str]):
        """Convert stored atoms_dict JSON to pymatgen Structure."""
        if not atoms_json:
            return None
        try:
            j_atoms = JAtoms.from_dict(json.loads(atoms_json))
            return JarvisAtomsAdaptor.get_structure(j_atoms)
        except Exception:
            return None

    @staticmethod
    def _backfill_k_total(df: pd.DataFrame, name: str) -> pd.DataFrame:
        """Ensure k_total is populated from k_measured wherever k_total is absent or NaN."""
        if 'k_measured' not in df.columns:
            return df
        if 'k_total' not in df.columns:
            df = df.copy()
            df['k_total'] = df['k_measured']
            n = int(df['k_total'].notna().sum())
            log.debug('  k_total backfill [%s]: column absent → created from k_measured  (%d non-null)', name, n)
            return df
        mask = df['k_total'].isna() & df['k_measured'].notna()
        n = int(mask.sum())
        if n > 0:
            df = df.copy()
            df.loc[mask, 'k_total'] = df.loc[mask, 'k_measured']
            log.debug('  k_total backfill [%s]: %d NaN k_total filled from k_measured', name, n)
        return df

    def deduplicate_cross_source(self, df_jarvis: pd.DataFrame, df_mp: pd.DataFrame) -> tuple:
        """FIX4: Remove MP entries structurally identical to JARVIS entries."""
        from pymatgen.analysis.structure_matcher import StructureMatcher
        matcher = StructureMatcher(ltol=0.2, stol=0.3, angle_tol=5)
        shared_formulas = set(df_mp['formula']).intersection(set(df_jarvis['formula']))
        jv_by_formula = df_jarvis.groupby('formula')
        drop_idx = set()
        n_merged = 0
        df_jarvis_mut = df_jarvis.copy()
        log.debug('FIX4 cross-source dedup: %d shared formulas between JARVIS and MP', len(shared_formulas))
        mp_shared = df_mp[df_mp['formula'].isin(shared_formulas)]
        for idx, mp_row in tqdm(mp_shared.iterrows(), total=len(mp_shared), desc='FIX4 cross-source dedup'):
            mp_struct = self._atoms_json_to_pymatgen(mp_row.get('atoms_dict'))
            if mp_struct is None:
                continue
            for _, jv_row in jv_by_formula.get_group(mp_row['formula']).iterrows():
                jv_struct = self._atoms_json_to_pymatgen(jv_row.get('atoms_dict'))
                if jv_struct is None:
                    continue
                try:
                    if matcher.fit(mp_struct, jv_struct):
                        drop_idx.add(idx)
                        jv_idx = jv_row.name
                        jv_k = df_jarvis_mut.at[jv_idx, 'k_total'] if 'k_total' in df_jarvis_mut.columns else float('nan')
                        mp_k = mp_row.get('k_total')
                        if pd.isna(jv_k) and mp_k is not None and (not (isinstance(mp_k, float) and np.isnan(mp_k))):
                            df_jarvis_mut.at[jv_idx, 'k_total'] = mp_k
                            df_jarvis_mut.at[jv_idx, 'k_measured'] = mp_k
                            if 'k_ionic' in df_jarvis_mut.columns:
                                df_jarvis_mut.at[jv_idx, 'k_ionic'] = mp_row.get('k_ionic')
                            if 'k_elec' in df_jarvis_mut.columns:
                                df_jarvis_mut.at[jv_idx, 'k_elec'] = mp_row.get('k_elec')
                            n_merged += 1
                        break
                except Exception:
                    continue
        df_mp_unique = df_mp.drop(index=list(drop_idx)).reset_index(drop=True)
        log.debug('FIX4 dedup: dropped %d MP duplicates  →  %d MP entries remain  |  k_total merged to %d JARVIS entries (DEDUP-MERGE)', len(drop_idx), len(df_mp_unique), n_merged)
        return (df_jarvis_mut, df_mp_unique)

    def build_tier1(self, df_jarvis: pd.DataFrame, df_mp: pd.DataFrame, df_qm9: pd.DataFrame, force_rebuild: bool=False, skip_cross_dedup: bool=False) -> pd.DataFrame:
        """Assemble full Tier 1 foundation dataset.
        FIX4: Cross-source structural deduplication (MP vs JARVIS).
        FIX5: Ensures functional columns present on all sources before concat."""
        if self.TIER_PATHS[1].exists() and (not force_rebuild):
            log.debug('Loading existing Tier 1 from %s', self.TIER_PATHS[1])
            return pd.read_hdf(self.TIER_PATHS[1], key='data')
        log.debug('Building Tier 1 foundation dataset...')
        df_jarvis = self._backfill_k_total(df_jarvis, 'JARVIS')
        df_mp = self._backfill_k_total(df_mp, 'MP')
        if skip_cross_dedup:
            log.warning('--skip_cross_dedup: same crystal may appear twice with contradictory DFT targets (PBE vs OptB88vdW).')
            df_mp_clean = df_mp.copy()
        elif len(df_mp) > 0 and len(df_jarvis) > 0:
            df_jarvis, df_mp_clean = self.deduplicate_cross_source(df_jarvis, df_mp)
        else:
            df_mp_clean = df_mp.copy()
        for df in [df_jarvis, df_mp_clean, df_qm9]:
            if len(df) == 0:
                continue
            if 'dft_functional' not in df.columns:
                df['dft_functional'] = 'PBE'
            if 'functional_code' not in df.columns:
                df['functional_code'] = FUNCTIONAL_CODE['PBE']
            if 'band_gap_optb88vdw' not in df.columns:
                df['band_gap_optb88vdw'] = np.nan
            if 'band_gap_pbe' not in df.columns:
                df['band_gap_pbe'] = np.nan
        for df, t in [(df_jarvis, 1), (df_mp_clean, 1), (df_qm9, 1)]:
            if len(df):
                df['tier'] = t
        dfs = [df for df in [df_jarvis, df_mp_clean, df_qm9] if len(df) > 0]
        df_all = pd.concat(dfs, ignore_index=True, sort=False)
        log.debug('Before dedup: %d rows', len(df_all))
        for src in ['JARVIS-DFT', 'MaterialsProject', 'QM9']:
            mask = df_all['source'] == src
            n_src = int(mask.sum())
            n_k = int(df_all.loc[mask, 'k_total'].notna().sum())
            log.debug('  k_total audit post-concat | %-22s %6d rows  k_total=%d', src, n_src, n_k)
        df_all = df_all.drop_duplicates(subset=['row_hash'], keep='first')
        log.debug('After dedup: %d rows', len(df_all))
        is_molecule = df_all.get('is_molecule', pd.Series(False, index=df_all.index))
        is_molecule = is_molecule.fillna(False).astype(bool)
        is_crystal = ~is_molecule
        bad_k = (df_all['k_measured'] < 1) | (df_all['k_measured'] > 500)
        bad_ef = df_all['formation_energy_per_atom'].abs() > 20
        bad_gap = df_all['band_gap'] < 0
        exclude = is_crystal & (bad_k.fillna(False) | bad_ef.fillna(False) | bad_gap.fillna(False))
        df_tier1 = df_all[~exclude].copy()
        df_tier1['tier'] = 1
        log.debug('Tier 1 final count: %d rows', len(df_tier1))
        kt_t1 = df_tier1['k_total'].notna().sum()
        log.debug('  k_total audit Tier 1 final | total=%d  JARVIS=%d  MP=%d  QM9=%d', kt_t1, int(df_tier1.loc[df_tier1['source'] == 'JARVIS-DFT', 'k_total'].notna().sum()), int(df_tier1.loc[df_tier1['source'].str.startswith('Material'), 'k_total'].notna().sum()), int(df_tier1.loc[df_tier1['source'] == 'QM9', 'k_total'].notna().sum()))
        _atomic_write_hdf(df_tier1, self.TIER_PATHS[1])
        self.manifest['tiers']['1']['row_count'] = len(df_tier1)
        self.manifest['tiers']['1']['last_updated'] = datetime.date.today().isoformat()
        self.manifest['tiers']['1']['breakdown'] = {'JARVIS-DFT': int((df_tier1['source'] == 'JARVIS-DFT').sum()), 'MaterialsProject': int((df_tier1['source'] == 'MaterialsProject').sum()), 'QM9': int((df_tier1['source'] == 'QM9').sum()), 'mp_dupes_removed_fix4': int(len(df_mp) - len(df_mp_clean)) if not skip_cross_dedup else 0}
        self._save_manifest()
        self._log_stats('Tier 1', df_tier1)
        return df_tier1

    def build_tier2(self, df_tier1: pd.DataFrame, force_rebuild: bool=False) -> pd.DataFrame:
        """Derive Tier 2 from Tier 1 by applying domain-specific filters:
        - Not a molecule (QM9 excluded)
        - Contains at least one Tier 2 high-k cation
        - k_measured > 10 (if available) OR is a relevant oxide without k
        - band_gap > 1.0 eV (exclude metals)
        - has_structure = True (need crystal graph for ALIGNN)"""
        if self.TIER_PATHS[2].exists() and (not force_rebuild):
            log.debug('Loading existing Tier 2 from %s', self.TIER_PATHS[2])
            return pd.read_hdf(self.TIER_PATHS[2], key='data')
        log.debug('Deriving Tier 2 domain dataset from Tier 1...')
        log.debug('  k_total audit Tier 2 INPUT  | total=%d  JARVIS=%d  MP=%d', int(df_tier1['k_total'].notna().sum()), int(df_tier1.loc[df_tier1['source'] == 'JARVIS-DFT', 'k_total'].notna().sum()), int(df_tier1.loc[df_tier1['source'].str.startswith('Material'), 'k_total'].notna().sum()))
        is_molecule_t2 = df_tier1.get('is_molecule', pd.Series(False, index=df_tier1.index))
        is_molecule_t2 = is_molecule_t2.fillna(False).astype(bool)
        df_cryst = df_tier1[~is_molecule_t2].copy()
        df_struct = df_cryst[df_cryst['has_structure'] == True].copy()
        df_cation = df_struct.copy()
        log.debug('  k_total audit post-structure filter | rows=%d  k_total=%d', len(df_cation), int(df_cation['k_total'].notna().sum()))
        df_cation = df_cation[df_cation['band_gap'].isna() | (df_cation['band_gap'] > 1.0)].copy()
        log.debug('  k_total audit post-bandgap filter   | rows=%d  k_total=%d', len(df_cation), int(df_cation['k_total'].notna().sum()))
        has_k = df_cation['k_total'].notna()
        valid_k = df_cation['k_total'] > TIER2_K_MIN
        df_tier2 = df_cation[~has_k | valid_k].copy()
        log.debug('  k_total audit post-k>%.1f filter   | rows=%d  k_total=%d  (★ Tier 2 training dataset size)', TIER2_K_MIN, len(df_tier2), int(df_tier2['k_total'].notna().sum()))
        df_tier2['tier'] = 2
        log.debug('Tier 2 final count: %d rows', len(df_tier2))
        _atomic_write_hdf(df_tier2, self.TIER_PATHS[2])
        self.manifest['tiers']['2']['row_count'] = len(df_tier2)
        self.manifest['tiers']['2']['last_updated'] = datetime.date.today().isoformat()
        self._save_manifest()
        self._log_stats('Tier 2', df_tier2)
        return df_tier2

    def build_tier3(self, df_tier2: pd.DataFrame, df_exp: pd.DataFrame, force_rebuild: bool=False) -> pd.DataFrame:
        """Derive Tier 3 from Tier 2 (HfO2-family DFT entries) + experimental DB."""
        tier3_path = self.TIER_PATHS[3]
        if _DIST['active'] and force_rebuild and (not is_rank0()):
            log.debug('[rank %d] Waiting for rank 0 to rebuild Tier 3 cache: %s', _DIST['rank'], tier3_path)
            dist_barrier()
            if not tier3_path.exists():
                raise FileNotFoundError(f'Rank 0 did not produce Tier 3 cache at {tier3_path}')
            return _read_hdf_with_retry(tier3_path, key='data')
        if tier3_path.exists() and (not force_rebuild):
            dist_barrier()
            log.debug('Loading existing Tier 3 from %s', tier3_path)
            return _read_hdf_with_retry(tier3_path, key='data')
        log.debug('Deriving Tier 3 project dataset%s...', ' on rank 0' if _DIST['active'] else '')
        HIGH_K_ELEMENTS = {'Hf', 'Zr', 'Al', 'Ti', 'Ta', 'Sr', 'La', 'Y', 'Ba', 'Nb', 'Ga', 'In', 'Sc', 'Ce', 'Pr', 'Nd'}

        def is_hfo2_family(formula):
            if not isinstance(formula, str):
                return False
            has_o = 'O' in formula
            has_highk = any((el in formula for el in HIGH_K_ELEMENTS))
            return has_o and has_highk

        def is_hfzr_core(formula):
            """Strict Hf/Zr-only filter for Tier 3 DFT TRAINING rows.
            FIX-DONOR-POOL: separate the donor pool (broad, for _find_donor)
            from the DFT training rows (Hf/Zr-only, for df_structural).
            Using the broad filter for df_hf caused 1128-row df_structural
            (Al2O3, TiO2, SrTiO3, etc. DFT rows included) which diluted the
            experimental proc-param signal from 79% → ~10% of each batch.
            df_hf (training) stays Hf/Zr-family only (~28 rows).
            _impute_structures uses the broad donor_pool separately."""
            if not isinstance(formula, str):
                return False
            return ('Hf' in formula or 'Zr' in formula) and 'O' in formula
        df_hf = df_tier2[df_tier2['formula'].apply(is_hfzr_core)].copy()
        df_donor_pool_wide = df_tier2[df_tier2['formula'].apply(is_hfo2_family)].copy()
        if 'k_total' in df_hf.columns:
            has_k_total = df_hf['k_total'].notna()
            lacks_k_meas = ~df_hf.get('k_measured', pd.Series(False, index=df_hf.index)).notna() if 'k_measured' in df_hf.columns else pd.Series(True, index=df_hf.index)
            propagate_mask = has_k_total & lacks_k_meas
            if propagate_mask.any():
                df_hf.loc[propagate_mask, 'k_measured'] = df_hf.loc[propagate_mask, 'k_total']
                log.debug('FIX-T3-8B: propagated k_total → k_measured for %d DFT HfO2-family rows', int(propagate_mask.sum()))
        log.debug('  HfO2-family DFT entries: %d', len(df_hf))
        if len(df_exp) > 0:
            df_exp_aligned = df_exp.copy()
            for col in df_hf.columns:
                if col not in df_exp_aligned.columns:
                    df_exp_aligned[col] = None
            df_tier3 = pd.concat([df_hf, df_exp_aligned], ignore_index=True, sort=False)
        else:
            df_tier3 = df_hf.copy()
        n_pre_dedup = len(df_tier3)
        n_exp_pre = int((df_tier3['source'] == 'Experimental').sum())
        n_dft_pre = n_pre_dedup - n_exp_pre
        log.debug('Tier 3 pre-dedup  : %d total  (DFT-HfO2=%d  Experimental=%d)', n_pre_dedup, n_dft_pre, n_exp_pre)
        df_tier3 = df_tier3.drop_duplicates(subset=['row_hash'], keep='first')
        n_post_dedup = len(df_tier3)
        n_exp_post = int((df_tier3['source'] == 'Experimental').sum())
        n_dft_post = n_post_dedup - n_exp_post
        n_lost = n_pre_dedup - n_post_dedup
        n_exp_lost = n_exp_pre - n_exp_post
        log.debug('Tier 3 post-dedup : %d total  (DFT-HfO2=%d  Experimental=%d)  lost=%d (DFT=%d  Experimental=%d)', n_post_dedup, n_dft_post, n_exp_post, n_lost, n_lost - n_exp_lost, n_exp_lost)
        if n_exp_lost > 0:
            log.warning('FIX-T3-5: %d experimental rows lost to row_hash deduplication.  Check process_db.csv for duplicate (paper_id + material + substrate_temp_C + precursor_type + oxidant_type + n_cycles) combinations — these are true duplicates that should be merged or given distinct paper_id values.', n_exp_lost)
        df_tier3 = df_tier3.drop_duplicates(subset=['row_hash'], keep='first')
        df_tier3['tier'] = 3
        log.debug('Tier 3 final count: %d rows', len(df_tier3))
        if not _DIST['active'] or is_rank0():
            _atomic_write_hdf(df_tier3, tier3_path, key='data')
            self.manifest['tiers']['3']['row_count'] = len(df_tier3)
            self.manifest['tiers']['3']['last_updated'] = datetime.date.today().isoformat()
            self.manifest['tiers']['3']['breakdown'] = {'DFT_HfO2_family': int((df_tier3['source'] != 'Experimental').sum()), 'Experimental': int((df_tier3['source'] == 'Experimental').sum())}
            self._save_manifest()
            self._log_stats('Tier 3', df_tier3)
        if _DIST['active']:
            dist_barrier()
        return df_tier3

    @staticmethod
    def _log_stats(label: str, df: pd.DataFrame):
        log.debug('-' * 60)
        log.debug(' %s  statistics', label)
        log.debug('  Total rows:          %d', len(df))
        if 'k_measured' in df.columns:
            k = df['k_measured'].dropna()
            log.debug('  k_measured:          %d rows, mean=%.1f, max=%.1f', len(k), k.mean() if len(k) else 0, k.max() if len(k) else 0)
            log.debug('  k > 35 (target):     %d rows (%.1f%%)', (k > 35).sum(), 100 * (k > 35).mean() if len(k) else 0)
        if 'band_gap' in df.columns:
            bg = df['band_gap'].dropna()
            log.debug('  band_gap:            %d rows, mean=%.2f eV', len(bg), bg.mean() if len(bg) else 0)
        if 'source' in df.columns:
            for src, cnt in df['source'].value_counts().items():
                log.debug('  %-22s %d', src, cnt)
        log.debug('-' * 60)
