"""Three-tier high-k ALIGNN research implementation."""
__version__ = "0.1.0"
