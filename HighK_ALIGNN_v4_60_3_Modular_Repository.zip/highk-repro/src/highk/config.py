"""Baseline defaults and workspace paths. Importing this module writes no files."""
from __future__ import annotations
import os
from pathlib import Path
from typing import Dict, Any

ROOT = Path(os.environ.get('HIGHK_ROOT', 'highk_project')).resolve()

DATA_ROOT = ROOT / 'data'

CKPT_ROOT = ROOT / 'checkpoints'

LOG_ROOT = ROOT / 'logs'

REPORT_ROOT = ROOT / 'reports'

SPLIT_ROOT = REPORT_ROOT / 'tier3_splits'

TIER3_TEST_SPLIT_PATH = SPLIT_ROOT / 'tier3_test_row_ids.csv'

TIER3_VAL_SPLIT_PATH = SPLIT_ROOT / 'tier3_val_row_ids.csv'

MP_API_KEY = os.environ.get('MP_API_KEY', '')

TIER3_ELEMENTS = {'Hf', 'Zr'}

HIGH_K_DONOR_ELEMENTS = {'Hf', 'Zr', 'Al', 'Ti', 'Ta', 'Sr', 'La', 'Y', 'Ba', 'Nb', 'Ga', 'In', 'Sc', 'Ce', 'Pr', 'Nd'}

TIER2_CATIONS = {'Hf', 'Zr', 'Ti', 'La', 'Ce', 'Pr', 'Nd', 'Gd', 'Dy', 'Y', 'Lu', 'Al', 'Ga', 'In', 'Si', 'Ge', 'Sn', 'Nb', 'Ta', 'W', 'Mo', 'Ba', 'Sr', 'Ca', 'Mg'}

TIER2_K_MIN = 3.9

ALIGNN_BASE_CONFIG = {'alignn_layers': 4,
 'gcn_layers': 4,
 'edge_input_features': 80,
 'triplet_input_features': 40,
 'embedding_features': 64,
 'hidden_features': 256,
 'output_features': 256}

TIER1_TRAIN_CONFIG = {'epochs': 300,
 'batch_size': 64,
 'learning_rate': 0.001,
 'weight_decay': 1e-05,
 'scheduler': 'onecycle',
 'pct_start': 0.4,
 'loss': 'mse',
 'target': 'formation_energy_per_atom',
 'aux_targets': ['band_gap', 'k_total_log'],
 'log_transform_aux': {'k_total_log': 'k_total'},
 'functional_loss_weights': {0: 1.5, 1: 1.0, 2: 2.0, 3: 1.5, 4: 0.3},
 'train_ratio': 0.8,
 'val_ratio': 0.1,
 'test_ratio': 0.1,
 'early_stopping': False,
 'min_epochs': 200,
 'patience': 50,
 'max_grad_norm': 1.0}

TIER2_TRAIN_CONFIG = {'epochs': 150,
 'batch_size': 32,
 'learning_rate': 0.0002,
 'learning_rate_unfreeze': 0.0001,
 'weight_decay': 1e-05,
 'scheduler': 'cosine',
 'loss': 'mse',
 'log_transform': True,
 'log_original_col': 'k_total',
 'target': 'k_total_log',
 'aux_targets': ['band_gap', 'formation_energy_per_atom'],
 'train_ratio': 0.8,
 'val_ratio': 0.1,
 'test_ratio': 0.1,
 'freeze_layers': 2,
 'unfreeze_after': 20,
 'early_stopping': True,
 'min_epochs': 50,
 'patience': 50,
 'phase_a_target': 'band_gap',
 'phase_a_epochs': 30,
 'max_grad_norm': 1.0}

TIER3_TRAIN_CONFIG = {'epochs': 100,
 'batch_size': 16,
 'learning_rate': 0.0001,
 'weight_decay': 0.0001,
 'scheduler': 'cosine',
 'loss': 'mse',
 'max_grad_norm': 1.0,
 'target': 'k_total_log',
 'log_transform': True,
 'log_original_col': 'k_total',
 'aux_targets': [],
 'train_ratio': 0.7,
 'val_ratio': 0.0,
 'test_ratio': 0.3,
 'freeze_backbone': True,
 'unfreeze_backbone_after': 50,
 'unfreeze_backbone_lr': 1e-05,
 'exp_sample_weight': 1.0,
 'early_stopping': True,
 'min_epochs': 20,
 'patience': 20,
 'phase_a_steps': 0,
 'phase_a_target': 'band_gap',
 'phase_a_lr': 5e-05,
 'bounded_process_residual': True,
 'process_delta_bound': 0.15,
 'process_delta_use_categorical': True,
 'process_delta_train_base_head': False,
 'tier3_use_structural_adapter': True,
 'tier3_structural_adapter_rank': 16,
 'tier3_structural_adapter_learning_rate': 5e-05,
 'tier3_process_learning_rate': 0.0001,
 'tier3_structural_adapter_weight_decay': 0.0001,
 'tier3_adapter_magnitude_weight': 1.0,
 'tier3_adapter_center_weight': 5.0,
 'tier3_process_center_weight': 5.0,
 'tier3_adapter_process_orthogonal_weight': 1.0,
 'tier3_process_weight_decay': 0.0001,
 'tier3_base_change_warn_mean': 0.03,
 'tier3_base_change_warn_max': 0.1,
 'process_delta_init_seed': 42,
 'frozen_base_state_tolerance': 1e-08,
 'save_epoch1_checkpoint': True,
 'audit_checkpoint_epochs': [1, 10, 20, 40, 80, 100],
 'audit_write_dataset_composition': True,
 'audit_write_optimizer_manifest': True,
 'eval_hfo2_family_only': True,
 'eval_verified_only': True,
 'tier3_disjoint_val': True,
 'tier3_disjoint_val_ratio': 0.3,
 'tier3_disjoint_val_seed': 42,
 'tier3_disjoint_val_min_pool': 15,
 'tier3_disjoint_val_min_rows': 15,
 'tier3_lock_persistent_splits': True,
 'tier3_allow_split_creation': True,
 'enable_material_family_offset': False,
 'material_family_offsets': {'pure_hfo2': 0.0,
                             'hzo_like': 0.2,
                             'doped_hfo2_al': 0.15,
                             'doped_hfo2_la': 0.15,
                             'doped_hfo2_other': 0.1,
                             'zro2_like': 0.05,
                             'other_highk': 0.0},
 'phase_aware_donor_selection': True,
 'donor_log_topn': 5}

FUNCTIONAL_CODE = {'OptB88vdW': 0, 'PBE': 1, 'r2SCAN': 2, 'GGA+U': 3, 'B3LYP': 4}

TASK_TO_COLUMN = {'k_measured': 'k_measured', 'k_total_log': 'k_total_log', 'k_total': 'k_total', 'band_gap': 'band_gap', 'formation_energy_per_atom': 'formation_energy_per_atom', 'e_above_hull': 'e_above_hull', 'J_g_log': 'J_g_A_cm2', 'E_BD': 'E_BD_MV_cm'}

PAPER_MAD_MAE_BENCHMARK = {'formation_energy_per_atom': 26.06, 'band_gap': 7.07, 'k_total': 1.63, 'k_total_log': 1.63, 'J_g_log': None, 'E_BD': None}

PROCESS_PARAMS_FEATURES = {'numerical': ['substrate_temp_C',
               'anneal_temp_C',
               'anneal_duration_min',
               'growth_rate_A_per_cycle',
               'n_cycles',
               'film_thickness_A',
               'pressure_mTorr'],
 'log_normalize': ['anneal_duration_min', 'pressure_mTorr'],
 'categorical': {'anneal_ambient': ['N2',
                                    'O2',
                                    'forming_gas',
                                    'vacuum',
                                    'Ar',
                                    'ambient',
                                    'other'],
                 'precursor_type': ['TDMA-Hf',
                                    'HfCl4',
                                    'TEMAZ',
                                    'TDMAZ',
                                    'other',
                                    'TDMAHf',
                                    'TDMAH',
                                    'TEMA-Hf',
                                    'TEMAH',
                                    'TDMAZr',
                                    'TMA'],
                 'oxidant_type': ['H2O',
                                  'O3',
                                  'O2_plasma',
                                  'other',
                                  'O2 plasma',
                                  'O2',
                                  'H2O_O3']},
 'embed_dim': 8,
 'output_dim': 64}

STACK_CONTEXT_FEATURES = {'numerical': ['IL_thickness_A', 'CET_target_A'],
 'log_normalize': [],
 'categorical': {'substrate': ['Si', 'SiO2_Si', 'TiN_Si', 'GaAs', 'other'],
                 'IL_type': ['SiO2', 'SiON', 'none', 'other'],
                 'top_electrode': ['TiN', 'TaN', 'W', 'Al', 'poly_Si', 'other'],
                 'stack_config': ['MOS', 'MIM', 'MFIM', 'MFIS', 'other']},
 'embed_dim': 8,
 'output_dim': 64}

