"""Transactional, versioned preparation artifacts (standard library only)."""
from __future__ import annotations
import contextlib
import hashlib
import json
import os
import pickle
import tempfile
from pathlib import Path

SCHEMA_VERSION = 1

def require_single_process():
    if any(key in os.environ for key in ('RANK', 'LOCAL_RANK', 'WORLD_SIZE')):
        raise RuntimeError('Preparation and evaluation must run with python, not torchrun. Run highk prepare first, then torchrun training.')

def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def atomic_bytes(path, writer):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.' + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            writer(stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)

@contextlib.contextmanager
def preparation_lock(root):
    import fcntl  # Linux/WSL; lock also excludes independent prepare invocations.
    root = Path(root)
    root.mkdir(parents=True, exist_ok=True)
    with (root / '.prepare.lock').open('a') as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError('Another preparation process is using this output root.') from exc
        try:
            yield
        finally:
            fcntl.flock(stream, fcntl.LOCK_UN)

def save_prepared(root, tier, state, metadata):
    directory = Path(root) / 'data/prepared'
    data_path = directory / f'tier{tier}.pkl'
    manifest_path = directory / f'tier{tier}.json'
    atomic_bytes(data_path, lambda f: pickle.dump(state, f, protocol=pickle.HIGHEST_PROTOCOL))
    manifest = dict(metadata, schema_version=SCHEMA_VERSION, tier=tier,
                    artifact=data_path.name, sha256=sha256(data_path))
    atomic_bytes(manifest_path, lambda f: f.write(json.dumps(manifest, indent=2).encode()))
    return manifest

def load_prepared(root, tier):
    """Load only self-created trusted pickle files. Never deserialize unknown input."""
    directory = Path(root) / 'data/prepared'
    manifest_path = directory / f'tier{tier}.json'
    if not manifest_path.exists():
        raise FileNotFoundError(f'Tier {tier} preparation is missing. Run: highk --root {root} prepare --tier {tier}')
    manifest = json.loads(manifest_path.read_text())
    if manifest['schema_version'] != SCHEMA_VERSION or manifest['tier'] != tier:
        raise RuntimeError('Prepared artifact schema mismatch; prepare again.')
    data_path = directory / f'tier{tier}.pkl'
    if manifest['artifact'] != data_path.name or sha256(data_path) != manifest['sha256']:
        raise RuntimeError('Prepared data checksum mismatch; prepare again.')
    for name, expected in manifest.get('split_sha256', {}).items():
        path = Path(root) / 'reports/tier3_splits' / name
        if not path.exists() or sha256(path) != expected:
            raise RuntimeError('Tier-3 split identity changed after preparation; prepare again.')
    with data_path.open('rb') as stream:
        return pickle.load(stream), manifest
