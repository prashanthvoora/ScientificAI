from __future__ import annotations
from .common import Dict, FUNCTIONAL_CODE, List, Optional, TIER3_TRAIN_CONFIG, log, np, pd
from .graph_data import infer_material_family_from_row

def _impute_structures(df_process_only: 'pd.DataFrame', df_structural: 'pd.DataFrame') -> tuple['pd.DataFrame', 'pd.DataFrame']:
    """Assign the best available JARVIS/MP crystal structure to experimental
    rows that have ALD process params + measured k but no atoms_dict."""
    if len(df_process_only) == 0:
        return (df_process_only.copy(), pd.DataFrame(columns=df_process_only.columns))
    donor_pool = df_structural[df_structural['atoms_dict'].notna()].copy()
    donor_pool['_source_rank'] = donor_pool['source'].apply(lambda s: 0 if str(s).startswith('JARVIS') else 1)
    donor_pool['_ef_abs'] = pd.to_numeric(donor_pool.get('formation_energy_peratom', pd.Series(dtype=float)), errors='coerce').abs().fillna(999.0)
    donor_pool = donor_pool.sort_values(['_source_rank', '_ef_abs'], ascending=[True, True])
    formula_to_donor: dict[str, pd.Series] = {}
    for formula, grp in donor_pool.groupby('formula', sort=False):
        formula_to_donor[str(formula)] = grp.iloc[0]
    try:
        from pymatgen.core import Composition

        def _reduced(f: str) -> str:
            try:
                return Composition(f).reduced_formula
            except Exception:
                return f
        reduced_map = {_reduced(f): f for f in formula_to_donor}
    except ImportError:
        _reduced = lambda f: f
        reduced_map = {}
    FORMULA_ALIASES: Dict[str, List[str]] = {'Hf0.5Zr0.5O2': ['HfZrO4', 'Hf2Zr2O8', 'HfO2'], 'Hf0.5Zr0.5O2/HfO2': ['HfZrO4', 'HfO2'], 'HfZrO2_LaSi': ['HfZrO4', 'HfO2'], 'HfO2/ZrO2/HfO2': ['HfO2'], 'HfAlO': ['HfAlO4', 'Al2HfO6', 'HfO2'], 'HfSiO': ['HfSiO4', 'Hf2Si2O8', 'HfO2'], 'HfLaO': ['HfO2'], 'HfYO': ['HfO2'], 'HfO2:La': ['HfO2'], 'HfO2:Al': ['HfO2'], 'HfO2:Y': ['HfO2'], 'HfO2:Gd': ['HfO2'], 'HfO2:N': ['HfO2'], 'HfO2:Sr': ['HfO2'], 'HfO2 on MoS2': ['HfO2'], 'HfO2/Al2O3_nanolaminate': ['HfO2'], 'HfO2/Al2O3_multilayer': ['HfO2'], 'ZrAlO': ['ZrO2'], 'SrTiO3': ['SrTiO3', 'TiO2'], 'BaTiO3': ['BaTiO3', 'TiO2'], 'La2O3': ['La2O3', 'LaAlO3'], 'LaAlO3': ['LaAlO3', 'La2O3'], 'LaAlO_solgel': ['LaAlO3'], 'La1-xAlxO3': ['LaAlO3'], 'Ta2O5': ['Ta2O5'], 'TiO2': ['TiO2'], 'Y2O3': ['Y2O3'], 'Nb2O5': ['Nb2O5', 'TiO2']}
    formula_to_donors: dict[str, list[pd.Series]] = {}
    for formula, grp in donor_pool.groupby('formula', sort=False):
        formula_to_donors[str(formula)] = [r for _, r in grp.iterrows()]

    def _candidate_donors(material: str) -> list[pd.Series]:
        """Return ordered donor candidates for a material string."""
        m = str(material).strip()
        if not m or m.lower() in ('nan', 'none', ''):
            return []
        candidates: list[pd.Series] = []

        def _add_formula(f: str):
            if f in formula_to_donors:
                candidates.extend(formula_to_donors[f])
            f_red = _reduced(f)
            if f_red in reduced_map:
                canon = reduced_map[f_red]
                if canon in formula_to_donors:
                    candidates.extend(formula_to_donors[canon])
        _add_formula(m)
        if m in FORMULA_ALIASES:
            for alias in FORMULA_ALIASES[m]:
                _add_formula(alias)
        first_token = m.split('/')[0].split('_')[0].split(' ')[0].strip()
        if first_token != m:
            _add_formula(first_token)
        for canon in formula_to_donors:
            if m.startswith(canon) or canon.startswith(m):
                _add_formula(canon)
        if not candidates:
            if 'Hf' in m:
                _add_formula('HfO2')
            if 'Zr' in m:
                _add_formula('ZrO2')
        seen = set()
        uniq = []
        for d in candidates:
            key = str(d.get('row_hash', d.get('jid', d.get('mp_id', id(d)))))
            if key not in seen:
                seen.add(key)
                uniq.append(d)
        return uniq

    def _phase_hint(row: pd.Series) -> str:
        """Infer a coarse ALD film phase hint from process fields only."""
        mat = str(row.get('material', row.get('material_system', '')))
        fam = infer_material_family_from_row(row)
        reported_phase = str(row.get('reported_phase', row.get('crystal_phase', ''))).lower()
        anneal = pd.to_numeric(row.get('anneal_temp_C', row.get('anneal_temp_PDA_C', np.nan)), errors='coerce')
        tsub = pd.to_numeric(row.get('substrate_temp_C', row.get('ald_substrate_temp_C', np.nan)), errors='coerce')
        ambient = str(row.get('anneal_ambient', row.get('anneal_atmosphere', ''))).lower()
        has_zr = fam == 'hzo_like' or 'Zr' in mat or 'HZO' in mat.upper() or ('Hf0.' in mat)
        doped = fam.startswith('doped_hfo2') or any((x in mat for x in [':', 'Al', 'La', 'Y', 'Gd', 'Sr', 'Si', 'N']))
        if 'orthorhombic' in reported_phase:
            return 'reported_orthorhombic_like'
        if 'tetragonal' in reported_phase:
            return 'reported_tetragonal_like'
        if 'monoclinic' in reported_phase:
            return 'reported_monoclinic_like'
        if 'amorph' in reported_phase:
            return 'reported_amorphous_like'
        if has_zr:
            if pd.notna(anneal) and anneal >= 400:
                return 'hzo_annealed_orthorhombic_like'
            return 'hzo_mixed_like'
        if pd.notna(anneal) and anneal >= 450:
            return 'annealed_monoclinic_like'
        if pd.notna(tsub) and tsub <= 300 and (pd.isna(anneal) or anneal < 400):
            return 'low_temp_amorphous_like'
        if doped:
            return 'doped_hfo2_like'
        if 'o2' in ambient or 'n2' in ambient or 'forming' in ambient:
            return 'pda_modified_like'
        return 'generic_hfo2_like'

    def _score_donor(row: pd.Series, donor: pd.Series) -> float:
        """Score donor candidate using formula/process metadata only."""
        mat = str(row.get('material', row.get('material_system', '')))
        fam = infer_material_family_from_row(row)
        d_formula = str(donor.get('formula', ''))
        source = str(donor.get('source', ''))
        phase_hint = _phase_hint(row)
        score = 0.0
        if fam == 'hzo_like':
            if 'Hf' in d_formula and 'Zr' in d_formula:
                score += 70.0
            elif d_formula == 'HfO2':
                score -= 25.0
        elif fam == 'doped_hfo2_al':
            if 'Hf' in d_formula and 'Al' in d_formula:
                score += 60.0
            elif d_formula == 'HfO2':
                score += 10.0
        elif fam.startswith('doped_hfo2'):
            if 'Hf' in d_formula and d_formula != 'HfO2':
                score += 40.0
        elif fam == 'pure_hfo2' and d_formula == 'HfO2':
            score += 60.0
        if d_formula == mat:
            score += 100.0
        if _reduced(d_formula) == _reduced(mat):
            score += 60.0
        if 'Hf' in mat and 'Hf' in d_formula:
            score += 25.0
        if 'Zr' in mat and 'Zr' in d_formula:
            score += 25.0
        if 'Al' in mat and 'Al' in d_formula:
            score += 15.0
        if 'Si' in mat and 'Si' in d_formula:
            score += 15.0
        if 'hzo' in phase_hint:
            if 'Hf' in d_formula and 'Zr' in d_formula:
                score += 40.0
            elif d_formula == 'HfO2':
                score -= 10.0
        if 'annealed_monoclinic' in phase_hint and d_formula == 'HfO2':
            score += 20.0
        if 'low_temp_amorphous' in phase_hint:
            if d_formula == 'HfO2':
                score += 10.0
        if 'doped_hfo2' in phase_hint:
            if d_formula not in ('HfO2', 'ZrO2') and 'Hf' in d_formula:
                score += 25.0
        if source.startswith('JARVIS'):
            score += 5.0
        ef_abs = pd.to_numeric(donor.get('formation_energy_per_atom', donor.get('formation_energy_peratom', np.nan)), errors='coerce')
        if pd.notna(ef_abs):
            score -= 0.01 * abs(float(ef_abs))
        return score

    def _find_donor(row: pd.Series) -> tuple[Optional[pd.Series], dict]:
        """Return best phase-aware donor and audit metadata."""
        material = row.get('material', row.get('material_system', ''))
        candidates = _candidate_donors(str(material))
        meta = {'phase_hint': _phase_hint(row), 'n_candidates': len(candidates), 'strategy': 'phase_aware' if len(candidates) else 'unmatched', 'best_score': float('nan'), 'candidate_formulas': ''}
        if not candidates:
            return (None, meta)
        if not TIER3_TRAIN_CONFIG.get('phase_aware_donor_selection', True):
            d = candidates[0]
            meta.update({'strategy': 'first_match_legacy', 'best_score': 0.0, 'candidate_formulas': ','.join(sorted({str(c.get('formula', '?')) for c in candidates}))[:200]})
            return (d, meta)
        scored = [(float(_score_donor(row, d)), d) for d in candidates]
        scored.sort(key=lambda x: x[0], reverse=True)
        best_score, best_donor = scored[0]
        meta.update({'best_score': best_score, 'candidate_formulas': ','.join([str(d.get('formula', '?')) for _, d in scored[:TIER3_TRAIN_CONFIG.get('donor_log_topn', 5)]])[:200]})
        return (best_donor, meta)
    df_imp = df_process_only.copy()
    df_imp['imputed_structure'] = False
    df_imp['imputed_from'] = ''
    matched_idx = []
    unmatched_idx = []
    for idx, row in df_imp.iterrows():
        donor, donor_meta = _find_donor(row)
        if donor is not None:
            df_imp.at[idx, 'atoms_dict'] = donor['atoms_dict']
            df_imp.at[idx, 'imputed_structure'] = True
            df_imp.at[idx, 'has_structure'] = True
            df_imp.at[idx, 'imputed_from'] = str(donor.get('jid', donor.get('mp_id', donor.get('row_hash', '?'))))
            df_imp.at[idx, 'imputed_donor_formula'] = str(donor.get('formula', ''))
            df_imp.at[idx, 'imputed_donor_source'] = str(donor.get('source', ''))
            df_imp.at[idx, 'imputed_donor_strategy'] = donor_meta.get('strategy', '')
            df_imp.at[idx, 'imputed_phase_hint'] = donor_meta.get('phase_hint', '')
            df_imp.at[idx, 'imputed_donor_score'] = donor_meta.get('best_score', float('nan'))
            df_imp.at[idx, 'imputed_candidate_formulas'] = donor_meta.get('candidate_formulas', '')
            if 'spacegroup' in donor.index:
                df_imp.at[idx, 'imputed_spacegroup'] = donor['spacegroup']
            source = str(donor.get('source', 'JARVIS'))
            df_imp.at[idx, 'functional_code'] = FUNCTIONAL_CODE.get('OptB88vdW', 0) if source.startswith('JARVIS') else FUNCTIONAL_CODE.get('PBE', 1)
            matched_idx.append(idx)
        else:
            unmatched_idx.append(idx)
    df_imputed = df_imp.loc[matched_idx].copy()
    df_unmatched = df_imp.loc[unmatched_idx].copy()
    log.debug('FIX-T3-7 structure imputation: %d/%d rows matched  (%d unmatched)', len(df_imputed), len(df_process_only), len(df_unmatched))
    if df_imputed is not None and len(df_imputed) > 0:
        by_formula = df_imputed.groupby(df_imputed.get('material', pd.Series(dtype=str))).size()
        for formula, cnt in by_formula.items():
            sample_donor = df_imputed[df_imputed.get('material', pd.Series(dtype=str)) == formula]['imputed_from'].iloc[0] if cnt > 0 else '?'
            log.debug('  %-20s  %3d rows  ← donor: %s', formula, cnt, sample_donor)
    if len(df_unmatched) > 0:
        _mat_col = 'material' if 'material' in df_unmatched.columns else 'material_system' if 'material_system' in df_unmatched.columns else None
        unmatched_formulas = df_unmatched[_mat_col].dropna().unique().tolist() if _mat_col else []
        log.warning('FIX-T3-7: %d rows unmatched — no JARVIS/MP donor for: %s.  Add these formulas to the HfO2-family filter or supply atoms_dict manually.', len(df_unmatched), unmatched_formulas)
    return (df_imputed, df_unmatched)

def _clean_numeric_series(series: 'pd.Series', col_name: str='') -> 'pd.Series':
    """FIX-T3-11: Convert literature-style numeric strings to float."""
    import re as _re
    _APPROX_PREFIXES = ('~', '≈', 'ca.', 'about ', '~<', '~>', '<', '>', '≤', '≥')
    _UNIT_SUFFIX_RE = _re.compile('\\s*(MV/cm|V/cm|MV|kV|Torr|mTorr|Pa|MPa|GPa|nm|Å|at\\s+\\d[\\de\\.]*\\s*\\w*/\\w*|at\\s+\\S+)', _re.IGNORECASE)
    _RANGE_SEP_RE = _re.compile('^(\\d[\\d\\.e\\+\\-]*)\\s*(?:–|-)\\s*(\\d[\\d\\.e\\+\\-]*)$')
    _TO_SEP_RE = _re.compile('^(\\d[\\d\\.e\\+\\-]*)\\s+to\\s+(\\d[\\d\\.e\\+\\-]*)$', _re.IGNORECASE)

    def _parse_one(raw) -> float:
        if raw is None or (isinstance(raw, float) and np.isnan(raw)):
            return float('nan')
        s = str(raw).strip()
        if not s or s.lower() in ('nan', 'none', 'n/a', 'na', '-', ''):
            return float('nan')
        s = _UNIT_SUFFIX_RE.sub('', s).strip()
        for pfx in _APPROX_PREFIXES:
            if s.startswith(pfx):
                s = s[len(pfx):].strip()
                break
        m = _TO_SEP_RE.match(s)
        if m:
            try:
                return (float(m.group(1)) + float(m.group(2))) / 2.0
            except ValueError:
                pass
        m = _RANGE_SEP_RE.match(s)
        if m:
            try:
                lo, hi = (float(m.group(1)), float(m.group(2)))
                if lo <= hi:
                    return (lo + hi) / 2.0
            except ValueError:
                pass
        try:
            return float(s)
        except ValueError:
            log.debug("FIX-T3-11 _clean_numeric_series [%s]: qualitative/unmappable value '%s' → NaN", col_name, raw)
            return float('nan')
    cleaned = series.apply(_parse_one).astype(float)
    n_before = int(series.notna().sum()) if hasattr(series, 'notna') else 0
    n_after = int(cleaned.notna().sum())
    n_recovered = n_after - n_before
    if n_recovered > 0:
        log.debug('FIX-T3-11 numeric clean [%-28s]: %d non-blank → %d valid float  (+%d recovered from ~prefix/range/suffix)', col_name + ']', n_before, n_after, n_recovered)
    elif n_before > 0:
        log.debug('FIX-T3-11 numeric clean [%-28s]: %d non-blank → %d valid float  (0 additional recoveries)', col_name + ']', n_before, n_after)
    return cleaned
