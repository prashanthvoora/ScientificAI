from __future__ import annotations
from .distributed import is_rank0
from .trainer import ALIGNNTrainer
from .common import ALIGNN_BASE_CONFIG, DATA_ROOT, HIGH_K_DONOR_ELEMENTS, Path, REPORT_ROOT, TIER1_TRAIN_CONFIG, TIER2_TRAIN_CONFIG, TIER3_TRAIN_CONFIG, json, log, math, np, pd, torch
from .model import HighKALIGNN, _load_state_dict_shape_compatible
from .imputation import _impute_structures
from .splits import build_dataloader, build_tier3_hfo2_eval_dataloader

def run_tier_evaluate(tier: int, df: pd.DataFrame, checkpoint_path: Path, ablate_context: bool=False):
    """Load a saved checkpoint and re-run the full test evaluation without
    retraining.  Useful when:
      - Training completed but the evaluation block crashed with an error
      - You fixed a bug and want to re-validate the best checkpoint
      - You want to compare multiple saved checkpoints head-to-head"""
    if tier not in (1, 2, 3):
        raise ValueError(f'run_tier_evaluate supports tiers 1, 2, 3 — got {tier}')
    tier_label = f'TIER {tier}'
    log.debug('=' * 70)
    log.debug(' %s -- Checkpoint Evaluation (no retraining)', tier_label)
    log.debug(' Checkpoint : %s', checkpoint_path)
    log.debug(' Rows in df : %d', len(df))
    log.debug('=' * 70)
    if tier == 1:
        cfg = TIER1_TRAIN_CONFIG
        df_eval = df.copy()
        for log_col, src_col in cfg.get('log_transform_aux', {}).items():
            if src_col in df_eval.columns:
                src_numeric = pd.to_numeric(df_eval[src_col], errors='coerce')
                mask = src_numeric.notna()
                df_eval[log_col] = np.nan
                df_eval.loc[mask, log_col] = np.log(src_numeric[mask].clip(lower=0.1))
                log.debug('Aux log transform: %s → %s  (%d non-null rows)', src_col, log_col, int(mask.sum()))
        target_col = cfg['target']
        task_names = [target_col] + cfg['aux_targets']
        ckpt_prefix = 'tier1'
    elif tier == 2:
        cfg = TIER2_TRAIN_CONFIG
        df_eval = df[pd.to_numeric(df['k_total'], errors='coerce').notna()].copy()
        log.debug('Tier 2 rows with k_total: %d', len(df_eval))
        if cfg.get('log_transform', False):
            orig_col = cfg['log_original_col']
            log_col = cfg['target']
            k_num = pd.to_numeric(df_eval[orig_col], errors='coerce')
            df_eval[log_col] = np.log(k_num.clip(lower=0.1))
            log.debug('Log transform: %s → %s  range=[%.3f, %.3f]', orig_col, log_col, df_eval[log_col].min(), df_eval[log_col].max())
        target_col = cfg['target']
        task_names = [target_col] + cfg['aux_targets']
        ckpt_prefix = 'tier2'
    else:
        cfg = TIER3_TRAIN_CONFIG
        df_eval = df.copy()
        if 'atoms_dict' in df_eval.columns:
            _df_structural_eval = df_eval[df_eval['atoms_dict'].notna()].copy()
            _df_process_only_eval = df_eval[df_eval['atoms_dict'].isna()].copy()
            if len(_df_process_only_eval) > 0:
                _tier2_path = DATA_ROOT / 'tier2_domain.h5'
                if _tier2_path.exists():
                    try:
                        _df_tier2_eval = pd.read_hdf(_tier2_path, key='data')
                        _df_donor_pool_wide = _df_tier2_eval[_df_tier2_eval['formula'].apply(lambda f: isinstance(f, str) and 'O' in f and any((el in f for el in HIGH_K_DONOR_ELEMENTS)))].copy()
                    except Exception as exc:
                        log.warning('v4.36 EVAL-IMPUTE: failed to load Tier2 donor pool from %s: %s; using structural fallback', _tier2_path, exc)
                        _df_donor_pool_wide = _df_structural_eval
                else:
                    log.warning('v4.36 EVAL-IMPUTE: Tier2 donor pool not found at %s; using structural fallback', _tier2_path)
                    _df_donor_pool_wide = _df_structural_eval
                _df_imputed_eval, _df_unmatched_eval = _impute_structures(_df_process_only_eval, _df_donor_pool_wide)
                if len(_df_imputed_eval) > 0:
                    df_eval = pd.concat([_df_structural_eval, _df_imputed_eval], ignore_index=True, sort=False)
                    log.debug('v4.36 EVAL-IMPUTE: tier3_evaluate dataframe after imputation rows=%d (original structural=%d imputed_experimental=%d unmatched=%d)', len(df_eval), len(_df_structural_eval), len(_df_imputed_eval), len(_df_unmatched_eval))
                else:
                    df_eval = _df_structural_eval.copy()
                    log.warning('v4.36 EVAL-IMPUTE: no process-only rows imputed; evaluating structural rows only')
        if cfg.get('log_transform', False):
            src_col = cfg['log_original_col']
            log_col = cfg['target']
            k_num = pd.to_numeric(df_eval[src_col], errors='coerce')
            valid_k = k_num.notna()
            df_eval[log_col] = np.nan
            df_eval.loc[valid_k, log_col] = np.log(k_num[valid_k].clip(lower=0.1))
            log.debug('tier3_evaluate: log transform %s → %s  (%d rows)', src_col, log_col, int(valid_k.sum()))
        df_kvalid = df_eval[df_eval[cfg['target']].notna()].copy()
        log.debug('Tier 3 rows with %s : %d (matches training df_phase_b)', cfg['target'], len(df_kvalid))
        if 'atoms_dict' in df_kvalid.columns:
            df_eval = df_kvalid[df_kvalid['atoms_dict'].notna()].copy()
            n_dropped = len(df_kvalid) - len(df_eval)
            if n_dropped > 0:
                log.debug('Tier 3 %d k-valid rows without atoms_dict dropped (split will be on %d structural k-valid rows)', n_dropped, len(df_eval))
        else:
            df_eval = df_kvalid
        target_col = cfg['target']
        task_names = [target_col] + cfg['aux_targets']
        ckpt_prefix = 'tier3'
    if tier == 3 and cfg.get('eval_hfo2_family_only', False):
        _, _, test_loader, _, test_dataset = build_tier3_hfo2_eval_dataloader(df=df_eval, target_col=target_col, aux_cols=[t for t in task_names if t != target_col], train_frac=cfg['train_ratio'], val_frac=cfg['val_ratio'], batch_size=cfg['batch_size'], use_saved_test_split=True, save_test_split=False, overwrite_saved_split=False, use_saved_val_split=True, test_only=True)
        log.debug('Test loader: %d batches  (BASELINE locked persistent TEST-only split)', len(test_loader))
    else:
        _, _, test_loader, _, test_dataset = build_dataloader(df=df_eval, target_col=target_col, aux_cols=[t for t in task_names if t != target_col], train_frac=cfg['train_ratio'], val_frac=cfg['val_ratio'], batch_size=cfg['batch_size'])
        log.debug('Test loader: %d batches  (seed=42 → same split as training)', len(test_loader))
    model = HighKALIGNN(config=ALIGNN_BASE_CONFIG, task_names=task_names)
    model.fit_encoder_stats(df_eval)
    if not checkpoint_path.exists():
        log.error('Checkpoint not found: %s', checkpoint_path)
        return
    ckpt = torch.load(checkpoint_path, map_location='cpu')
    saved_epoch = ckpt.get('epoch', '?')
    saved_mae = ckpt.get('val_mae', float('nan'))
    if tier == 3:
        _saved_runtime = ckpt.get('adapter_runtime', {}) or {}
        _saved_cfg = ckpt.get('config', {}) or {}
        _adapter_enabled = bool(_saved_runtime.get('enabled', _saved_cfg.get('tier3_use_structural_adapter', cfg.get('tier3_use_structural_adapter', True))))
        _adapter_rank = int(_saved_runtime.get('rank', _saved_cfg.get('tier3_structural_adapter_rank', cfg.get('tier3_structural_adapter_rank', 16))))
        model.configure_structural_adapter(enabled=_adapter_enabled, rank=_adapter_rank, reset=False)
        log.debug('v4.58 EVAL-ADAPTER-CONFIG: restored enabled=%s rank=%d from checkpoint metadata', _adapter_enabled, _adapter_rank)
    missing, unexpected = _load_state_dict_shape_compatible(model, ckpt.get('model_state_dict', ckpt), checkpoint_label=str(checkpoint_path))
    log.debug('Loaded checkpoint: epoch=%s  saved_val_MAE=%.4f  missing=%d unexpected=%d', saved_epoch, saved_mae, len(missing), len(unexpected))
    if tier == 3 and _adapter_enabled:
        _adapter_missing = [k for k in missing if k.startswith('tier3_structural_adapter.')]
        _state = ckpt.get('model_state_dict', ckpt)
        _adapter_saved = [k for k in _state if k.startswith('tier3_structural_adapter.')]
        if not _adapter_saved:
            raise RuntimeError('v4.58 EVAL CHECKPOINT ERROR: structural adapter is enabled but the checkpoint contains no tier3_structural_adapter tensors. Refusing to report a process-only result.')
        if _adapter_missing:
            raise RuntimeError('v4.58 EVAL CHECKPOINT ERROR: adapter tensors were not restored: ' + str(_adapter_missing))
    if tier == 3:
        model.configure_structural_adapter(enabled=_adapter_enabled, rank=_adapter_rank, reset=False)
        model.configure_bounded_process_residual(enabled=cfg.get('bounded_process_residual', False), bound=cfg.get('process_delta_bound', 0.15), use_categorical=cfg.get('process_delta_use_categorical', True))
        log.debug('v4.50 T3-EVAL-RESIDUAL-RESTORE: enabled=%s bound=%.3f use_categorical=%s ablate_context=%s', bool(model.use_bounded_process_residual), float(model.process_delta_bound), bool(model.process_delta_use_categorical), bool(ablate_context))
        if not ablate_context and (not model.use_bounded_process_residual):
            raise RuntimeError('tier3_evaluate requested a normal process-aware evaluation, but bounded_process_residual is disabled. Refusing to report an ablation metric as the Tier-3 checkpoint result.')
    trainer = ALIGNNTrainer(model, cfg, ckpt_prefix=ckpt_prefix, ablate_context=ablate_context)
    test_mae_log, test_rmse_log, preds_t, trues_t = trainer.evaluate(test_loader, target_col, return_preds=True)
    if tier == 3:
        _adapter_eval_diag = trainer.evaluate_adapter_diagnostics(test_loader, target_col, split_name='TEST-EVALUATE')
    log.debug('')
    log.debug('─' * 68)
    log.info('  %s TEST RESULTS  (checkpoint: ep %s)', tier_label, saved_epoch)
    log.debug('─' * 68)
    if tier == 2 and cfg.get('log_transform', False):
        valid = ~torch.isnan(trues_t)
        mae_k_exact = (torch.exp(preds_t[valid]) - torch.exp(trues_t[valid])).abs().mean().item()
        rmse_k_exact = ((torch.exp(preds_t[valid]) - torch.exp(trues_t[valid])) ** 2).mean().sqrt().item()
        log.debug('  Diagnostic log-space  MAE  = %.4f  [log(k) units]', test_mae_log)
        log.debug('  Diagnostic log-space  RMSE = %.4f', test_rmse_log)
        log.debug('  exp(MAE)                  = %.4f×  → ±%.1f%% average relative error', math.exp(test_mae_log), (math.exp(test_mae_log) - 1) * 100)
        log.debug('  PRIMARY benchmark (linear-k) MAE  = %.4f  [dielectric units, exact]', mae_k_exact)
        log.debug('  PRIMARY benchmark (linear-k) RMSE = %.4f  [dielectric units]', rmse_k_exact)
        log.debug('  Benchmark scale for publication: LINEAR-K')
        log.debug('  ALIGNN paper    ≈ 0.81  [linear k, JARVIS DFPT]')
    elif tier == 3:
        valid = ~torch.isnan(trues_t)
        if valid.sum() > 0:
            _p_lin = torch.exp(preds_t[valid])
            _t_lin = torch.exp(trues_t[valid])
            mae_k_exact = (_p_lin - _t_lin).abs().mean().item()
            rmse_k_exact = ((_p_lin - _t_lin) ** 2).mean().sqrt().item()
            _t_np = _t_lin.cpu().numpy()
            mad_k_exact = float(np.mean(np.abs(_t_np - np.mean(_t_np))))
            mad_mae_k_exact = mad_k_exact / mae_k_exact if mae_k_exact > 0 else float('nan')
            n_k_exact = int(valid.sum())
        else:
            mae_k_exact = rmse_k_exact = mad_k_exact = mad_mae_k_exact = float('nan')
            n_k_exact = 0
        log.debug(' Diagnostic log-space MAE = %.4f [log(k) units]', test_mae_log)
        log.debug(' Diagnostic log-space RMSE = %.4f ', test_rmse_log)
        log.debug(' exp (MAE) = %.4fx -> %.1f%% avg relative error', math.exp(test_mae_log) if not math.isnan(test_mae_log) else float('nan'), (math.exp(test_mae_log) - 1) * 100 if not math.isnan(test_mae_log) else float('nan'))
        if not math.isnan(mae_k_exact):
            log.debug(' PRIMARY (linear - k exact) MAE = %.4f [dielectric units]', mae_k_exact)
            log.debug(' PRIMARY (linear - k exact) RMSE = %.4f [dielectric units]', rmse_k_exact)
        else:
            log.debug(' PRIMARY (linear - k exact) MAE = N/A (no valid samples)')
            log.debug(' PRIMARY (linear - k exact) RMSE = N/A')
    else:
        log.debug('  MAE  = %.4f', test_mae_log)
        log.debug('  RMSE = %.4f', test_rmse_log)
    mt_results = trainer.evaluate_multitask(test_loader, cfg, df_full=test_dataset.df)
    if tier in (2, 3) and cfg.get('log_transform', False) and (target_col in mt_results):
        if tier == 2:
            _true_k_np = torch.exp(trues_t[~torch.isnan(trues_t)]).cpu().numpy()
            mad_k_exact = float(np.mean(np.abs(_true_k_np - np.mean(_true_k_np)))) if len(_true_k_np) else float('nan')
            mad_mae_k_exact = mad_k_exact / mae_k_exact if mae_k_exact > 0 else float('nan')
            n_k_exact = int((~torch.isnan(trues_t)).sum().item())
        mt_results[target_col].update({'mae_log': float(test_mae_log), 'rmse_log': float(test_rmse_log), 'mae_linear': float(mae_k_exact), 'rmse_linear': float(rmse_k_exact), 'mad_linear': float(mad_k_exact), 'mad_mae_linear': float(mad_mae_k_exact), 'mae': float(mae_k_exact), 'rmse': float(rmse_k_exact), 'mad': float(mad_k_exact), 'mad_mae_ratio': float(mad_mae_k_exact), 'n': int(n_k_exact), 'coverage_pct': 100.0, 'mad_source': 'same fixed TEST rows as primary evaluation', 'metric_scale': 'linear-k exact', 'display_name': 'k_total'})
    trainer.print_multitask_results(mt_results, split_name='TEST', tier_name=tier_label)
    if tier == 3 and target_col in mt_results and (mt_results[target_col]['n'] > 0):
        km = mt_results[target_col]
        log.debug('k_total (linear exact)  MAD=%.2f  MAE=%.4f  MAD:MAE=%.2f  (paper: 1.63 @ 44K no transfer | goal: ≥ 2.5 with three-tier transfer)', km['mad'], km['mae'], km['mad_mae_ratio'])
    out_path = REPORT_ROOT / f'tier{tier}_evaluate_results.json'
    primary = {'mae': test_mae_log, 'rmse': test_rmse_log, 'mae_log_k': test_mae_log, 'rmse_log_k': test_rmse_log, 'checkpoint_epoch': saved_epoch, 'checkpoint_val_mae': saved_mae, 'benchmark_scale': 'linear', 'diagnostic_scale': 'log'}
    if tier == 2 and cfg.get('log_transform', False):
        primary.update({'mae_linear_k': mae_k_exact, 'rmse_linear_k': rmse_k_exact, 'mad_linear_k': mad_k_exact, 'mad_mae_linear': mad_mae_k_exact, 'n_test': n_k_exact, 'mae': mae_k_exact, 'rmse': rmse_k_exact, 'exp_mae_multiplier': math.exp(test_mae_log)})
    elif tier == 3:
        primary.update({'mae_linear_k': mae_k_exact, 'rmse_linear_k': rmse_k_exact, 'mad_k': mad_k_exact, 'mad_mae': mad_mae_k_exact, 'n_test': n_k_exact, 'mae': mae_k_exact, 'rmse': rmse_k_exact})
    if is_rank0():
        with open(out_path, 'w') as f:
            json.dump({'primary': primary, 'multitask': mt_results}, f, indent=2)
    log.debug('Results saved → %s', out_path)
    log.debug('─' * 68)
