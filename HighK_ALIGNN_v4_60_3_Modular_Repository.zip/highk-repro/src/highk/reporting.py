from __future__ import annotations
from .common import PROCESS_PARAMS_FEATURES, STACK_CONTEXT_FEATURES, log, pd

def _tier_col_summary(df: pd.DataFrame, col: str) -> str:
    """One-line stat string for a numeric column: count, %, mean, std."""
    if col not in df.columns:
        return 'column absent'
    s = df[col].dropna()
    if len(s) == 0:
        return '0 rows  (0.0%)'
    return f'{len(s):,} rows  ({100 * len(s) / len(df):.1f}%)  mean={s.mean():.3g}  std={s.std():.3g}  min={s.min():.3g}  max={s.max():.3g}'

def log_tier_summary(df: pd.DataFrame, tier_num: int, tier_name: str):
    """Emit a comprehensive per-tier summary to the logger.
    Called once per tier at the end of extract_only / after build_tier*.
    Covers all targets, source breakdown, k_total thresholds, and process coverage."""
    W = 70
    log.debug('=' * W)
    log.debug(' TIER %d  %s  |  %d total rows', tier_num, tier_name.upper(), len(df))
    log.debug('=' * W)
    n_struct = int(df['has_structure'].sum()) if 'has_structure' in df.columns else int(df['atoms_dict'].notna().sum()) if 'atoms_dict' in df.columns else 0
    log.debug('  Structural rows (ALIGNN-ready) : %d  (%.1f%%)', n_struct, 100 * n_struct / max(len(df), 1))
    if tier_num == 3:
        n_proc = len(df) - n_struct
        log.debug('  Process-only rows (no struct)  : %d  (%.1f%%)', n_proc, 100 * n_proc / max(len(df), 1))
    log.debug('')
    log.debug('  ── Dielectric targets ──────────────────────────────────')
    for col in ['k_total', 'k_measured', 'k_ionic', 'k_elec']:
        log.debug('  %-14s  %s', col + ':', _tier_col_summary(df, col))
    k_col = 'k_total'
    if k_col in df.columns:
        k = df[k_col].dropna()
        if len(k) > 0:
            log.debug('  %s thresholds:', k_col)
            for thresh, label in [(3.9, 'k>3.9 (above SiO2)'), (10, 'k>10  (coarse high-k)'), (25, 'k>25  (practical high-k)'), (35, 'k>35  (advanced high-k)'), (100, 'k>100 (ultra-high-k / ferroelec)')]:
                n = int((k > thresh).sum())
                log.debug('    %-28s %d  (%.1f%% of k rows)', label, n, 100 * n / len(k))
    if tier_num == 2:
        n_trainable = int(df['k_total'].notna().sum()) if 'k_total' in df.columns else 0
        log.debug('')
        log.debug('  ★ TIER 2 TRAINING DATASET SIZE (k_total.notna()): %d rows', n_trainable)
        log.debug('    (target ≥ 3,000 for robust fine-tuning)')
        if n_trainable < 1000:
            log.warning('    !! BELOW MINIMUM -- k_total head will be undertrained.    Check MP dielectric extraction (see FIX-DIELECTRIC-SCALAR).')
    log.debug('')
    log.debug('  ── Other property targets ──────────────────────────────')
    for col in ['band_gap', 'formation_energy_per_atom', 'e_above_hull', 'J_g_A_cm2', 'E_BD_MV_cm']:
        if col in df.columns:
            log.debug('  %-28s %s', col + ':', _tier_col_summary(df, col))
    log.debug('')
    if 'source' in df.columns:
        log.debug('  ── Source breakdown ────────────────────────────────────')
        for src, cnt in df['source'].value_counts().items():
            k_in_src = df.loc[df['source'] == src, 'k_total'].notna().sum() if 'k_total' in df.columns else 0
            log.debug('  %-22s %6d rows   k_total non-null: %d  (%.1f%%)', src, cnt, k_in_src, 100 * k_in_src / max(cnt, 1))
        log.debug('')
    if 'dft_functional' in df.columns:
        log.debug('  ── DFT functional breakdown ────────────────────────────')
        for fn, cnt in df['dft_functional'].value_counts().items():
            log.debug('  %-14s  %d  (%.1f%%)', fn, cnt, 100 * cnt / len(df))
        log.debug('')
    if tier_num == 3:
        log.debug('  ── Process/stack context coverage ──────────────────────')
        proc_cols = [c for c in PROCESS_PARAMS_FEATURES['numerical'] + list(PROCESS_PARAMS_FEATURES['categorical'].keys()) if c in df.columns]
        stack_cols = [c for c in STACK_CONTEXT_FEATURES['numerical'] + list(STACK_CONTEXT_FEATURES['categorical'].keys()) if c in df.columns]
        for col in proc_cols + stack_cols:
            n_filled = int(df[col].notna().sum())
            log.debug('  %-28s %d  (%.1f%%)', col + ':', n_filled, 100 * n_filled / max(len(df), 1))
        log.debug('')
    log.debug('=' * W)

def log_full_dataset_summary(df_tier1: pd.DataFrame, df_tier2: pd.DataFrame, df_tier3: pd.DataFrame):
    """Print a comprehensive summary for all three tiers after dataset generation.
    Called at the end of extract_only and after Step 5 in the main pipeline."""
    bar = '█' * 70
    log.debug('\n%s', bar)
    log.debug('  FULL DATASET GENERATION SUMMARY  (end of Step 5)')
    log.debug('%s\n', bar)
    tier_names = {1: 'Foundation Pretrain', 2: 'Domain Fine-tune', 3: 'Project Fine-tune'}
    tiers = {1: df_tier1, 2: df_tier2, 3: df_tier3}
    for t in [1, 2, 3]:
        df = tiers[t]
        if df is None or len(df) == 0:
            log.warning('  Tier %d (%s): EMPTY OR NOT BUILT', t, tier_names[t])
        else:
            log_tier_summary(df, t, tier_names[t])
    log.debug('  ┌─────────────────────────────────────────────────────────────┐')
    log.debug('  │  k_total AVAILABILITY ACROSS TIERS  (Tier 2 critical check) │')
    log.debug('  ├──────────────┬────────────┬────────────┬────────────────────┤')
    log.debug('  │ Tier         │ Total rows │ k_total    │ k_total > 10       │')
    log.debug('  ├──────────────┼────────────┼────────────┼────────────────────┤')
    for t, df, nm in [(1, df_tier1, 'Tier 1 Found.'), (2, df_tier2, 'Tier 2 Domain'), (3, df_tier3, 'Tier 3 Proj.')]:
        if df is None or len(df) == 0:
            log.debug('  │ %-12s │ %-10s │ %-10s │ %-18s │', nm, 'N/A', 'N/A', 'N/A')
            continue
        n_total = len(df)
        k_col = 'k_total'
        k_avail = int(df[k_col].notna().sum()) if k_col in df.columns else 0
        k_gt10 = int((df[k_col].dropna() > 10).sum()) if k_col in df.columns else 0
        pct = 100 * k_avail / max(n_total, 1)
        flag = '  ← TARGET ≥3K' if t == 2 and k_gt10 < 3000 else '  ✓ sufficient' if t == 2 and k_gt10 >= 3000 else ''
        log.debug('  │ %-12s │ %10d │ %10d │ %6d  (%4.1f%%)%s │', nm, n_total, k_avail, k_gt10, pct, flag)
    log.debug('  └──────────────┴────────────┴────────────┴────────────────────┘')
    log.debug('')
    log.debug('%s\n', bar)
