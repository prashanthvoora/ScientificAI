from __future__ import annotations
from .common import DataLoader, Dict, List, Optional, Path, Subset, TIER3_TEST_SPLIT_PATH, TIER3_TRAIN_CONFIG, TIER3_VAL_SPLIT_PATH, Tuple, _DIST, hashlib, log, np, pd, torch
from .graph_data import HighKGraphDataset
from .distributed import is_rank0

def get_stratified_split(dataset: HighKGraphDataset, train_frac: float=0.8, val_frac: float=0.1, seed: int=42, target_col: str=None) -> Tuple[Subset, Subset, Subset]:
    """Stratified split on target bins to ensure balanced distribution across
    all three splits. Falls back to random split if stratification fails."""
    from sklearn.model_selection import StratifiedShuffleSplit
    df = dataset.df.loc[dataset.valid_idx].copy()
    if target_col is None:
        target_col = dataset.target_col
    raw_vals = df[target_col]
    target_vals_f = pd.to_numeric(raw_vals, errors='coerce').values
    valid_mask = ~np.isnan(target_vals_f)
    if not valid_mask.any():
        log.warning('All target values are NaN. Falling back to random split.')
        return get_random_split(dataset, train_frac, val_frac, seed)
    try:
        n_valid = int(valid_mask.sum())
        n_bins = min(6, n_valid // 10)
        if n_bins < 2:
            log.warning('Not enough samples (%d) for stratification. Falling back to random split.', n_valid)
            return get_random_split(dataset, train_frac, val_frac, seed)
        percentiles = np.linspace(0, 100, n_bins + 1)
        bins_edges = np.percentile(target_vals_f[valid_mask], percentiles)
        bins_edges = np.unique(bins_edges)
        if len(bins_edges) < 2:
            log.warning('Not enough unique bins for stratification. Falling back to random split.')
            return get_random_split(dataset, train_frac, val_frac, seed)
        target_bins = np.digitize(target_vals_f, bins_edges[1:-1]).astype(int)
        nan_rows = ~valid_mask
        if nan_rows.any():
            median_bin = int(np.median(target_bins[valid_mask]))
            target_bins[nan_rows] = median_bin
        try:
            proc_avail = np.array([int(dataset.df.loc[dataset.valid_idx[i], 'source'] == 'Experimental') for i in range(len(dataset))])
        except Exception:
            proc_avail = np.zeros(len(dataset), dtype=int)
        composite_bins = target_bins * 2 + proc_avail
        unique, counts = np.unique(target_bins, return_counts=True)
        if (counts < 2).any():
            log.warning('Some bins have < 2 samples. Falling back to random split.')
            return get_random_split(dataset, train_frac, val_frac, seed)
        if train_frac < 1e-09:
            train_idx = np.array([], dtype=int)
            temp_idx = np.arange(len(dataset))
            composite_temp = composite_bins
            target_bins_temp = target_bins
        else:
            sss = StratifiedShuffleSplit(n_splits=1, test_size=1 - train_frac, random_state=seed)
            idx_all = np.arange(len(dataset))
            for train_idx, temp_idx in sss.split(idx_all, composite_bins):
                pass
            target_bins_temp = target_bins[temp_idx]
            composite_temp = composite_bins[temp_idx]
        test_ratio = (1 - train_frac - val_frac) / max(1 - train_frac, 1e-09)
        if test_ratio < 1e-09:
            val_idx = temp_idx
            test_idx = np.array([], dtype=int)
        elif test_ratio >= 1.0 - 1e-09:
            val_idx = np.array([], dtype=int)
            test_idx = temp_idx
            log.debug('Train/test-only split: val_frac=0 → assigning all %d temp rows to TEST', len(temp_idx))
        else:
            n_unique_bins_temp = len(np.unique(composite_temp))
            n_test_int = max(1, int(test_ratio * len(temp_idx)))
            if n_test_int < n_unique_bins_temp:
                log.warning('Second stratified split skipped (n_test=%d < n_bins=%d); using random val/test split on the %d temp samples.', n_test_int, n_unique_bins_temp, len(temp_idx))
                rng_local = np.random.default_rng(seed + 1)
                perm = rng_local.permutation(len(temp_idx))
                cut = max(1, int(len(temp_idx) * (val_frac / (1 - train_frac))))
                val_idx = temp_idx[perm[:cut]]
                test_idx = temp_idx[perm[cut:]]
            else:
                sss2 = StratifiedShuffleSplit(n_splits=1, test_size=test_ratio, random_state=seed)
                for val_idx_local, test_idx_local in sss2.split(np.arange(len(temp_idx)), composite_temp):
                    pass
                val_idx = temp_idx[val_idx_local]
                test_idx = temp_idx[test_idx_local]
    except Exception as e:
        log.warning('Stratification failed: %s. Falling back to random split.', e)
        return get_random_split(dataset, train_frac, val_frac, seed)
    log.debug('Stratified split -- train: %d  val: %d  test: %d  (bins: %d  target: %s)', len(train_idx), len(val_idx), len(test_idx), n_bins, target_col)
    return (Subset(dataset, train_idx.tolist()), Subset(dataset, val_idx.tolist()), Subset(dataset, test_idx.tolist()))

def get_random_split(dataset: HighKGraphDataset, train_frac: float=0.8, val_frac: float=0.1, seed: int=42) -> Tuple[Subset, Subset, Subset]:
    """Fallback random split if stratification fails."""
    np.random.seed(seed)
    idx_all = np.arange(len(dataset))
    np.random.shuffle(idx_all)
    n_train = int(len(idx_all) * train_frac)
    n_val = int(len(idx_all) * val_frac)
    train_idx = idx_all[:n_train]
    val_idx = idx_all[n_train:n_train + n_val]
    test_idx = idx_all[n_train + n_val:]
    log.debug('Random split -- train: %d  val: %d  test: %d', len(train_idx), len(val_idx), len(test_idx))
    return (Subset(dataset, train_idx.tolist()), Subset(dataset, val_idx.tolist()), Subset(dataset, test_idx.tolist()))

class BalancedDistributedSampler(torch.utils.data.Sampler):
    """
    Distributed Sampler that guraantees balances proc_avail (DFT vs experimental)
    across ranks every epoch via round-robin grouping.
    """

    def __init__(self, dataset, proc_avail: list[int], num_replicas: int=2, rank: int=0, seed: int=42, shuffle: bool=True):
        if num_replicas < 1 or not 0 <= rank < num_replicas:
            raise ValueError("Invalid distributed rank/world size")
        if len(proc_avail) != len(dataset):
            raise ValueError("Process flags must match the TRAIN subset")
        self.dataset = dataset
        self.proc_avail = proc_avail
        self.num_replicas = num_replicas
        self.rank = rank
        self.seed = seed
        self.shuffle = shuffle
        self.epoch = 0

    def __iter__(self):
        rng = np.random.default_rng(self.seed + self.epoch)
        indices = list(range(len(self.dataset)))
        groups: dict[int, list[int]] = {}
        for idx, pa in zip(indices, self.proc_avail):
            groups.setdefault(pa, []).append(idx)
        if self.shuffle:
            for pa in groups:
                rng.shuffle(groups[pa])
        group_keys = sorted(groups.keys())
        group_iters = {k: iter(v) for k, v in groups.items()}
        balanced: list[int] = []
        while True:
            added = False
            for gk in group_keys:
                try:
                    balanced.append(next(group_iters[gk]))
                    added = True
                except StopIteration:
                    pass
            if not added:
                break
        # Equal sample and batch counts prevent mismatched DDP collectives.
        total = len(self) * self.num_replicas
        if balanced:
            balanced += [balanced[i % len(balanced)] for i in range(total - len(balanced))]
        rank_indices = balanced[self.rank:total:self.num_replicas]
        return iter(rank_indices)

    def __len__(self):
        return (len(self.proc_avail) + self.num_replicas - 1) // self.num_replicas

    def set_epoch(self, epoch: int):
        self.epoch = epoch

def is_hfo2_eval_family_row(row: pd.Series) -> bool:
    """Return True for HfO2/HZO/Hf-Zr-O/doped-HfO2 target-family rows."""
    text = ' '.join((str(row.get(c, '')) for c in ['material', 'material_system', 'formula', 'composition', 'film_material', 'material_name'])).lower().replace(' ', '')
    if not text or text in {'nan', 'none'}:
        return False
    if any((tok in text for tok in ['hfo2', 'hzo', 'hfzro', 'hf-zr-o', 'hf0.', 'hf/o'])):
        return True
    has_hf = 'hf' in text
    has_oxide_marker = any((tok in text for tok in ['o', 'oxide', 'oxynitride', 'sio', 'sion']))
    if has_hf and has_oxide_marker:
        return True
    return False

def _norm_split_val(v) -> str:
    """Normalise values used in persistent split keys."""
    if v is None:
        return ''
    s = str(v).strip()
    if s.lower() in ('', 'nan', 'none', 'null'):
        return ''
    return s

def _tier3_split_keys_from_row(row: pd.Series) -> List[str]:
    """Return multiple stable keys for one Tier-3 row."""
    keys: List[str] = []
    for col in ['row_id', 'paper_id', 'doi', 'row_hash']:
        v = _norm_split_val(row.get(col, None))
        if v:
            keys.append(f'{col}:{v}')
    material = _norm_split_val(row.get('material', row.get('material_system', ''))).lower().replace(' ', '')
    formula = _norm_split_val(row.get('formula', '')).lower().replace(' ', '')
    source = _norm_split_val(row.get('source', '')).lower()
    kval_raw = row.get('k_total', row.get('k_measured', ''))
    try:
        kval = f'{float(kval_raw):.6g}'
    except Exception:
        kval = _norm_split_val(kval_raw)
    if material and kval:
        keys.append(f'matk:{material}|{source}|{kval}')
    if formula and kval:
        keys.append(f'formk:{formula}|{source}|{kval}')
    parts = []
    for col in ['paper_id', 'doi', 'material', 'material_system', 'formula', 'source', 'k_total']:
        parts.append(_norm_split_val(row.get(col, '')))
    fallback = 'fallback:' + '|'.join(parts)
    keys.append(fallback)
    seen = set()
    out = []
    for k in keys:
        if k and k not in seen:
            seen.add(k)
            out.append(k)
    return out

def _tier3_split_key_from_row(row: pd.Series) -> str:
    """Primary stable row key used for persistent Tier-3 split matching."""
    keys = _tier3_split_keys_from_row(row)
    return keys[0] if keys else 'fallback:'

def save_tier3_test_split_rows(dataset: 'HighKGraphDataset', valid_rows: pd.DataFrame, test_pos: np.ndarray, path: Path=TIER3_TEST_SPLIT_PATH, split_name: str='test', overwrite: bool=True) -> None:
    """Save exact Tier-3 TEST row IDs/keys used by finetune."""
    if not is_rank0():
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and (not overwrite):
        log.debug('Tier3 split file already exists; not overwriting: %s', path)
        return
    test_pos = np.asarray(test_pos, dtype=int)
    rows = []
    for p in test_pos.tolist():
        if p < 0 or p >= len(valid_rows):
            continue
        r = valid_rows.iloc[p]
        rows.append({'split': split_name, 'position': int(p), 'split_key': _tier3_split_key_from_row(r), 'split_key_candidates': '||'.join(_tier3_split_keys_from_row(r)), 'row_id': r.get('row_id', ''), 'row_hash': r.get('row_hash', ''), 'paper_id': r.get('paper_id', ''), 'doi': r.get('doi', ''), 'material': r.get('material', r.get('material_system', '')), 'formula': r.get('formula', ''), 'source': r.get('source', ''), 'data_quality': r.get('data_quality', ''), 'material_family': r.get('material_family', ''), 'k_total': r.get('k_total', ''), 'k_total_log': r.get('k_total_log', '')})
    pd.DataFrame(rows).to_csv(path, index=False)
    log.debug('v4.35 SPLIT-SAVE: saved Tier3 TEST split rows=%d → %s', len(rows), path)

def load_tier3_test_positions_from_split(valid_rows: pd.DataFrame, path: Path=TIER3_TEST_SPLIT_PATH) -> Optional[np.ndarray]:
    """Load saved Tier-3 TEST positions using strict one-to-one matching."""
    if not path.exists():
        log.debug('v4.41 STRICT-SPLIT-LOAD: no saved Tier3 split file at %s', path)
        return None
    try:
        split_df = pd.read_csv(path)
        if split_df.empty:
            log.warning('v4.41 STRICT-SPLIT-LOAD: empty split file: %s', path)
            return None
        current_key_map: Dict[str, List[int]] = {}
        current_rows = valid_rows.reset_index(drop=True)
        for pos, (_, row) in enumerate(current_rows.iterrows()):
            for key in _tier3_split_keys_from_row(row):
                current_key_map.setdefault(key, []).append(pos)
        used: set = set()
        matched: List[int] = []
        ambiguous_saved = 0
        unmatched_saved = 0

        def _ordered_saved_keys(r: pd.Series) -> List[str]:
            keys: List[str] = []
            for col in ['row_hash', 'row_id']:
                v = _norm_split_val(r.get(col, None))
                if v:
                    keys.append(f'{col}:{v}')
            primary = _norm_split_val(r.get('split_key', None))
            if primary:
                keys.append(primary)
            cand = _norm_split_val(r.get('split_key_candidates', None))
            if cand:
                keys.extend([k.strip() for k in cand.split('||') if k.strip()])
            keys.extend(_tier3_split_keys_from_row(r))
            seen = set()
            return [k for k in keys if k and (not (k in seen or seen.add(k)))]
        for _, saved_row in split_df.iterrows():
            selected = None
            had_ambiguous = False
            for key in _ordered_saved_keys(saved_row):
                candidates = [p for p in current_key_map.get(key, []) if p not in used]
                if len(candidates) == 1:
                    selected = candidates[0]
                    break
                if len(candidates) > 1:
                    had_ambiguous = True
                    exact = []
                    for p in candidates:
                        cur = current_rows.iloc[p]
                        checks = []
                        for col in ['row_hash', 'row_id', 'paper_id', 'doi', 'material', 'formula', 'source']:
                            sv = _norm_split_val(saved_row.get(col, None))
                            if sv:
                                checks.append(_norm_split_val(cur.get(col, None)) == sv)
                        try:
                            sk = float(saved_row.get('k_total', float('nan')))
                            ck = float(cur.get('k_total', float('nan')))
                            if np.isfinite(sk) and np.isfinite(ck):
                                checks.append(abs(sk - ck) <= 1e-08)
                        except Exception:
                            pass
                        if checks and all(checks):
                            exact.append(p)
                    if len(exact) == 1:
                        selected = exact[0]
                        break
            if selected is None:
                unmatched_saved += 1
                if had_ambiguous:
                    ambiguous_saved += 1
                continue
            used.add(selected)
            matched.append(selected)
        n_saved = len(split_df)
        log.debug('v4.41 STRICT-SPLIT-LOAD: matched exactly %d/%d saved rows; unmatched=%d ambiguous_unresolved=%d current_valid=%d', len(matched), n_saved, unmatched_saved, ambiguous_saved, len(current_rows))
        if len(matched) < max(5, int(0.95 * n_saved)):
            log.warning('v4.41 STRICT-SPLIT-LOAD rejected split: only %d/%d rows matched. Delete %s and run normal tier3_finetune once.', len(matched), n_saved, path)
            return None
        if len(set(matched)) != len(matched):
            raise RuntimeError('v4.41 strict split produced duplicate positions')
        return np.asarray(matched, dtype=int)
    except Exception as exc:
        log.warning('v4.41 STRICT-SPLIT-LOAD failed for %s: %s', path, exc)
        return None

def _tier3_split_fingerprint(path: Path) -> str:
    """Stable SHA256 fingerprint for a persistent split CSV."""
    if not path.exists():
        return 'MISSING'
    return hashlib.sha256(path.read_bytes()).hexdigest()

def _split_positions_stratified(df_for_positions: pd.DataFrame, positions: np.ndarray, target_col: str, train_frac: float, val_frac: float, seed: int=42) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Stratified split for a subset of dataset positions; random fallback."""
    from sklearn.model_selection import StratifiedShuffleSplit
    positions = np.asarray(positions, dtype=int)
    if len(positions) == 0:
        return (positions, positions, positions)
    rng = np.random.default_rng(seed)
    y = pd.to_numeric(df_for_positions.iloc[positions][target_col], errors='coerce').to_numpy(dtype=float)
    valid = ~np.isnan(y)
    if valid.sum() < 20:
        perm = rng.permutation(positions)
        n_train = int(len(perm) * train_frac)
        n_val = int(len(perm) * val_frac)
        return (perm[:n_train], perm[n_train:n_train + n_val], perm[n_train + n_val:])
    try:
        n_bins = min(6, int(valid.sum()) // 10)
        if n_bins < 2:
            raise ValueError('too few bins')
        edges = np.unique(np.percentile(y[valid], np.linspace(0, 100, n_bins + 1)))
        if len(edges) < 3:
            raise ValueError('not enough unique target edges')
        bins = np.digitize(y, edges[1:-1]).astype(int)
        if (~valid).any():
            bins[~valid] = int(np.median(bins[valid]))
        _, counts = np.unique(bins, return_counts=True)
        if (counts < 2).any():
            raise ValueError('some bins have <2 rows')
        idx_all = np.arange(len(positions))
        sss = StratifiedShuffleSplit(n_splits=1, test_size=1 - train_frac, random_state=seed)
        train_local, temp_local = next(sss.split(idx_all, bins))
        if val_frac <= 1e-09:
            return (positions[train_local], np.asarray([], dtype=int), positions[temp_local])
        test_ratio = (1 - train_frac - val_frac) / max(1 - train_frac, 1e-09)
        if test_ratio < 1e-09:
            return (positions[train_local], positions[temp_local], np.asarray([], dtype=int))
        temp_bins = bins[temp_local]
        n_test = max(1, int(len(temp_local) * test_ratio))
        if n_test < len(np.unique(temp_bins)):
            raise ValueError('too few test slots for stratified temp split')
        sss2 = StratifiedShuffleSplit(n_splits=1, test_size=test_ratio, random_state=seed)
        val_local2, test_local2 = next(sss2.split(np.arange(len(temp_local)), temp_bins))
        return (positions[train_local], positions[temp_local[val_local2]], positions[temp_local[test_local2]])
    except Exception as exc:
        log.warning('HfO2-family eval stratification failed: %s. Using deterministic random split.', exc)
        perm = rng.permutation(positions)
        n_train = int(len(perm) * train_frac)
        n_val = int(len(perm) * val_frac)
        return (perm[:n_train], perm[n_train:n_train + n_val], perm[n_train + n_val:])

def build_tier3_hfo2_eval_dataloader(df: pd.DataFrame, target_col: str, aux_cols: List[str], train_frac: float, val_frac: float, batch_size: int, num_workers: int=4, use_saved_test_split: bool=False, save_test_split: bool=False, overwrite_saved_split: bool=True, split_path: Path=TIER3_TEST_SPLIT_PATH, use_saved_val_split: bool=False, val_split_path: Path=TIER3_VAL_SPLIT_PATH, test_only: bool=False) -> Tuple[DataLoader, DataLoader, DataLoader, BalancedDistributedSampler, HighKGraphDataset]:
    """Train on the full k-valid Tier-3 set, validate/test only on HfO2 family."""
    dataset = HighKGraphDataset(df, target_col=target_col, aux_cols=aux_cols)
    if len(dataset) == 0:
        raise ValueError('No valid Tier-3 rows available for dataloader')
    valid_rows = dataset.df.loc[dataset.valid_idx].reset_index(drop=True)
    all_pos = np.arange(len(dataset), dtype=int)
    eval_mask = valid_rows.apply(is_hfo2_eval_family_row, axis=1).to_numpy(dtype=bool)
    if TIER3_TRAIN_CONFIG.get('eval_verified_only', True):
        if 'data_quality' in valid_rows.columns:
            quality = valid_rows['data_quality'].fillna('verified').astype(str).str.lower().str.strip()
        else:
            quality = pd.Series('verified', index=valid_rows.index)
        verified_mask = quality.eq('verified') | quality.eq('trusted') | quality.eq('manual_verified')
        n_hfo2_all = int(eval_mask.sum())
        eval_mask = eval_mask & verified_mask.to_numpy(dtype=bool)
        log.debug('QUALITY-AWARE-EVAL active: HfO2-family candidates=%d; verified HfO2 eval candidates=%d; train-only nonverified=%d', n_hfo2_all, int(eval_mask.sum()), int((~verified_mask.to_numpy(dtype=bool)).sum()))
    eval_pos = all_pos[eval_mask]
    non_eval_pos = all_pos[~eval_mask]
    if len(eval_pos) < 20:
        log.warning('EVAL-FAMILY-SPLIT requested but only %d HfO2-family valid rows found. Falling back to normal full-dataset split.', len(eval_pos))
        return build_dataloader(df, target_col, aux_cols, train_frac, val_frac, batch_size, num_workers)
    loaded_test_pos = load_tier3_test_positions_from_split(valid_rows, split_path) if use_saved_test_split else None
    if loaded_test_pos is not None and len(loaded_test_pos) > 0:
        test_pos = loaded_test_pos.astype(int)
        _saved_test_n = len(pd.read_csv(split_path))
        if len(test_pos) != _saved_test_n:
            raise RuntimeError(f'BASELINE-SPLIT-LOCK: TEST identity match {len(test_pos)}/{_saved_test_n}; partial TEST restoration is forbidden.')
        test_set = set(test_pos.tolist())
        loaded_val_pos = None
        if use_saved_val_split and val_split_path.exists():
            loaded_val_pos = load_tier3_test_positions_from_split(valid_rows, val_split_path)
            _saved_val_n = len(pd.read_csv(val_split_path))
            if loaded_val_pos is None or len(loaded_val_pos) != _saved_val_n:
                raise RuntimeError(f'BASELINE-SPLIT-LOCK: VAL identity match {(0 if loaded_val_pos is None else len(loaded_val_pos))}/{_saved_val_n}; partial VAL restoration is forbidden.')
        if test_only:
            train_pos = np.asarray([], dtype=int)
            val_pos = np.asarray([], dtype=int)
            eval_train_pos = np.asarray([], dtype=int)
        elif loaded_val_pos is not None and len(loaded_val_pos) > 0:
            val_pos = loaded_val_pos.astype(int)
            val_set = set(val_pos.tolist())
            if test_set & val_set:
                raise RuntimeError(f'BASELINE-SPLIT-LOCK: persistent VAL/TEST overlap={len(test_set & val_set)}')
            train_pos = np.asarray([p for p in all_pos.tolist() if p not in test_set and p not in val_set], dtype=int)
            eval_train_pos = np.asarray([p for p in eval_pos.tolist() if p not in test_set and p not in val_set], dtype=int)
        else:
            train_pos = np.asarray([p for p in all_pos.tolist() if p not in test_set], dtype=int)
            val_pos = np.asarray([], dtype=int)
            eval_train_pos = np.asarray([p for p in eval_pos.tolist() if p not in test_set], dtype=int)
        log.debug('BASELINE-SPLIT-LOCK: restored TEST=%d VAL=%d TRAIN=%d test_only=%s', len(test_pos), len(val_pos), len(train_pos), bool(test_only))
    else:
        eval_train_pos, val_pos, test_pos = _split_positions_stratified(valid_rows, eval_pos, target_col, train_frac, val_frac, seed=42)
        if save_test_split:
            save_tier3_test_split_rows(dataset, valid_rows, test_pos, split_path, split_name='test', overwrite=overwrite_saved_split)
        if len(val_pos) == 0 and len(test_pos) > 0 and TIER3_TRAIN_CONFIG.get('tier3_disjoint_val', False):
            log.debug('BASELINE-SPLIT: initial VAL empty; awaiting disjoint VAL creation/restoration.')
        elif len(val_pos) == 0 and len(test_pos) > 0:
            raise RuntimeError('Unsafe empty VAL in non-disjoint mode. VAL==TEST fallback has been removed.')
        train_pos = np.concatenate([non_eval_pos, eval_train_pos]).astype(int)
    rng = np.random.default_rng(42)
    train_pos = rng.permutation(train_pos)
    log.debug('─' * 68)
    log.debug('EVAL-FAMILY-SPLIT active: TRAIN=full expanded DB; VAL/TEST=HfO2-family only')
    log.debug('  valid rows total=%d | verified-HfO2-family=%d | train-only-other/weak=%d', len(dataset), len(eval_pos), len(non_eval_pos))
    if 'data_quality' in valid_rows.columns:
        log.debug('  data_quality in k-valid rows: %s', valid_rows['data_quality'].fillna('verified').astype(str).value_counts().to_dict())
    log.debug('  split positions: train=%d (including HfO2-train=%d + wider=%d)  val=%d  test=%d', len(train_pos), len(eval_train_pos), len(non_eval_pos), len(val_pos), len(test_pos))
    for name, pos in [('TRAIN', train_pos), ('VAL-HfO2', val_pos), ('TEST-HfO2', test_pos)]:
        vals = pd.to_numeric(valid_rows.iloc[pos][target_col], errors='coerce')
        src_exp = int((valid_rows.iloc[pos].get('source', pd.Series(index=valid_rows.iloc[pos].index)) == 'Experimental').sum()) if len(pos) else 0
        log.debug('  %-10s N=%-4d experimental=%-4d %s range=[%.3f, %.3f] mean=%.3f', name, len(pos), src_exp, target_col, float(vals.min()) if len(vals) else float('nan'), float(vals.max()) if len(vals) else float('nan'), float(vals.mean()) if len(vals) else float('nan'))
    log.debug('─' * 68)
    collate = HighKGraphDataset.collate_fn
    train_ds = Subset(dataset, train_pos.tolist())
    val_ds = Subset(dataset, val_pos.tolist())
    test_ds = Subset(dataset, test_pos.tolist())
    if _DIST['active']:
        try:
            proc_avail = [int(dataset.df.loc[dataset.valid_idx[i], 'source'] == 'Experimental') for i in train_pos.tolist()]
        except Exception:
            proc_avail = [0] * len(train_pos)
        train_sampler = BalancedDistributedSampler(train_ds, proc_avail=proc_avail, num_replicas=_DIST['world'], rank=_DIST['rank'], shuffle=True)
        shuffle_flag = False
    else:
        train_sampler = None
        shuffle_flag = True
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=shuffle_flag, sampler=train_sampler, num_workers=num_workers, collate_fn=collate, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, collate_fn=collate)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, collate_fn=collate)
    return (train_loader, val_loader, test_loader, train_sampler, dataset)

def build_dataloader(df: pd.DataFrame, target_col: str, aux_cols: List[str], train_frac: float, val_frac: float, batch_size: int, num_workers: int=4) -> Tuple[DataLoader, DataLoader, DataLoader, BalancedDistributedSampler, HighKGraphDataset]:
    """Build train/val/test DataLoaders with stratified splitting."""
    dataset = HighKGraphDataset(df, target_col=target_col, aux_cols=aux_cols)
    train_ds, val_ds, test_ds = get_stratified_split(dataset, train_frac=train_frac, val_frac=val_frac)
    collate = HighKGraphDataset.collate_fn
    if _DIST['active']:
        train_indices = list(range(len(train_ds)))
        try:
            proc_avail = [int(dataset.df.loc[dataset.valid_idx[i], 'source'] == 'Experimental') for i in train_indices]
        except Exception:
            proc_avail = [0] * len(train_indices)
        train_sampler = BalancedDistributedSampler(train_ds, proc_avail=proc_avail, num_replicas=_DIST['world'], rank=_DIST['rank'], shuffle=True)
        shuffle_flag = False
    else:
        train_sampler = None
        shuffle_flag = True
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=shuffle_flag, sampler=train_sampler, num_workers=num_workers, collate_fn=collate, drop_last=True)
    val_loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, collate_fn=collate)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, collate_fn=collate)
    return (train_loader, val_loader, test_loader, train_sampler, dataset)
