from __future__ import annotations
from .artifacts import require_single_process
from .splits import BalancedDistributedSampler, _split_positions_stratified, _tier3_split_fingerprint, build_dataloader, build_tier3_hfo2_eval_dataloader, is_hfo2_eval_family_row, save_tier3_test_split_rows
from .common import DataLoader, HIGH_K_DONOR_ELEMENTS, SPLIT_ROOT, Subset, TIER1_TRAIN_CONFIG, TIER2_TRAIN_CONFIG, TIER3_TEST_SPLIT_PATH, TIER3_TRAIN_CONFIG, TIER3_VAL_SPLIT_PATH, _DIST, json, log, np, pd, torch
from .graph_data import HighKGraphDataset
from .imputation import _impute_structures
from .distributed import dist_barrier, is_rank0

def prepare_tier1_state(df_tier1=None, df_tier2=None, df_tier3=None):
    """Tier 1 -- Foundation pretraining on full JARVIS-DFT + MP + QM9."""
    require_single_process()
    log.debug('=' * 70)
    log.debug(' TIER 1 -- Foundation Pretrain')
    log.debug(' Rows: %d   Target: formation_energy_per_atom', len(df_tier1))
    log.debug('=' * 70)
    cfg = TIER1_TRAIN_CONFIG
    for log_col, src_col in cfg.get('log_transform_aux', {}).items():
        if src_col in df_tier1.columns:
            df_tier1 = df_tier1.copy()
            src_numeric = pd.to_numeric(df_tier1[src_col], errors='coerce')
            mask = src_numeric.notna()
            df_tier1[log_col] = np.nan
            df_tier1.loc[mask, log_col] = np.log(src_numeric[mask].clip(lower=0.1))
            n_transformed = int(mask.sum())
            log.debug('Tier 1 aux log transform: %s → %s  (%d non-null rows, range=[%.3f, %.3f])', src_col, log_col, n_transformed, df_tier1[log_col].dropna().min(), df_tier1[log_col].dropna().max())
    task_names = [cfg['target']] + cfg['aux_targets']
    log.debug('Tier 1 training with targets: %s', task_names)
    train_loader, val_loader, test_loader, train_sampler, _main_ds_t1 = build_dataloader(df=df_tier1, target_col=cfg['target'], aux_cols=cfg['aux_targets'], train_frac=cfg['train_ratio'], val_frac=cfg['val_ratio'], batch_size=cfg['batch_size'])
    return {'_main_ds_t1': _main_ds_t1, 'cfg': cfg, 'task_names': task_names, 'test_loader': test_loader, 'train_loader': train_loader, 'train_sampler': train_sampler, 'val_loader': val_loader, 'df_tier1': df_tier1}

def prepare_tier2_state(df_tier1=None, df_tier2=None, df_tier3=None):
    """Tier 2 -- Domain fine-tuning on oxide dielectrics (k > 10)."""
    require_single_process()
    log.debug('=' * 70)
    log.debug(' TIER 2 -- Domain Fine-tune (Oxide Dielectrics)')
    log.debug(' Rows: %d   Target: k_total', len(df_tier2))
    log.debug('=' * 70)
    cfg = TIER2_TRAIN_CONFIG
    df_t2_k = df_tier2[df_tier2['k_total'].notna()].copy()
    log.debug('Tier 2 rows with k_total: %d', len(df_t2_k))
    if cfg.get('log_transform', False):
        orig_col = cfg['log_original_col']
        log_col = cfg['target']
        k_numeric = pd.to_numeric(df_t2_k[orig_col], errors='coerce')
        df_t2_k[log_col] = np.log(k_numeric.clip(lower=0.1))
        log.debug('Log transform: %s → %s  range=[%.3f, %.3f]  (original k range=[%.1f, %.1f])', orig_col, log_col, df_t2_k[log_col].min(), df_t2_k[log_col].max(), k_numeric.min(), k_numeric.max())
    target_col = cfg['target']
    train_loader, val_loader, test_loader, train_sampler, _main_ds_t2 = build_dataloader(df=df_t2_k, target_col=target_col, aux_cols=cfg['aux_targets'], train_frac=cfg['train_ratio'], val_frac=cfg['val_ratio'], batch_size=cfg['batch_size'])
    task_names = [target_col] + cfg['aux_targets']
    log.debug('Tier 2 training with task heads: %s', task_names)
    phase_a_target = cfg.get('phase_a_target', 'band_gap')
    pa_loader, _, _, pa_sampler, _ds = build_dataloader(df_tier2, phase_a_target, [c for c in cfg['aux_targets'] if c != phase_a_target], 0.95, 0.05, cfg['batch_size'])
    return {'_main_ds_t2': _main_ds_t2, 'cfg': cfg, 'df_t2_k': df_t2_k, 'target_col': target_col, 'task_names': task_names, 'test_loader': test_loader, 'train_loader': train_loader, 'train_sampler': train_sampler, 'val_loader': val_loader, 'df_tier2': df_tier2, 'pa_loader': pa_loader}

def prepare_tier3_state(df_tier1=None, df_tier2=None, df_tier3=None):
    """Tier 3 -- Project fine-tuning on HfO2-family (with process parameters)."""
    require_single_process()
    log.debug('=' * 70)
    log.debug(' TIER 3 -- Project Fine-tune (HfO2 Family)')
    log.debug(' Rows: %d   Target: k_measured', len(df_tier3))
    log.debug('=' * 70)
    cfg = TIER3_TRAIN_CONFIG
    df_structural = df_tier3[df_tier3['atoms_dict'].notna()].copy()
    df_process_only = df_tier3[df_tier3['atoms_dict'].isna()].copy()
    log.debug('  Structural rows (ALIGNN path): %d  |  Process-only rows (unused in v3): %d', len(df_structural), len(df_process_only))
    if df_tier2 is not None:
        df_donor_pool_wide = df_tier2[df_tier2['formula'].apply(lambda f: isinstance(f, str) and 'O' in f and any((el in f for el in HIGH_K_DONOR_ELEMENTS)))].copy()
    else:
        df_donor_pool_wide = df_structural
    df_imputed, df_unmatched = _impute_structures(df_process_only, df_donor_pool_wide)
    if len(df_imputed) > 0:
        df_structural = pd.concat([df_structural, df_imputed], ignore_index=True, sort=False)
        log.debug('After imputation: df_structural=%d  (DFT-only=%d  imputed-experimental=%d  unmatched=%d)', len(df_structural), len(df_structural) - len(df_imputed), len(df_imputed), len(df_unmatched))
    else:
        log.warning("FIX-T3-7: No experimental rows could be imputed (donor pool empty or no formula matches).  Check that df_structural contains HfO2-family JARVIS entries and that process_db.csv 'material' column uses standard formulas (e.g. HfO2, Al2O3, ZrO2).")
    if len(df_unmatched) > 0:
        log.warning('Tier 3: %d process-only rows remain EXCLUDED — no matching crystal structure donor found.  See FIX-T3-7 warning above for unmatched formulas.', len(df_unmatched))
    if cfg.get('log_transform', False):
        src_col = cfg['log_original_col']
        log_col = cfg['target']
        k_num = pd.to_numeric(df_structural[src_col], errors='coerce')
        valid_k = k_num.notna()
        df_structural[log_col] = np.nan
        df_structural.loc[valid_k, log_col] = np.log(k_num[valid_k].clip(lower=0.1))
        log.debug('FIX-T3-9A log transform: %s → %s  (%d valid rows  range [%.3f, %.3f] log units = k [%.1f, %.1f])', src_col, log_col, int(valid_k.sum()), df_structural[log_col].dropna().min(), df_structural[log_col].dropna().max(), float(k_num[valid_k].min()), float(k_num[valid_k].max()))
    log.debug('─' * 65)
    log.debug('Tier 3 target coverage in df_structural (%d rows):', len(df_structural))
    _diag_targets = [cfg['target'], 'k_measured', 'band_gap', 'J_g_A_cm2', 'E_BD_MV_cm']
    for _tgt in _diag_targets:
        if _tgt not in df_structural.columns:
            if _tgt != 'k_measured':
                log.warning('  %-22s  column ABSENT — check target_renames in load_experimental_process_db', _tgt)
            continue
        _total = int(df_structural[_tgt].notna().sum())
        if 'source' in df_structural.columns:
            _dft = int(df_structural[df_structural['source'] != 'Experimental'][_tgt].notna().sum())
            _exp = int(df_structural[df_structural['source'] == 'Experimental'][_tgt].notna().sum())
            log.debug('  %-22s  total=%-5d  (DFT=%-5d  experimental=%-5d)  coverage=%.1f%%', _tgt + ':', _total, _dft, _exp, 100.0 * _total / max(len(df_structural), 1))
        else:
            log.debug('  %-22s  total=%d  coverage=%.1f%%', _tgt + ':', _total, 100.0 * _total / max(len(df_structural), 1))
    log.debug('─' * 65)
    _kmeas_col = cfg['target']
    valid_k_count = int(df_structural[_kmeas_col].notna().sum()) if _kmeas_col in df_structural.columns else 0
    if valid_k_count < 50:
        log.warning("FIX-T3-10B STALE CACHE DETECTED: only %d valid '%s' rows (expected ≥ 100 after FIX-T3-8 column renames).  FIX-T3-8 (dielectric_constant_k → k_measured) runs inside build_tier3() which requires --rebuild_tier3 to execute.  Without rebuild: train≈23 rows → catastrophic overfitting → band_gap and aux heads will degrade severely.  Re-run with --rebuild_tier3 before continuing.", valid_k_count, _kmeas_col)
    cfg_min_epochs = cfg.get('min_epochs', 40)
    if valid_k_count < 100:
        safe_min = max(20, valid_k_count // 2)
        if safe_min < cfg_min_epochs:
            n_train_est = max(1, int(valid_k_count * cfg['train_ratio']))
            n_batches_est = max(1, n_train_est // cfg.get('batch_size', 8))
            log.warning('FIX-T3-10C ADAPTIVE min_epochs: %d → %d  (valid_k=%d  train≈%d  batches/ep≈%d  full min=%d would force %d steps on %d examples → overfit).  Run --rebuild_tier3 to unlock min_epochs=%d.', cfg_min_epochs, safe_min, valid_k_count, n_train_est, n_batches_est, cfg_min_epochs, cfg_min_epochs * n_batches_est, n_train_est, cfg_min_epochs)
            cfg = {**cfg, 'min_epochs': safe_min}
    log.debug('FIX-T3-10 summary: valid_%s=%d  min_epochs=%d  patience=%d  worst-case-stop=ep%d', _kmeas_col, valid_k_count, cfg.get('min_epochs', 40), cfg.get('patience', 40), cfg.get('min_epochs', 40) + cfg.get('patience', 40))
    df_phase_b = df_structural[df_structural[cfg['target']].notna()].copy().reset_index(drop=True)
    _n_phase_b = len(df_phase_b)
    _n_phase_b_train = int(_n_phase_b * cfg['train_ratio'])
    log.debug('Phase B dataloader built on k-valid subset  rows=%d  train≈%d  val≈%d  test≈%d  k-density=%.1f%%)', _n_phase_b, _n_phase_b_train, int(_n_phase_b * cfg['val_ratio']), _n_phase_b - _n_phase_b_train - int(_n_phase_b * cfg['val_ratio']), 100.0 * _n_phase_b / max(len(df_structural), 1))
    _tier3_loader_fn = build_tier3_hfo2_eval_dataloader if cfg.get('eval_hfo2_family_only', False) else build_dataloader
    if cfg.get('eval_hfo2_family_only', False):
        train_loader, val_loader, test_loader, train_sampler, _main_ds_t3 = _tier3_loader_fn(df=df_phase_b, target_col=cfg['target'], aux_cols=cfg['aux_targets'], train_frac=cfg['train_ratio'], val_frac=cfg['val_ratio'], batch_size=cfg['batch_size'], use_saved_test_split=bool(TIER3_TEST_SPLIT_PATH.exists()), save_test_split=bool(not TIER3_TEST_SPLIT_PATH.exists()), overwrite_saved_split=False)
    else:
        train_loader, val_loader, test_loader, train_sampler, _main_ds_t3 = _tier3_loader_fn(df=df_phase_b, target_col=cfg['target'], aux_cols=cfg['aux_targets'], train_frac=cfg['train_ratio'], val_frac=cfg['val_ratio'], batch_size=cfg['batch_size'])
    if cfg.get('eval_hfo2_family_only', False) and TIER3_TEST_SPLIT_PATH.exists():
        train_loader, val_loader, test_loader, train_sampler, _main_ds_t3 = build_tier3_hfo2_eval_dataloader(df=df_phase_b, target_col=cfg['target'], aux_cols=cfg['aux_targets'], train_frac=cfg['train_ratio'], val_frac=cfg['val_ratio'], batch_size=cfg['batch_size'], num_workers=0, use_saved_test_split=True, save_test_split=False, overwrite_saved_split=False, use_saved_val_split=bool(TIER3_VAL_SPLIT_PATH.exists()))
        from collections import Counter

        def _audit_schema_key(item):
            if item is None:
                return None

            def _one(g):
                try:
                    nf = g.ndata.get('atom_features')
                    return (tuple(sorted(g.ndata.keys())), tuple(sorted(g.edata.keys())), int(nf.shape[-1]) if nf is not None else 0)
                except Exception:
                    return None
            return (_one(item['graph']), _one(item['line_graph']))
        _raw_test_pos = list(getattr(test_loader.dataset, 'indices', []))
        _schema_by_pos = {}
        _graph_failed_test_pos = []
        for _p in _raw_test_pos:
            try:
                _item = _main_ds_t3[int(_p)]
            except BaseException:
                _item = None
            _key = _audit_schema_key(_item)
            if _key is None or _key[0] is None or _key[1] is None:
                _graph_failed_test_pos.append(int(_p))
            else:
                _schema_by_pos[int(_p)] = _key
        if not _schema_by_pos:
            raise RuntimeError('v4.43: no graph/schema-evaluable rows remain in canonical Tier3 TEST split')
        _schema_counts = Counter(_schema_by_pos.values())
        _canonical_schema, _canonical_schema_n = _schema_counts.most_common(1)[0]
        _graph_ok_test_pos = [p for p in _raw_test_pos if _schema_by_pos.get(int(p)) == _canonical_schema]
        _schema_mismatch_pos = [p for p in _raw_test_pos if int(p) in _schema_by_pos and _schema_by_pos[int(p)] != _canonical_schema]
        log.debug('v4.43 SCHEMA-CANONICAL-SPLIT: raw=%d graph_failed=%d schema_mismatch=%d canonical=%d schema_groups=%s', len(_raw_test_pos), len(_graph_failed_test_pos), len(_schema_mismatch_pos), len(_graph_ok_test_pos), sorted(_schema_counts.values(), reverse=True))
        if _graph_failed_test_pos:
            log.debug('v4.43 graph-failed subset positions: %s', _graph_failed_test_pos)
        if _schema_mismatch_pos:
            log.debug('v4.43 schema-mismatch subset positions: %s', _schema_mismatch_pos)
        _canonical_subset = Subset(_main_ds_t3, _graph_ok_test_pos)
        _eval_loader_kwargs = dict(batch_size=cfg['batch_size'], shuffle=False, num_workers=0, collate_fn=HighKGraphDataset.collate_fn, pin_memory=torch.cuda.is_available())
        test_loader = DataLoader(_canonical_subset, **_eval_loader_kwargs)
        _saved_test_count = len(pd.read_csv(TIER3_TEST_SPLIT_PATH))
        if len(_raw_test_pos) != _saved_test_count:
            raise RuntimeError(f'BASELINE-SPLIT-LOCK: persistent TEST identity resolution failed (saved={_saved_test_count}, restored={len(_raw_test_pos)}). Some saved TEST rows are missing from the current dataset; refusing to proceed.')
        if len(_graph_ok_test_pos) != len(_raw_test_pos):
            _n_dropped = len(_raw_test_pos) - len(_graph_ok_test_pos)
            if not cfg.get('tier3_allow_split_creation', True):
                raise RuntimeError(f'BASELINE-SPLIT-LOCK: persistent TEST needs healing (saved={_saved_test_count}, canonical={len(_graph_ok_test_pos)}, drop={_n_dropped}) but tier3_allow_split_creation=False. Re-enable split creation for one baseline run to heal, then freeze again.')
            log.warning('BASELINE-SPLIT-LOCK: healing persistent TEST identity: saved=%d restored=%d canonical=%d (dropping %d non-graph/schema-evaluable rows). Re-persisting the canonical subset as the locked TEST identity.', _saved_test_count, len(_raw_test_pos), len(_graph_ok_test_pos), _n_dropped)
            if is_rank0():
                _valid_rows_for_split = _main_ds_t3.df.loc[_main_ds_t3.valid_idx].reset_index(drop=True)
                save_tier3_test_split_rows(_main_ds_t3, _valid_rows_for_split, np.asarray(_graph_ok_test_pos, dtype=int), path=TIER3_TEST_SPLIT_PATH, split_name='test', overwrite=True)
            dist_barrier()
            _healed_count = len(pd.read_csv(TIER3_TEST_SPLIT_PATH))
            if _healed_count != len(_graph_ok_test_pos):
                raise RuntimeError(f'BASELINE-SPLIT-LOCK: TEST heal verification failed (re-saved={_healed_count}, canonical={len(_graph_ok_test_pos)}).')
            log.debug('BASELINE-SPLIT-LOCK: TEST identity healed and locked at N=%d (was %d saved); these are the same rows evaluated by prior versions.', len(_graph_ok_test_pos), _saved_test_count)
        dist_barrier()
        _canonical_test_n = len(_graph_ok_test_pos)
        _canonical_val_n = len(getattr(val_loader.dataset, 'indices', []))
        log.debug('BASELINE TEST-CANONICAL: train=%d preloaded_val=%d test=%d; TEST identities unchanged', len(getattr(train_loader.dataset, 'indices', [])), _canonical_val_n, _canonical_test_n)
    else:
        _canonical_test_n = len(getattr(test_loader.dataset, 'indices', []))
        _canonical_val_n = _canonical_test_n
    _tier3_disjoint_val_active = False
    if cfg.get('tier3_disjoint_val', False) and cfg.get('eval_hfo2_family_only', False):
        from collections import Counter as _CounterDV
        _dv_seed = int(cfg.get('tier3_disjoint_val_seed', 42))
        _dv_ratio = float(cfg.get('tier3_disjoint_val_ratio', 0.2))
        _dv_min_pool = int(cfg.get('tier3_disjoint_val_min_pool', 6))
        _train_pos_all = [int(p) for p in getattr(train_loader.dataset, 'indices', [])]
        _test_pos_set = set((int(p) for p in getattr(test_loader.dataset, 'indices', [])))
        _valid_rows_dv = _main_ds_t3.df.loc[_main_ds_t3.valid_idx].reset_index(drop=True)

        def _is_val_candidate_dv(pos: int) -> bool:
            if pos in _test_pos_set or pos < 0 or pos >= len(_valid_rows_dv):
                return False
            r = _valid_rows_dv.iloc[pos]
            if not is_hfo2_eval_family_row(r):
                return False
            if not cfg.get('eval_verified_only', True):
                return True
            q = str(r.get('data_quality', 'verified')).lower().strip()
            return q in ('verified', 'trusted', 'manual_verified')
        _existing_val_pos = [int(p) for p in getattr(val_loader.dataset, 'indices', [])]
        _min_val_rows = int(cfg.get('tier3_disjoint_val_min_rows', 15))
        _persistent_val_loaded = bool(TIER3_VAL_SPLIT_PATH.exists() and _existing_val_pos)
        if _persistent_val_loaded:
            _val_set_dv = set(_existing_val_pos)
            _train_set_dv = set(_train_pos_all)
            if _val_set_dv & _test_pos_set or _val_set_dv & _train_set_dv:
                raise RuntimeError(f'BASELINE-SPLIT-LOCK leakage: val∩test={len(_val_set_dv & _test_pos_set)} val∩train={len(_val_set_dv & _train_set_dv)}')
            if len(_existing_val_pos) < _min_val_rows:
                raise RuntimeError(f'BASELINE-SPLIT-LOCK: persistent VAL has {len(_existing_val_pos)} rows; minimum required is {_min_val_rows}.')
            _canonical_val_n = len(_existing_val_pos)
            _tier3_disjoint_val_active = True
            log.debug('BASELINE-SPLIT-LOCK: reused persistent identity splits TRAIN=%d VAL=%d TEST=%d', len(_train_pos_all), _canonical_val_n, len(_test_pos_set))
        _val_candidate_pos = [p for p in _train_pos_all if _is_val_candidate_dv(p)]
        if not _persistent_val_loaded and len(_val_candidate_pos) < _dv_min_pool:
            raise RuntimeError(f'DISJOINT-VAL ABORT: tier3_disjoint_val=True but only {len(_val_candidate_pos)} eval-family verified TRAIN rows are available (need >= {_dv_min_pool}). Refusing to silently fall back to VAL==TEST, which would reintroduce selecting on the test set. Fix the data pool, lower tier3_disjoint_val_min_pool deliberately, or set tier3_disjoint_val=False to run legacy mode on purpose.')
        if not _persistent_val_loaded:
            if TIER3_VAL_SPLIT_PATH.exists() and cfg.get('tier3_lock_persistent_splits', True):
                raise RuntimeError('BASELINE-SPLIT-LOCK: VAL file exists but was not restored exactly.')
            if not cfg.get('tier3_allow_split_creation', True):
                raise RuntimeError('BASELINE-SPLIT-LOCK: split creation disabled and no valid VAL split exists.')
            _cand_arr = np.asarray(_val_candidate_pos, dtype=int)
            _keep_local, _val_local, _unused_local = _split_positions_stratified(_valid_rows_dv, _cand_arr, cfg['target'], train_frac=1.0 - _dv_ratio, val_frac=_dv_ratio, seed=_dv_seed)
            _val_pos_raw = np.asarray(_val_local, dtype=int)
            if _val_pos_raw.size == 0:
                log.warning("DISJOINT-VAL: stratified VAL hold-out degenerated (empty). Falling back to a DETERMINISTIC RANDOM disjoint hold-out (seed=%d). VAL is still disjoint from TRAIN/TEST, but is not stratified across the k range — treat this run's val-selection as lower-confidence.", _dv_seed)
                _rng_dv = np.random.default_rng(_dv_seed)
                _perm_dv = _rng_dv.permutation(_cand_arr)
                _n_val_dv = max(1, int(round(_dv_ratio * len(_perm_dv))))
                _val_pos_raw = _perm_dv[:_n_val_dv]

            def _schema_key_dv(item):
                if item is None:
                    return None

                def _one(g):
                    try:
                        nf = g.ndata.get('atom_features')
                        return (tuple(sorted(g.ndata.keys())), tuple(sorted(g.edata.keys())), int(nf.shape[-1]) if nf is not None else 0)
                    except Exception:
                        return None
                return (_one(item['graph']), _one(item['line_graph']))
            _schema_by_pos_dv = {}
            for _p in _val_pos_raw.tolist():
                try:
                    _it_dv = _main_ds_t3[int(_p)]
                except BaseException:
                    _it_dv = None
                _k_dv = _schema_key_dv(_it_dv)
                if _k_dv is not None and _k_dv[0] is not None and (_k_dv[1] is not None):
                    _schema_by_pos_dv[int(_p)] = _k_dv
            if _schema_by_pos_dv:
                _canon_schema_dv, _ = _CounterDV(_schema_by_pos_dv.values()).most_common(1)[0]
                _val_pos = [p for p in _val_pos_raw.tolist() if _schema_by_pos_dv.get(int(p)) == _canon_schema_dv]
            else:
                _val_pos = _val_pos_raw.tolist()
            _val_set_dv = set((int(p) for p in _val_pos))
            _new_train_pos = [p for p in _train_pos_all if int(p) not in _val_set_dv]
            _collate_dv = HighKGraphDataset.collate_fn
            _train_ds_dv = Subset(_main_ds_t3, _new_train_pos)
            _val_ds_dv = Subset(_main_ds_t3, list(_val_pos))
            if _DIST['active']:
                try:
                    _proc_avail_dv = [int(_main_ds_t3.df.loc[_main_ds_t3.valid_idx[i], 'source'] == 'Experimental') for i in _new_train_pos]
                except Exception:
                    _proc_avail_dv = [0] * len(_new_train_pos)
                train_sampler = BalancedDistributedSampler(_train_ds_dv, proc_avail=_proc_avail_dv, num_replicas=_DIST['world'], rank=_DIST['rank'], shuffle=True)
                _shuffle_dv = False
            else:
                train_sampler = None
                _shuffle_dv = True
            train_loader = DataLoader(_train_ds_dv, batch_size=cfg['batch_size'], shuffle=_shuffle_dv, sampler=train_sampler, num_workers=0, collate_fn=_collate_dv, drop_last=True)
            val_loader = DataLoader(_val_ds_dv, batch_size=cfg['batch_size'], shuffle=False, num_workers=0, collate_fn=_collate_dv)
            _canonical_val_n = len(_val_pos)
            if _canonical_val_n < _min_val_rows:
                raise RuntimeError(f'BASELINE-SPLIT-LOCK: newly carved VAL has {_canonical_val_n} graph-evaluable rows; minimum required is {_min_val_rows}. Increase the candidate pool or ratio.')
            if is_rank0():
                save_tier3_test_split_rows(_main_ds_t3, _valid_rows_dv, np.asarray(_val_pos, dtype=int), path=TIER3_VAL_SPLIT_PATH, split_name='val', overwrite=True)
            dist_barrier()
            _leak_vt = _val_set_dv & _test_pos_set
            _leak_vtr = _val_set_dv & set(_new_train_pos)
            if _leak_vt or _leak_vtr:
                raise RuntimeError(f'DISJOINT-VAL leakage detected: val∩test={len(_leak_vt)} val∩train={len(_leak_vtr)}')
            log.debug('─' * 68)
            log.debug('DISJOINT-VAL active: VAL carved from TRAIN, disjoint from TEST.  train=%d  val=%d  test=%d  (val_frac_of_evalfamily_train=%.2f seed=%d)', len(_new_train_pos), _canonical_val_n, _canonical_test_n, _dv_ratio, _dv_seed)
            log.debug('DISJOINT-VAL leakage check passed: val∩test=0 val∩train=0')
            log.debug('DISJOINT-VAL selection policy: tier3_best.pt chosen on VAL log-MAE; TEST sealed during optimization and reported once after the frozen best checkpoint.')
            log.debug('─' * 68)
            _tier3_disjoint_val_active = True
    if cfg.get('tier3_disjoint_val', False) and cfg.get('eval_hfo2_family_only', False) and (not _tier3_disjoint_val_active):
        raise RuntimeError('DISJOINT-VAL ABORT: tier3_disjoint_val=True was requested but the disjoint VAL carve did not complete (_tier3_disjoint_val_active is False). Refusing to proceed with a possibly VAL==TEST selection.')
    if is_rank0():
        log.debug('BASELINE SPLIT FINGERPRINTS | VAL=%s | TEST=%s', _tier3_split_fingerprint(TIER3_VAL_SPLIT_PATH), _tier3_split_fingerprint(TIER3_TEST_SPLIT_PATH))
        split_manifest = {'version': 'v4.60_locked_disjoint_baseline', 'val_path': str(TIER3_VAL_SPLIT_PATH), 'test_path': str(TIER3_TEST_SPLIT_PATH), 'val_sha256': _tier3_split_fingerprint(TIER3_VAL_SPLIT_PATH), 'test_sha256': _tier3_split_fingerprint(TIER3_TEST_SPLIT_PATH), 'val_n': int(_canonical_val_n), 'test_n': int(_canonical_test_n), 'selection_metric': 'VAL log-MAE only', 'test_policy': 'sealed until final frozen-checkpoint evaluation'}
        (SPLIT_ROOT / 'tier3_locked_split_manifest.json').write_text(json.dumps(split_manifest, indent=2))
    task_names_t3 = [cfg['target'], 'band_gap']
    log.debug('Tier 3 training with task heads: %s', task_names_t3)
    if cfg['phase_a_steps'] > 0 and len(df_structural) > 0:
        df_pa = df_structural[df_structural['band_gap'].notna()].copy()
        pa_loader, _, _, pa_sampler, _ds = build_dataloader(df_pa, 'band_gap', [], 0.95, 0.05, cfg['batch_size'])
    else:
        pa_loader = None
    return {'_canonical_test_n': _canonical_test_n, '_canonical_val_n': _canonical_val_n, '_main_ds_t3': _main_ds_t3, '_n_phase_b': _n_phase_b, '_tier3_disjoint_val_active': _tier3_disjoint_val_active, 'cfg': cfg, 'df_phase_b': df_phase_b, 'df_structural': df_structural, 'task_names_t3': task_names_t3, 'test_loader': test_loader, 'train_loader': train_loader, 'train_sampler': train_sampler, 'val_loader': val_loader, 'pa_loader': pa_loader}
