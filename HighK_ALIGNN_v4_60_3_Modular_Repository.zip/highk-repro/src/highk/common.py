from __future__ import annotations
from .config import ROOT, DATA_ROOT, CKPT_ROOT, LOG_ROOT, REPORT_ROOT, SPLIT_ROOT, TIER3_TEST_SPLIT_PATH, TIER3_VAL_SPLIT_PATH, MP_API_KEY, TIER3_ELEMENTS, HIGH_K_DONOR_ELEMENTS, TIER2_CATIONS, TIER2_K_MIN, ALIGNN_BASE_CONFIG, TIER1_TRAIN_CONFIG, TIER2_TRAIN_CONFIG, TIER3_TRAIN_CONFIG, FUNCTIONAL_CODE, TASK_TO_COLUMN, PAPER_MAD_MAE_BENCHMARK, PROCESS_PARAMS_FEATURES, STACK_CONTEXT_FEATURES
import os
import json
import math
import time
import hashlib
import logging
import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.distributed as dist
from torch.utils.data import DataLoader, Subset
from tqdm import tqdm
from alignn.models.alignn import ALIGNN, ALIGNNConfig
from alignn.graphs import Graph
from jarvis.db.figshare import data as jdata
from jarvis.core.atoms import Atoms as JAtoms
from pymatgen.io.jarvis import JarvisAtomsAdaptor
from mp_api.client import MPRester
_DIST = {'rank': 0, 'world': 1, 'active': False, 'device': 'cpu'}
log = logging.getLogger('highk')
