from __future__ import annotations
from .common import Graph, JAtoms, List, PROCESS_PARAMS_FEATURES, STACK_CONTEXT_FEATURES, TIER3_TRAIN_CONFIG, Tuple, json, log, np, pd, torch

def infer_material_family_from_row(row) -> str:
    """Return a compact material-family label used for donor rules and offsets."""
    fam = str(row.get('material_family', '')).strip().lower()
    if fam and fam not in ('nan', 'none', '', 'unknown'):
        return fam
    s = (str(row.get('material', row.get('material_system', ''))) + ' ' + str(row.get('formula', ''))).lower().replace(' ', '')
    if 'hfo2' in s and (not any((x in s for x in ['zr', 'al', 'la', 'y', 'gd', 'si', 'sr']))):
        return 'pure_hfo2'
    if 'hzo' in s or ('hf' in s and 'zr' in s and ('o' in s)) or 'hf0.' in s:
        return 'hzo_like'
    if 'alhfo' in s or 'hfalo' in s or ('hf' in s and 'al' in s and ('o' in s)):
        return 'doped_hfo2_al'
    if 'lahfo' in s or 'hfl ao' in s or ('hf' in s and 'la' in s and ('o' in s)):
        return 'doped_hfo2_la'
    if 'hf' in s and 'o' in s:
        return 'doped_hfo2_other'
    if 'zro2' in s or ('zr' in s and 'o' in s):
        return 'zro2_like'
    return 'other_highk'

def material_family_log_offset_from_row(row) -> float:
    """Deterministic, conservative log(k) correction by material family."""
    if not TIER3_TRAIN_CONFIG.get('enable_material_family_offset', True):
        return 0.0
    fam = infer_material_family_from_row(row)
    offsets = TIER3_TRAIN_CONFIG.get('material_family_offsets', {})
    return float(offsets.get(fam, 0.0))

class HighKGraphDataset(torch.utils.data.Dataset):
    """
    PyTorch Dataset that wraps the tiered HDF5 stores and builds ALIGNN
    DGL graphs on-the-fly from stored atoms_dict JSON strings.

    Graph construction follows the ALIGNN paper exactly:
    - 12-nearest-neighbor periodic graph for crystals
    - RBF edge features: bond distances expanded over [0, 8 Å]
    - Line graph: nodes are bonds, edges are bond-angle triplets
    - RBF triplet features: bond angle cosines

    For QM9 molecules: same construction with 5 Å cutoff (no periodicity).
    For experimental entries without atoms_dict: returns None (excluded from
    ALIGNN path, used only in the process-parameter MLP branch).
    """
    RBF_CUTOFF_CRYSTAL = 8.0
    RBF_CUTOFF_MOLECULE = 5.0
    N_NEIGHBORS = 12

    def __init__(self, df: pd.DataFrame, target_col: str='k_measured', aux_cols: List[str]=None, cutoff: float=None, use_canonize: bool=True):
        self.df = df.reset_index(drop=True)
        self.target_col = target_col
        self.aux_cols = aux_cols or []
        self.cutoff = cutoff
        self.use_canonize = use_canonize
        _pf = PROCESS_PARAMS_FEATURES
        self._proc_num_cols = list(_pf['numerical'])
        self._proc_log_cols = set(_pf.get('log_normalize', []))
        self._proc_cat_cols = list(_pf['categorical'].keys())
        self._proc_vocabs = {name: {v: i for i, v in enumerate(vocab)} for name, vocab in _pf['categorical'].items()}
        _sf = STACK_CONTEXT_FEATURES
        self._stack_num_cols = list(_sf['numerical'])
        self._stack_cat_cols = list(_sf['categorical'].keys())
        self._stack_vocabs = {name: {v: i for i, v in enumerate(vocab)} for name, vocab in _sf['categorical'].items()}
        _all_ctx_cols = self._proc_num_cols + self._proc_cat_cols + self._stack_num_cols + self._stack_cat_cols
        self._has_context = any((c in self.df.columns for c in _all_ctx_cols))
        self._zero_proc_num = [0.0] * len(self._proc_num_cols)
        self._zero_proc_cat = [len(self._proc_vocabs[c]) for c in self._proc_cat_cols]
        self._zero_stack_num = [0.0] * len(self._stack_num_cols)
        self._zero_stack_cat = [len(self._stack_vocabs[c]) for c in self._stack_cat_cols]
        valid = self.df[target_col].notna() & self.df['atoms_dict'].notna() & self.df['has_structure'].fillna(False)
        self.valid_idx = self.df[valid].index.tolist()
        log.debug("HighKGraphDataset: %d/%d rows have valid target '%s' + structure", len(self.valid_idx), len(self.df), target_col)

    @staticmethod
    def _safe_val(row, col):
        """Return row[col] as float if present and numeric, else None."""
        try:
            v = row[col]
            if v is None:
                return None
            if isinstance(v, float) and np.isnan(v):
                return None
            fv = pd.to_numeric(v, errors='coerce')
            if pd.isna(fv):
                return None
            return fv
        except (KeyError, TypeError):
            return None

    def _extract_proc_feats(self, row) -> Tuple[List[float], List[int], float]:
        """Extract ALD process parameter features from a row."""
        num_vals = []
        any_present = False
        for col in self._proc_num_cols:
            v = self._safe_val(row, col)
            if v is not None:
                fv = float(v)
                if col in self._proc_log_cols:
                    fv = float(np.log1p(max(fv, 0.0)))
                num_vals.append(fv)
                any_present = True
            else:
                num_vals.append(0.0)
        cat_indices = []
        for col in self._proc_cat_cols:
            v = self._safe_val(row, col)
            vmap = self._proc_vocabs[col]
            if v is not None:
                idx = vmap.get(str(v), len(vmap))
                any_present = True
            else:
                idx = len(vmap)
            cat_indices.append(idx)
        return (num_vals, cat_indices, 1.0 if any_present else 0.0)

    def _extract_stack_feats(self, row) -> Tuple[List[float], List[int], float]:
        """Extract device stack context features from a row."""
        num_vals = []
        any_present = False
        for col in self._stack_num_cols:
            v = self._safe_val(row, col)
            if v is not None:
                num_vals.append(float(v))
                any_present = True
            else:
                num_vals.append(0.0)
        cat_indices = []
        for col in self._stack_cat_cols:
            v = self._safe_val(row, col)
            vmap = self._stack_vocabs[col]
            if v is not None:
                idx = vmap.get(str(v), len(vmap))
                any_present = True
            else:
                idx = len(vmap)
            cat_indices.append(idx)
        return (num_vals, cat_indices, 1.0 if any_present else 0.0)

    def __len__(self):
        return len(self.valid_idx)

    def __getitem__(self, idx):
        row_idx = self.valid_idx[idx]
        row = self.df.loc[row_idx]
        try:
            atoms_dict = json.loads(row['atoms_dict'])
            j_atoms = JAtoms.from_dict(atoms_dict)
        except Exception as e:
            log.debug('Atom parse failed for row %d: %s', row_idx, e)
            return None
        is_mol = False if bool(row.get('is_experimental', 0.0)) else bool(row.get('is_molecule', False))
        cutoff = self.cutoff or (self.RBF_CUTOFF_MOLECULE if is_mol else self.RBF_CUTOFF_CRYSTAL)
        try:
            graph, line_graph = Graph.atom_dgl_multigraph(j_atoms, cutoff=cutoff, max_neighbors=self.N_NEIGHBORS, use_canonize=self.use_canonize, use_lattice_prop=not is_mol, compute_line_graph=True)
        except Exception as e:
            log.debug('DGL graph build failed for row %d: %s', row_idx, e)
            return None
        except BaseException as e:
            log.debug('DGLError in graph build for row %d: %s', row_idx, e)
            return None
        try:
            _nf = graph.ndata.get('atom_features')
            if graph.num_nodes() < 2 or graph.num_edges() < 1 or line_graph.num_nodes() < 1 or (_nf is None) or (_nf.shape[-1] != 92):
                log.debug('Row %d: degenerate graph (nodes=%d edges=%d lg_nodes=%d feat_dim=%s) → skip', row_idx, graph.num_nodes(), graph.num_edges(), line_graph.num_nodes(), str(_nf.shape[-1]) if _nf is not None else 'None')
                return None
        except Exception:
            return None
        target = torch.tensor([float(row[self.target_col])], dtype=torch.float32)
        aux_targets = {}
        for col in self.aux_cols:
            val = row.get(col)
            if val is not None and (not (isinstance(val, float) and np.isnan(val))):
                aux_targets[col] = torch.tensor([float(val)], dtype=torch.float32)
            else:
                aux_targets[col] = torch.tensor([float('nan')], dtype=torch.float32)
        if self._has_context:
            p_num, p_cat, p_avail = self._extract_proc_feats(row)
            s_num, s_cat, s_avail = self._extract_stack_feats(row)
        else:
            p_num, p_cat, p_avail = (self._zero_proc_num, self._zero_proc_cat, 0.0)
            s_num, s_cat, s_avail = (self._zero_stack_num, self._zero_stack_cat, 0.0)
        proc_context = {'num': torch.tensor(p_num, dtype=torch.float32), 'cat': torch.tensor(p_cat, dtype=torch.long), 'avail': torch.tensor([p_avail], dtype=torch.float32), 'family_offset': torch.tensor([material_family_log_offset_from_row(row)], dtype=torch.float32)}
        stack_context = {'num': torch.tensor(s_num, dtype=torch.float32), 'cat': torch.tensor(s_cat, dtype=torch.long), 'avail': torch.tensor([s_avail], dtype=torch.float32)}
        _fc_raw = pd.to_numeric(row.get('functional_code', 1), errors='coerce')
        _fc_int = int(_fc_raw) if not pd.isna(_fc_raw) else 1
        return {'graph': graph, 'line_graph': line_graph, 'target': target, 'aux_targets': aux_targets, 'proc_context': proc_context, 'stack_context': stack_context, 'row_idx': row_idx, 'formula': row.get('formula', ''), 'source': row.get('source', ''), 'functional_code': torch.tensor(_fc_int, dtype=torch.long), 'is_experimental': torch.tensor([1.0 if str(row.get('source', '')) == 'Experimental' else 0.0], dtype=torch.float32)}

    @staticmethod
    def collate_fn(batch):
        """FIX2: stacks aux_targets per-task for multi-task evaluation.
        v2.2: also stacks proc_context and stack_context tensors per batch.
        All aux_target values are NaN-tensors (not None) after __getitem__ fix,
        so torch.stack works safely across the whole batch."""
        import dgl
        batch = [b for b in batch if b is not None]
        if not batch:
            return None

        def _graph_schema_key(g):
            """Return a hashable schema signature for a DGL graph."""
            try:
                nf = g.ndata.get('atom_features')
                return (tuple(sorted(g.ndata.keys())), tuple(sorted(g.edata.keys())), nf.shape[-1] if nf is not None else 0)
            except Exception:
                return None
        ref_schema = _graph_schema_key(batch[0]['graph'])
        valid_batch = []
        for item in batch:
            try:
                if _graph_schema_key(item['graph']) == ref_schema and _graph_schema_key(item['line_graph']) is not None:
                    valid_batch.append(item)
                else:
                    log.debug('collate_fn: dropping row %s — graph schema mismatch', item.get('row_idx', '?'))
            except Exception:
                pass
        batch = valid_batch
        if not batch:
            return None
        try:
            graphs = dgl.batch([b['graph'] for b in batch])
            line_graphs = dgl.batch([b['line_graph'] for b in batch])
        except BaseException as e:
            log.warning('collate_fn: dgl.batch() failed (%s) — dropping batch of %d', str(e)[:120], len(batch))
            return None
        targets = torch.stack([b['target'] for b in batch])
        aux_targets = {}
        if batch[0].get('aux_targets'):
            for key in batch[0]['aux_targets'].keys():
                aux_targets[key] = torch.stack([b['aux_targets'][key] for b in batch])
        proc_context = None
        stack_context = None
        if batch[0].get('proc_context') is not None:
            proc_context = {k: torch.stack([b['proc_context'][k] for b in batch]) for k in batch[0]['proc_context'].keys()}
            stack_context = {k: torch.stack([b['stack_context'][k] for b in batch]) for k in batch[0]['stack_context'].keys()}
        functional_codes = None
        if 'functional_code' in batch[0]:
            functional_codes = torch.stack([b['functional_code'] for b in batch])
        is_experimental = None
        if 'is_experimental' in batch[0]:
            is_experimental = torch.stack([b['is_experimental'] for b in batch])
        return {'graph': graphs, 'line_graph': line_graphs, 'target': targets, 'aux_targets': aux_targets, 'proc_context': proc_context, 'stack_context': stack_context, 'formulas': [b['formula'] for b in batch], 'functional_code': functional_codes, 'is_experimental': is_experimental, 'row_indices': torch.tensor([b['row_idx'] for b in batch])}
