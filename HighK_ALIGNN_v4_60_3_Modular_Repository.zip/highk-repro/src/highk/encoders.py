from __future__ import annotations
from .common import PROCESS_PARAMS_FEATURES, STACK_CONTEXT_FEATURES, nn, np, pd, torch

class ProcessParamsEncoder(nn.Module):
    """
    Encodes ALD/deposition process parameters into a fixed 64-dim embedding.

    Numerical features are z-score normalised (log1p first for skewed columns).
    Normalization stats are fitted from training data via fit_stats(); for
    Tier 1/2 checkpoints where no proc data exists, stats stay at mean=0 std=1
    (correct because all inputs are 0.0 in those tiers).

    Categorical features use per-feature nn.Embedding tables (dim=8).
    Absent / unknown values map to index vocab_size (the extra embedding slot).

    Final gate:  emb = mlp(cat(num_norm, cat_embs)) * avail_flag
    When avail_flag = 0 the output is a zero vector -- no contribution to fusion.
    """

    def __init__(self, cfg: dict=None):
        super().__init__()
        cfg = cfg or PROCESS_PARAMS_FEATURES
        self._num_cols = list(cfg['numerical'])
        self._log_cols = set(cfg.get('log_normalize', []))
        self._cat_spec = cfg['categorical']
        self._cat_cols = list(self._cat_spec.keys())
        embed_dim = cfg.get('embed_dim', 8)
        output_dim = cfg.get('output_dim', 64)
        self._vocab_sizes = {name: len(v) for name, v in self._cat_spec.items()}
        self.embeddings = nn.ModuleDict({name: nn.Embedding(len(vocab) + 1, embed_dim) for name, vocab in self._cat_spec.items()})
        n_num = len(self._num_cols)
        n_cat_emb = len(self._cat_cols) * embed_dim
        self.mlp = nn.Sequential(nn.Linear(n_num + n_cat_emb, 128), nn.SiLU(), nn.Dropout(0.1), nn.Linear(128, output_dim), nn.SiLU())
        self.register_buffer('num_mean', torch.zeros(n_num))
        self.register_buffer('num_std', torch.ones(n_num))

    def fit_stats(self, df: pd.DataFrame):
        """Fit z-score normalisation stats from a training dataframe."""
        means, stds = ([], [])
        for col in self._num_cols:
            if col in df.columns:
                vals = pd.to_numeric(df[col], errors='coerce').dropna()
                if col in self._log_cols:
                    vals = np.log1p(vals.clip(lower=0))
                means.append(float(vals.mean()) if len(vals) > 0 else 0.0)
                stds.append(float(vals.std()) if len(vals) > 1 else 1.0)
            else:
                means.append(0.0)
                stds.append(1.0)
        self.num_mean.copy_(torch.tensor(means, dtype=torch.float32))
        self.num_std.copy_(torch.tensor(stds, dtype=torch.float32).clamp(min=1e-06))

    def forward(self, num_feats: torch.Tensor, cat_indices: torch.Tensor, avail_flag: torch.Tensor) -> torch.Tensor:
        num_norm = (num_feats - self.num_mean) / self.num_std
        num_norm = num_norm * avail_flag
        cat_embs = [self.embeddings[name](cat_indices[:, i]) for i, name in enumerate(self._cat_cols)]
        x = torch.cat([num_norm] + cat_embs, dim=-1)
        emb = self.mlp(x)
        return emb * avail_flag

class StackContextEncoder(nn.Module):
    """
    Encodes device stack / interface context into a fixed 64-dim embedding.

    Same architecture as ProcessParamsEncoder; different feature set.
    See STACK_CONTEXT_FEATURES for full feature list.
    """

    def __init__(self, cfg: dict=None):
        super().__init__()
        cfg = cfg or STACK_CONTEXT_FEATURES
        self._num_cols = list(cfg['numerical'])
        self._log_cols = set(cfg.get('log_normalize', []))
        self._cat_spec = cfg['categorical']
        self._cat_cols = list(self._cat_spec.keys())
        embed_dim = cfg.get('embed_dim', 8)
        output_dim = cfg.get('output_dim', 64)
        self._vocab_sizes = {name: len(v) for name, v in self._cat_spec.items()}
        self.embeddings = nn.ModuleDict({name: nn.Embedding(len(vocab) + 1, embed_dim) for name, vocab in self._cat_spec.items()})
        n_num = len(self._num_cols)
        n_cat_emb = len(self._cat_cols) * embed_dim
        self.mlp = nn.Sequential(nn.Linear(n_num + n_cat_emb, 128), nn.SiLU(), nn.Dropout(0.1), nn.Linear(128, output_dim), nn.SiLU())
        self.register_buffer('num_mean', torch.zeros(n_num))
        self.register_buffer('num_std', torch.ones(n_num))

    def fit_stats(self, df: pd.DataFrame):
        """Fit z-score normalisation stats from a training dataframe."""
        means, stds = ([], [])
        for col in self._num_cols:
            if col in df.columns:
                vals = pd.to_numeric(df[col], errors='coerce').dropna()
                if col in self._log_cols:
                    vals = np.log1p(vals.clip(lower=0))
                means.append(float(vals.mean()) if len(vals) > 0 else 0.0)
                stds.append(float(vals.std()) if len(vals) > 1 else 1.0)
            else:
                means.append(0.0)
                stds.append(1.0)
        self.num_mean.copy_(torch.tensor(means, dtype=torch.float32))
        self.num_std.copy_(torch.tensor(stds, dtype=torch.float32).clamp(min=1e-06))

    def forward(self, num_feats: torch.Tensor, cat_indices: torch.Tensor, avail_flag: torch.Tensor) -> torch.Tensor:
        num_norm = (num_feats - self.num_mean) / self.num_std
        num_norm = num_norm * avail_flag
        cat_embs = [self.embeddings[name](cat_indices[:, i]) for i, name in enumerate(self._cat_cols)]
        x = torch.cat([num_norm] + cat_embs, dim=-1)
        emb = self.mlp(x)
        return emb * avail_flag
