from __future__ import annotations
from .common import Dict, Optional, math, nn, torch

class MaskedMultiTaskLoss(nn.Module):
    """
    Multi-task MSE loss with:
    1. Masking for missing targets (NaN → excluded from loss)
    2. Per-task loss weighting
    3. High-k upweighting: entries above per-task threshold get 5× weight

    HIGH_K_THRESHOLDS covers k-column variants across all tiers:
      "k_total"     → linear scale: threshold = 35.0  (Tier 1/2/3)
      "k_total_log" → log scale:    threshold = log(35) ≈ 3.555  (Tier 2/3)

    Review fix #2: previous code had `tgt_m > 35.0` for "k_total_log",
    which is never True in log space (values range 1.36–5.96 for k=3.9–386).
    UNIFY-K: "k_measured": 35.0 removed — k_total:35.0 covers all tiers.
    """
    HIGH_K_THRESHOLDS = {'k_total': 35.0, 'k_total_log': math.log(35.0)}
    HIGH_K_MULTIPLIER = 5.0

    def __init__(self, task_weights: Dict[str, float]=None, upweight_high_k: bool=True):
        super().__init__()
        self.task_weights = task_weights or {'k_total': 2.0, 'k_total_log': 2.0, 'band_gap': 1.0, 'formation_energy_per_atom': 1.0, 'e_above_hull': 0.5, 'J_g_A_cm2': 1.5, 'E_BD_MV_cm': 1.0, 'J_g_log': 1.5, 'E_BD': 1.0}
        self.upweight_high_k = upweight_high_k
        self.mse = nn.MSELoss(reduction='none')

    def forward(self, predictions: Dict[str, torch.Tensor], targets: Dict[str, torch.Tensor], functional_weights: Optional[torch.Tensor]=None) -> torch.Tensor:
        """functional_weights: float Tensor [B] of per-sample loss multipliers
        Accumulates task losses via torch.stack+mean to avoid disconnected
        tensor when all targets are NaN."""
        device = next(iter(predictions.values())).device
        task_losses = []
        for task, pred in predictions.items():
            if task not in targets:
                continue
            tgt = targets[task]
            mask = ~torch.isnan(tgt)
            if mask.sum() == 0:
                continue
            pred_m = pred[mask].squeeze()
            tgt_m = tgt[mask].squeeze()
            per_sample_loss = self.mse(pred_m, tgt_m)
            if task in self.HIGH_K_THRESHOLDS and self.upweight_high_k:
                threshold = self.HIGH_K_THRESHOLDS[task]
                high_k_mask = tgt_m > threshold
                hw = torch.ones_like(per_sample_loss)
                hw[high_k_mask] = self.HIGH_K_MULTIPLIER
                per_sample_loss = per_sample_loss * hw
            if functional_weights is not None:
                mask_1d = mask.view(-1) if mask.ndim > 1 else mask
                fw_m = functional_weights[mask_1d].squeeze()
                per_sample_loss = per_sample_loss * fw_m
            task_loss = per_sample_loss.mean()
            task_losses.append(self.task_weights.get(task, 1.0) * task_loss)
        if task_losses:
            return torch.stack(task_losses).mean()
        else:
            return next(iter(predictions.values())).new_zeros(())
