# High-k ALIGNN: three-tier research implementation

A modular refactor of `highk_alignn_train_v4_60_3_locked_disjoint_baseline(4).py`.
It retains this version's model, target definitions, loss, donor imputation,
stratified splits, frozen structural prior, structural adapter and bounded
process residual. Source hash and verification records are in `docs/`.

## Prepare once; train separately

All raw downloads, CSV/HDF5 parsing, tier assembly, dielectric transforms,
donor imputation, graph-schema checks and persistent Tier-3 split creation run
under **ordinary Python before DDP starts**. Training reads a verified prepared
pickle artifact, then initializes DDP and attaches rank-local samplers.
Training never downloads, opens HDF5, imputes donors or creates splits.

Graph tensors are still constructed on demand by the dataset during batches;
this is an in-memory transformation of prepared structure records and does not
write a shared cache. Precomputing every Tier-1 graph would create a much larger
artifact and is outside this refactor.

Preparation is deliberately rejected under `torchrun`, including world size 1.
A preparation lock excludes two concurrent preparation jobs on the same root.
Do not prepare and train against the same root simultaneously. Use a separate
root for an independent experiment.

## Environment

Use Linux/WSL and Python 3.10 or newer. Start with the original working ALIGNN
training environment if available. The dependency list declares packages; it
is **not a validated version lock**. PyTorch, DGL and CUDA must be compatible.
No package versions from the original training host were supplied.

```bash
python -m venv .venv
source .venv/bin/activate
# Install the PyTorch/DGL builds appropriate for your CUDA environment first.
python -m pip install -e .
python scripts/check_environment.py
```

Record a tested environment after acceptance:

```bash
python -m pip freeze > requirements-lock.txt
```

Use your own Materials Project API key for acquisition:

```bash
export MP_API_KEY="<your-own-key>"
```

Obtain it from https://materialsproject.org/dashboard. No key is needed to
train from prepared inputs or convert existing local caches. Keys and local
datasets/checkpoints are excluded by `.gitignore`.

## Start from existing baseline caches (recommended for parity)

Place these files in `highk_project/data/`:

- `tier1_foundation.h5`
- `tier2_domain.h5`
- `tier3_project.h5`

Also copy the original locked split CSVs into
`highk_project/reports/tier3_splits/` **before** preparing Tier 3:

- `tier3_test_row_ids.csv`
- `tier3_val_row_ids.csv`

```bash
highk --root highk_project prepare --tier all --reuse-caches
```

Tier 3 needs Tier 2 as its donor pool. The copied split identities are restored
and checked using the source version's rules. The source permits narrowing an
existing TEST lock when non-evaluable graph schemas are present; this is done
only during preparation. Inspect the prepared counts and hashes rather than
assuming the manuscript's population is reproduced automatically.

To avoid preparing all tiers at once:

```bash
highk --root highk_project prepare --tier 1 --reuse-caches
highk --root highk_project prepare --tier 2 --reuse-caches
highk --root highk_project prepare --tier 3 --reuse-caches
```

## Start from raw sources

For Tier 1, prepare downloads JARVIS-DFT, Materials Project and QM9 when the
needed cache is absent. Cross-source structural deduplication is retained.

```bash
highk --root highk_project prepare --tier 1
highk --root highk_project prepare --tier 2
highk --root highk_project prepare --tier 3 --process-db /absolute/path/process_db_clean.csv
```

Alternatively:

```bash
highk --root highk_project prepare --tier all --process-db /absolute/path/process_db_clean.csv
```

An explicit `--process-db` rebuilds Tier 3. `--force-rebuild` rebuilds the
selected tier caches. `--force-refresh` requests fresh raw downloads. Rebuilding
an upstream tier rebuilds downstream dataframe dependencies needed by that
command and invalidates dependent prepared manifests; prepare dependent tiers
again before training. If Tier 1 already exists, requesting only Tier 2 or 3
does not re-download raw sources.

Live databases change. Fresh acquisition may produce different row counts,
splits and results from the paper. Exact paper reproduction requires the
original data snapshot, split files, checkpoints and tested software versions.
Those assets are not bundled here.

## Train

Single process (GPU if available, otherwise CPU):

```bash
highk --root highk_project train --tier 1
highk --root highk_project train --tier 2
highk --root highk_project train --tier 3
```

DDP (two GPUs, sequential tier runs):

```bash
torchrun --standalone --nproc_per_node=2 -m highk --root highk_project train --tier 1
torchrun --standalone --nproc_per_node=2 -m highk --root highk_project train --tier 2
torchrun --standalone --nproc_per_node=2 -m highk --root highk_project train --tier 3
```

Tier 2 defaults to `checkpoints/tier1_best.pt`; Tier 3 defaults to
`checkpoints/tier2_best.pt`. Override with `--weights /path/checkpoint.pt`.
For context ablation add `--ablate-context`. Detailed diagnostics are available
with the global flag `--verbose` before `train` or `prepare`.

The preserved distributed backend is NCCL and requires CUDA for `torchrun`.
Each machine/rank must see the same prepared root. Multi-node operation was not
tested. Rank 0 alone writes shared reports, histories and checkpoints. The
sampler pads at most `world_size - 1` samples per epoch so ranks execute equal
batch counts; this intentionally changes uneven-size DDP runs from the unsafe
source behavior. It also now looks up process flags by the actual TRAIN indices.

## Evaluate

Evaluation is a separate single-process command:

```bash
highk --root highk_project evaluate --tier 1
highk --root highk_project evaluate --tier 2
highk --root highk_project evaluate --tier 3
```

It uses the baseline frozen-checkpoint evaluation routine with prepared
dataframes. Tier 3 restores the locked TEST identity. This evaluation path may
perform in-memory filtering/graph creation, but never runs inside DDP.

## Code map

| Module | Responsibility |
|---|---|
| `cli.py` | User commands, prerequisites and preparation/training separation |
| `config.py` | Baseline hyperparameters, targets, features and workspace paths |
| `common.py` | Shared imports and process-local runtime state |
| `artifacts.py` | Preparation lock, atomic artifacts, manifests and checksums |
| `extraction.py` | JARVIS, Materials Project, QM9 and experimental CSV parsing |
| `tier_builder.py` | Deduplication, tier filters and dataframe caches |
| `imputation.py` | Experimental donor structure matching and numeric cleanup |
| `preparation.py` | Target transforms, prepared datasets and canonical Tier-3 splits |
| `graph_data.py` | Structure-to-graph conversion, context tensors and collation |
| `splits.py` | Stratified splits, persistent row identities and sampler |
| `runtime.py` | Rank-local TRAIN/Phase-A loader binding |
| `encoders.py` | Process and stack feature encoders |
| `model.py` | ALIGNN, structural adapter, bounded process residual and weight mapping |
| `loss.py` | Masked multi-task loss |
| `trainer.py` | Optimization, checkpoints and model metrics |
| `workflows.py` | Tier-specific training phases on prepared inputs |
| `evaluation.py` | Frozen-checkpoint evaluation |
| `reporting.py` | Dataset summaries available for analysis |

## Verification and scientific scope

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

See `docs/VALIDATION.md` for checks completed and GPU acceptance steps.
**This is a refactor of the supplied v4_60_3 baseline, not a claim that it
incorporates later corrected manuscript reruns.** In particular, its encoder
normalization fitting populations and categorical feature handling are
preserved from that source. Verify them against the exact script used for the
final paper before asserting numerical reproduction. No reported manuscript
metrics are hard-coded as an acceptance result.

Prepared artifacts contain pickled dataset/loader objects and depend on the
installed package versions. Load only artifacts you created or otherwise
trust. They are local runtime caches, not a portable public dataset format.

This archive contains code/documentation, not the experimental CSV, original
data snapshots, trained weights or a chosen redistribution license. The data
availability information in `data/README.md` lists the assets required to
complete a public release.
