"""Execute the actual sampler implementation using a minimal torch base stub."""
import ast
from pathlib import Path
from types import SimpleNamespace
import unittest
import numpy as np

path=Path(__file__).resolve().parents[1]/'src/highk/splits.py'
node=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.ClassDef) and n.name=='BalancedDistributedSampler')
namespace={'torch':SimpleNamespace(utils=SimpleNamespace(data=SimpleNamespace(Sampler=object))),'np':np}
exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(path),'exec'),namespace)
Sampler=namespace['BalancedDistributedSampler']
class SamplerTest(unittest.TestCase):
    def test_equal_counts_for_uneven_sizes(self):
        for size in (1,17,31,32,33,63,65):
            for world in (2,3,4):
                samplers=[Sampler(range(size),[i%2 for i in range(size)],world,rank) for rank in range(world)]
                batches=[list(s) for s in samplers]
                self.assertEqual(len(set(map(len,batches))),1,(size,world))
                self.assertEqual(set(sum(batches,[])),set(range(size)))
                self.assertTrue(all(len(s)==len(b) for s,b in zip(samplers,batches)))
    def test_repeatable_and_epoch_dependent(self):
        s=Sampler(range(65),[i%2 for i in range(65)],2,1)
        first=list(s);self.assertEqual(first,list(s));s.set_epoch(1)
        self.assertNotEqual(first,list(s))
    def test_invalid_flag_alignment(self):
        with self.assertRaises(ValueError):Sampler(range(3),[1],2,0)
    def test_invalid_rank(self):
        with self.assertRaises(ValueError):Sampler(range(3),[1,0,1],2,2)
