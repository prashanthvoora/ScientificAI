import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from highk.artifacts import atomic_bytes, load_prepared, preparation_lock, require_single_process, save_prepared, sha256

class ArtifactsTest(unittest.TestCase):
    def test_round_trip(self):
        with tempfile.TemporaryDirectory() as root:
            save_prepared(root,1,{'rows':[3,8]}, {'config':{}})
            state, manifest = load_prepared(root,1)
            self.assertEqual(state,{'rows':[3,8]})
            self.assertEqual(manifest['tier'],1)
    def test_corruption_is_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            save_prepared(root,1,{}, {})
            (Path(root)/'data/prepared/tier1.pkl').write_bytes(b'broken')
            with self.assertRaisesRegex(RuntimeError,'checksum'):load_prepared(root,1)
    def test_split_change_is_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'reports/tier3_splits/tier3_test_row_ids.csv'
            path.parent.mkdir(parents=True);path.write_text('row_id\nA\n')
            save_prepared(root,3,{}, {'split_sha256':{path.name:sha256(path)}})
            path.write_text('row_id\nB\n')
            with self.assertRaisesRegex(RuntimeError,'identity'):load_prepared(root,3)
    def test_missing_artifact_has_actionable_error(self):
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaisesRegex(FileNotFoundError,'prepare'):load_prepared(root,2)
    def test_atomic_failure_preserves_old_file(self):
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'cache';path.write_bytes(b'old')
            def broken(stream):
                stream.write(b'partial');raise ValueError('failed')
            with self.assertRaises(ValueError):atomic_bytes(path,broken)
            self.assertEqual(path.read_bytes(),b'old')
            self.assertEqual(len(list(Path(root).iterdir())),1)
    def test_preparation_rejects_each_launcher_variable(self):
        for name in ('RANK','LOCAL_RANK','WORLD_SIZE'):
            with self.subTest(name=name),patch.dict(os.environ,{name:'0'},clear=True):
                with self.assertRaisesRegex(RuntimeError,'not torchrun'):require_single_process()
    def test_plain_python_allowed(self):
        with patch.dict(os.environ,{},clear=True):require_single_process()
    def test_preparation_lock(self):
        with tempfile.TemporaryDirectory() as root,preparation_lock(root):
            with self.assertRaisesRegex(RuntimeError,'Another preparation'):
                with preparation_lock(root):pass
