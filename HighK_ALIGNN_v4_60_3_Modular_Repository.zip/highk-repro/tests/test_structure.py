import ast
import builtins
import os
from pathlib import Path
import subprocess
import symtable
import sys
import unittest

PACKAGE=Path(__file__).resolve().parents[1]/'src/highk'
class StructureTest(unittest.TestCase):
    def test_all_modules_compile(self):
        for path in PACKAGE.glob('*.py'):
            with self.subTest(module=path.name):compile(path.read_text(),str(path),'exec')
    def test_no_unresolved_globals(self):
        for path in PACKAGE.glob('*.py'):
            table=symtable.symtable(path.read_text(),str(path),'exec')
            defined=set(table.get_identifiers())|set(dir(builtins))
            def check(t):
                for symbol in t.get_symbols():
                    if symbol.is_referenced() and symbol.is_global():
                        self.assertIn(symbol.get_name(),defined,(path.name,symbol.get_name()))
                for child in t.get_children():check(child)
            check(table)
    def test_training_has_no_data_preparation_calls(self):
        forbidden={'build_dataloader','build_tier3_hfo2_eval_dataloader','_impute_structures','read_hdf','to_hdf','build_tier1','build_tier2','build_tier3','pull_jarvis_dft','pull_materials_project','pull_qm9','save_tier3_test_split_rows'}
        for name in ('workflows.py','runtime.py'):
            for node in ast.walk(ast.parse((PACKAGE/name).read_text())):
                if isinstance(node,ast.Call):
                    target=getattr(node.func,'id',getattr(node.func,'attr',''))
                    self.assertNotIn(target,forbidden,(name,target))
    def test_cli_help_without_scientific_dependencies(self):
        result=subprocess.run([sys.executable,'-m','highk','--help'],text=True,capture_output=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('prepare',result.stdout)
    def test_prepare_guard_precedes_dependency_imports(self):
        env=dict(os.environ,RANK='1')
        result=subprocess.run([sys.executable,'-m','highk','prepare'],env=env,text=True,capture_output=True)
        self.assertNotEqual(result.returncode,0)
        self.assertIn('not torchrun',result.stderr)
        self.assertNotIn("No module named 'torch'",result.stderr)
    def test_ddp_device_uses_local_rank(self):
        source=(PACKAGE/'trainer.py').read_text()
        self.assertIn("device_ids=[_DIST['local_rank']]",source)
        self.assertIn("output_device=_DIST['local_rank']",source)
