"""Report versions without displaying credentials; capture before GPU acceptance tests."""
import importlib.metadata as metadata
import os
import platform
print('Python:', platform.python_version())
for package in ('torch','dgl','alignn','jarvis-tools','mp-api','pymatgen','numpy','pandas','tables'):
    try:print(package + ':',metadata.version(package))
    except metadata.PackageNotFoundError:print(package + ': MISSING')
print('MP_API_KEY set:',bool(os.getenv('MP_API_KEY')))
try:
    import torch
    print('CUDA available:',torch.cuda.is_available())
    print('torch CUDA build:',torch.version.cuda)
except ImportError:pass
