# Data availability assets

No experimental dataset, original HDF5 snapshot or trained weights are bundled.

The code obtains JARVIS-DFT/QM9 via jarvis-tools and Materials Project via mp-api.
Researchers supply their own MP credentials and follow upstream data terms.
Official references:

- https://jarvis.nist.gov/
- https://materialsproject.org/
- https://docs.materialsproject.org/downloading-data/using-the-api/querying-data

For exact-paper availability, supply a stable data archive with the original
three-tier snapshots, source versions/acquisition dates, record provenance,
experimental `process_db_clean.csv`, the locked Tier-3 VAL/TEST split files,
and checkpoint/environment metadata. Include checksums and an archive DOI or
stable URL in this file when those assets are released. Select an appropriate
code license and clarify upstream/experimental-data redistribution rights.
Do not include API keys.

Preparation metadata is generated under `ROOT/data/prepared/tierN.json` with
row counts, configuration, source-cache hashes, artifact hash and Tier-3 split
hashes. The source's persistent split manifest remains under
`ROOT/reports/tier3_splits/`.
