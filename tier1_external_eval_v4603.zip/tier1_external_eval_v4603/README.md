# Tier-1 External Benchmark Evaluation for v4.60.3

## Purpose

This package adds a separate `tier1_external_eval` mode. It evaluates the already-selected Tier-1 checkpoint on a frozen external benchmark. It never trains, creates an optimizer, selects a checkpoint, calibrates predictions, or writes a checkpoint.

## Manifest schema

Required:

- stable identity: `benchmark_row_id` or a recognized source ID;
- structure: `structure_path`, `cif_path`, or embedded `atoms_dict`;
- at least one target: `formation_energy_per_atom`, `band_gap`, or `k_total`.

Recommended metadata:

- `source_database`;
- `source_material_id`;
- `formula`;
- `dft_functional`;
- `functional_code` (`1` for the current PBE-compatible external default).

Paths in `structure_path` may be absolute or relative to the manifest directory.

## 1. Static validation

```bash
python -m py_compile highk_alignn_train_v4_60_3_tier1_external_eval.py
python -m py_compile prepare_tier1_external_manifest.py
```

## 2. Prepare and freeze a source export

The input can be a CSV/JSON/JSONL exported from OQMD, AFLOW, or another independent source. Every selected row must have a locally downloaded CIF/structure file.

```bash
python prepare_tier1_external_manifest.py \
  --input external_raw/oqmd_selected.csv \
  --output benchmarks/tier1_external_v1/manifest.csv \
  --source-name OQMD \
  --dft-functional PBE \
  --functional-code 1 \
  --structure-root external_raw/structures
```

The utility prints and saves the SHA-256 hash. Freeze the generated manifest and metadata before evaluation.

## 3. First smoke run

Use a small manifest first and disable bootstrap to check structure parsing and checkpoint loading:

```bash
CUDA_VISIBLE_DEVICES=0 python highk_alignn_train_v4_60_3_tier1_external_eval.py \
  --mode tier1_external_eval \
  --weights highk_project/checkpoints/tier1_best.pt \
  --tier1_external_manifest benchmarks/tier1_external_smoke/manifest.csv \
  --tier1_external_expected_hash <SHA256_FROM_METADATA> \
  --tier1_external_overlap_policy exclude \
  --tier1_external_batch_size 32 \
  --tier1_external_num_workers 0 \
  --tier1_external_n_boot 0 \
  --tier1_external_outdir highk_project/reports/tier1_external_smoke
```

## 4. Final frozen evaluation

Run as a single process. Do not use multi-rank `torchrun`; the mode deliberately rejects multiple ranks to prevent duplicate evaluation rows.

```bash
CUDA_VISIBLE_DEVICES=0 python highk_alignn_train_v4_60_3_tier1_external_eval.py \
  --mode tier1_external_eval \
  --weights highk_project/checkpoints/tier1_best.pt \
  --tier1_external_manifest benchmarks/tier1_external_v1/manifest.csv \
  --tier1_external_expected_hash <SHA256_FROM_METADATA> \
  --tier1_external_overlap_policy exclude \
  --tier1_external_batch_size 64 \
  --tier1_external_num_workers 4 \
  --tier1_external_n_boot 10000 \
  --tier1_external_outdir highk_project/reports/tier1_external_v1
```

## Overlap policies

- `exclude` (recommended): audit and remove structural matches to the Tier-1 cache;
- `fail`: abort if any overlap is detected;
- `report`: retain overlaps but mark them non-strict; not for the primary headline score;
- `off`: skip overlap checking; only for debugging.

The overlap check groups by reduced formula and then uses pymatgen `StructureMatcher` with the same tolerances used by the training pipeline.

## Outputs

- `tier1_external_summary.md`
- `tier1_external_metrics.csv`
- `tier1_external_prediction_audit.csv`
- `tier1_external_overlap_audit.csv`
- `tier1_external_metadata.json`

Metrics include native-scale formation-energy and band-gap errors, log- and linear-scale dielectric errors, MAD::MAE, and 10,000-sample percentile bootstrap CIs for MAE and MAD::MAE.

## Acceptance checks

The final run should show:

1. manifest SHA-256 equals the frozen metadata hash;
2. required Tier-1 checkpoint heads load without missing tensors;
3. overlap audit completes and the strict-external retained count is non-zero;
4. no optimizer/scheduler/checkpoint output appears;
5. `n` for each metric equals the corresponding valid-target count after overlap exclusion and graph validation;
6. prediction audit contains unique `(benchmark_row_id, task)` pairs;
7. rerunning the same command produces identical point metrics and prediction rows.

## Interpretation

This benchmark measures cross-source transfer. Differences can reflect both model generalization and source-method shift (functional, pseudopotential, relaxation, and reference-energy conventions). Keep OQMD-PBE and any HSE/other-fidelity subsets in separate manifests and reports.
