#!/usr/bin/env python3
from pathlib import Path
import argparse, json
import pandas as pd

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outdir',required=True); a=ap.parse_args()
    d=Path(a.outdir)
    req=['tier1_external_metrics.csv','tier1_external_prediction_audit.csv','tier1_external_metadata.json','tier1_external_overlap_audit.csv']
    missing=[x for x in req if not (d/x).exists()]
    if missing: raise SystemExit(f'FAIL missing outputs: {missing}')
    m=pd.read_csv(d/'tier1_external_metrics.csv')
    p=pd.read_csv(d/'tier1_external_prediction_audit.csv')
    meta=json.loads((d/'tier1_external_metadata.json').read_text())
    if p.duplicated(['benchmark_row_id','task']).any(): raise SystemExit('FAIL duplicate prediction identities')
    if not bool(meta.get('inference_only')): raise SystemExit('FAIL metadata does not declare inference_only')
    if (m['n']<=0).any(): raise SystemExit('FAIL one or more reported tasks have n<=0')
    print('PASS external evaluation outputs')
    print(m.to_string(index=False))
if __name__=='__main__': main()
